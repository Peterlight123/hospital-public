<?php

use App\Models\PatientConsent;
use App\Models\LivingArrangements;
use App\Models\SpiritualPreference;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\patient\DnrController;
use App\Http\Controllers\patient\HisPdfController;
use App\Http\Controllers\patient\SelectController;
use App\Http\Controllers\patient\addressController;
use App\Http\Controllers\patient\PatientController;
use App\Http\Controllers\patient\DischargeController;
use App\Http\Controllers\patient\NutritionController;
use App\Http\Controllers\patient\PrognosisController;
use App\Http\Controllers\patient\SignatureController;
use App\Http\Controllers\patient\DmeProviderController;
use App\Http\Controllers\patient\BenefitPeriodController;
use App\Http\Controllers\patient\RaceEthnicityController;
use App\Http\Controllers\patient\LiaisonPrimaryController;
use App\Http\Controllers\patient\PatientPharmacyController;
use App\Http\Controllers\patient\LiaisonSecondaryController;
use App\Http\Controllers\patient\PayerInformationController;
use App\Http\Controllers\patient\PrimaryDiagnosisController;
use App\Http\Controllers\patient\VisitInformationController;
use App\Http\Controllers\patient\CardiacAssessmentController;
use App\Http\Controllers\patient\LivingArrangementsController;
use App\Http\Controllers\patient\EndocrineAssessmentController;
use App\Http\Controllers\patient\NursingClinicalNoteController;

use App\Http\Controllers\patient\SpiritualPreferenceController;
use App\Http\Controllers\patient\AdmissionInformationController;
use App\Http\Controllers\patient\HematologicalAssessmentController;
use App\Http\Controllers\patient\IntegumentaryAssessmentController;
use App\Http\Controllers\patient\EmergencyPreparednessLevelController;
use App\Http\Controllers\patient\PatientIdentifiersController;
use App\Http\Controllers\patient\Pain\PainTypeController;
use App\Http\Controllers\patient\Pain\PainAssessmentController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

// Public routes 
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout']);
Route::get('/dischargeSections', [DischargeController::class, 'dischargeSections']);
Route::get('/generate-pdf/{noteId}', [NursingClinicalNoteController::class, 'generatePdf']);

Route::get('/generate-his-pdf ', [HisPdfController::class, 'generatePdf']);
Route::get('/patients/{id}/chart', [BenefitPeriodController::class, 'getPatientChart']);

Route::get('/nursing-clinical-notes/{id}', [NursingClinicalNoteController::class, 'show']);
Route::put('/nursing-clinical-notes/{id}', [NursingClinicalNoteController::class, 'update']);

Route::get('/nursing-clinical-notes-chart/{noteId}', [NursingClinicalNoteController::class, 'show']);


Route::get('/pain-type/breakthrough', [PainTypeController::class, 'PainBreakthrough']);
Route::get('/pain-type/character', [PainTypeController::class, 'PainCharacter']);
Route::get('/pain-type/frequency', [PainTypeController::class, 'PainFrequency']);
Route::get('/pain-type/observation', [PainTypeController::class, 'PainObservation']);
Route::get('/pain-type/effects-on-function', [PainTypeController::class, 'PainEffectsOnFunction']);
Route::get('/pain-type/rating-scale-used', [PainTypeController::class, 'TypeOfPainRatingScaleUsed']);
Route::get('/pain-type/rated-by', [PainTypeController::class, 'PainRatedBy']);
Route::get('/pain-type/worsened', [PainTypeController::class, 'PainWorsened']);
Route::get('/pain-type/relieved-by', [PainTypeController::class, 'PainRelivedBy']);
Route::get('/pain-type/duration', [PainTypeController::class, 'PainDuration']);
Route::get('/pain-type/negative-vocalization', [PainTypeController::class, 'NegativeVocalization']);
Route::get('/pain-type/facial-expression', [PainTypeController::class, 'FacialExpression']);
Route::get('/pain-type/body-language', [PainTypeController::class, 'BodyLanguage']);
Route::get('/pain-type/consolability', [PainTypeController::class, 'Consolability']);
Route::get('/pain-type/breathing', [PainTypeController::class, 'Breathing']);
Route::get('/pain-type/face', [PainTypeController::class, 'Face']);
Route::get('/pain-type/legs', [PainTypeController::class, 'Legs']);
Route::get('/pain-type/activity', [PainTypeController::class, 'Activity']);
Route::get('/pain-type/cry', [PainTypeController::class, 'Cry']);
Route::get('/pain-type/pain-serverity', [PainTypeController::class, 'PainServerity']);
Route::get('/pain-type/standardized-pain-tool', [PainTypeController::class, 'StandardizedPainTool']);
Route::get('/pain-type/comprehensive-pain-included', [PainTypeController::class, 'ComprehensivePainIncluded']);
Route::get('/pain-type/flaacc-behavioral-consolability', [PainTypeController::class, 'FlaaccBehavioralConsolability']);


Route::post('/pain-assessment/store', [PainAssessmentController::class, 'painLevelSeveritystore']);
Route::get('/pain-assessment', [PainAssessmentController::class, 'index']);
Route::get('/pain-assessment/{id}', [PainAssessmentController::class, 'show']);

Route::post('/pain-rated-by/store', [PainAssessmentController::class, 'painRatedByStore']);
Route::post('/pain-duration/store', [PainAssessmentController::class, 'painDurationStore']);
Route::post('/pain-frequency/store', [PainAssessmentController::class, 'painFrequencyStore']);
Route::post('/pain-observation/store', [PainAssessmentController::class, 'painObservationStore']);
Route::post('/pain-worsened-by/store', [PainAssessmentController::class, 'painWorsenedByStore']);
Route::post('/pain-character/store', [PainAssessmentController::class, 'painCharacterStore']);
Route::post('/pain-relieved-by/store', [PainAssessmentController::class, 'painRelievedByStore']);
Route::post('/pain-effects-on-function/store', [PainAssessmentController::class, 'painEffectsOnFunctionStore']);
Route::post('/pain-breakthrough/store', [PainAssessmentController::class, 'painBreakthroughStore']);
Route::post('/pain-rating-scale/store', [PainAssessmentController::class, 'typeOfPainRatingScaleUsedStore']);
Route::post('/pain-vital-signs/store', [PainAssessmentController::class, 'painVitalSignsStore']);
Route::post('/pain-scales-tools-lab-data-reviews/store', [PainAssessmentController::class, 'painScalesToolsLabDataReviewsStore']);
Route::post('/pain-assessment-in-dementia-scale/store', [PainAssessmentController::class, 'painAssessmentInDementiaScaleStore']);
Route::post('/flacc-behavioral-pain/store', [PainAssessmentController::class, 'flaccBehavioralPainStore']);
Route::post('/pain-screening/store', [PainAssessmentController::class, 'painScreeningStore']);
Route::post('/pain-active-problem/store', [PainAssessmentController::class, 'painActiveProblemStore']);
Route::post('/pain-summary-interventions-goals/store', [PainAssessmentController::class, 'painSummaryInterventionsGoalsStore']);
Route::post('/comprehensive-pain-assessment/store', [PainAssessmentController::class, 'comprehensivePainAssessmentStore']);

Route::get('/pain-rated-by/{id}', [PainAssessmentController::class, 'painRatedById']);
Route::get('/pain-duration/{id}', [PainAssessmentController::class, 'painDurationById']);
Route::get('/pain-frequency/{id}', [PainAssessmentController::class, 'painFrequencyById']);
Route::get('/pain-observation/{id}', [PainAssessmentController::class, 'painObservationById']);
Route::get('/pain-worsened-by/{id}', [PainAssessmentController::class, 'painWorsenedById']);
Route::get('/pain-character/{id}', [PainAssessmentController::class, 'painCharacterById']);
Route::get('/pain-relieved-by/{id}', [PainAssessmentController::class, 'painRelievedById']);
Route::get('/pain-effects-on-function/{id}', [PainAssessmentController::class, 'painEffectsOnFunctionById']);
Route::get('/pain-breakthrough/{id}', [PainAssessmentController::class, 'painBreakthroughById']);
Route::get('/pain-rating-scale/{id}', [PainAssessmentController::class, 'typeOfPainRatingScaleUsedById']);
Route::get('/pain-vital-signs/{id}', [PainAssessmentController::class, 'painVitalSignsById']);
Route::get('/pain-scales-tools-lab-data-reviews/{id}', [PainAssessmentController::class, 'painScalesToolsLabDataReviewsById']);
Route::get('/pain-assessment-in-dementia-scale/{id}', [PainAssessmentController::class, 'painAssessmentInDementiaScaleById']);
Route::get('/flacc-behavioral-pain/{id}', [PainAssessmentController::class, 'flaccBehavioralPainById']);
Route::get('/pain-screening/{id}', [PainAssessmentController::class, 'painScreeningById']);
Route::get('/pain-summary-interventions-goals/{id}', [PainAssessmentController::class, 'painSummaryInterventionsGoalsById']);
Route::get('/comprehensive-pain-assessment/{id}', [PainAssessmentController::class, 'comprehensivePainAssessmentById']);
Route::get('/pain-active-problem/{id}', [PainAssessmentController::class, 'painActiveProblemById']);

Route::group(['middleware' => ['jwt.auth']], function () {

    //User
    Route::get('/users', [UserController::class, 'index']);
    Route::post('/user/store', [UserController::class, 'store']);
    Route::get('/user/{id}', [UserController::class, 'show']);
    Route::put('/user/update/{id}', [UserController::class, 'update']);
    Route::delete('/user/{id}', [UserController::class, 'destroy']);

    Route::get('/permissions', [PermissionController::class, 'index']);
    Route::get('/permissions/list', [PermissionController::class, 'permissionList']);
    Route::post('/permissions/store', [PermissionController::class, 'store']);
    Route::get('/permissions/{id}', [PermissionController::class, 'show']);
    Route::put('/permissions/{id}', [PermissionController::class, 'update']);
    Route::delete('/permissions/{id}', [PermissionController::class, 'destroy']);
    // signature
    Route::post('/signature/store', [SignatureController::class, 'store']);
    Route::get('/signature', [SignatureController::class, 'index']);
    Route::get('/signature/{id}', [SignatureController::class, 'show']);
    Route::delete('/signature/delete/{id}', [SignatureController::class, 'delete']);

    Route::get('/roles', [RoleController::class, 'index']);
    Route::post('/role/store', [RoleController::class, 'store']);
    Route::get('/role/{id}', [RoleController::class, 'show']);
    Route::put('/role/{id}', [RoleController::class, 'update']);
    Route::delete('/roles/{id}', [RoleController::class, 'destroy']);
    // provders
    Route::get('/providers', [DmeProviderController::class, 'index']);
    Route::post('/providers/store', [DmeProviderController::class, 'store']);
    Route::get('/providers/{id}', [DmeProviderController::class, 'show']);
    Route::put('/providers/update/{id}', [DmeProviderController::class, 'update']);
    Route::delete('/providers/{id}', [DmeProviderController::class, 'destroy']);
    // primaryDiagnosis
    Route::get('/primaryDiagnosis', [PrimaryDiagnosisController::class, 'index']);
    Route::post('/primaryDiagnosis/store', [PrimaryDiagnosisController::class, 'store']);
    Route::get('/primaryDiagnosis/{id}', [PrimaryDiagnosisController::class, 'show']);
    Route::put('/primaryDiagnosis/update/{id}', [PrimaryDiagnosisController::class, 'update']);
    Route::delete('/primaryDiagnosis/{id}', [PrimaryDiagnosisController::class, 'destroy']);
    // VisitInformation
    Route::get('/saveAuto', [VisitInformationController::class, 'index']);
    Route::get('/saveAuto/{id}', [VisitInformationController::class, 'show']);
    Route::post('/saveAuto/store', [VisitInformationController::class, 'store']);

    // Address
    Route::get('/address', [addressController::class, 'index']);
    Route::get('/address/{id}', [addressController::class, 'show']);
    Route::post('/address/store', [addressController::class, 'store']);
    // Address
    Route::get('/payerInformation', [PayerInformationController::class, 'index']);
    Route::get('/payerInformation/{id}', [PayerInformationController::class, 'show']);
    Route::post('/payerInformation/store', [PayerInformationController::class, 'store']);
    // payer Information
    Route::get('/payerInformation', [PayerInformationController::class, 'index']);
    Route::get('/payerInformation/{id}', [PayerInformationController::class, 'show']);
    Route::post('/payerInformation/store', [PayerInformationController::class, 'store']);
    // Admission 
    Route::get('/admission', [AdmissionInformationController::class, 'index']);
    Route::get('/admission/{id}', [AdmissionInformationController::class, 'show']);
    Route::post('/admission/store', [AdmissionInformationController::class, 'autoSave']);
    // checkbox list
    Route::get('/siteOfService', [SelectController::class, 'siteOfServiceList']);
    Route::get('/admittedForm', [SelectController::class, 'admittedFormList']);
    Route::get('/prognosisPatient', [SelectController::class, 'prognosisPatientList']);
    Route::get('/prognosisImminence', [SelectController::class, 'prognosisImminence']);
    Route::get('/prognosisCaregiver', [SelectController::class, 'prognosisCaregiver']);
    Route::get('/nutritionTemplate', [SelectController::class, 'nutitionTemplate']);
    Route::get('/nutitionProblems', [SelectController::class, 'nutitionProblem']);
    //patientPharmacy
    Route::get('/patientPharmacy', [PatientPharmacyController::class, 'index']);
    Route::post('/patientPharmacy/store', [PatientPharmacyController::class, 'store']);
    Route::get('/patientPharmacy/{id}', [PatientPharmacyController::class, 'show']);
    Route::put('/patientPharmacy/update/{id}', [PatientPharmacyController::class, 'update']);
    Route::delete('/patientPharmacy/{id}', [PatientPharmacyController::class, 'destroy']);

    // nutrition problems types
    Route::get('/nutrition_problems_types', [NutritionController::class, 'nutritionProblemsTypes']);
    Route::get('/nutrition_assessment/{id}', [NutritionController::class, 'nutritionAssessmentShow']);
    Route::post('/nutrition_assessment_auto_save/{id}', [NutritionController::class, 'nutritionAssessmentAutoSave']);
    //prognosis

    Route::post('/prognosis/store', [PrognosisController::class, 'store']);
    Route::get('/prognosis', [PrognosisController::class, 'index']);
    Route::get('/prognosis/{id}', [PrognosisController::class, 'show']);

    //livingArrangements
    Route::post('/livingArrangements/store', [LivingArrangementsController::class, 'store']);
    Route::get('/livingArrangements', [LivingArrangementsController::class, 'index']);
    Route::get('/livingArrangements/{id}', [LivingArrangementsController::class, 'show']);

    //livingArrangements
    Route::post('/spiritualPreference/store', [SpiritualPreferenceController::class, 'store']);
    Route::get('/spiritualPreference', [SpiritualPreferenceController::class, 'index']);
    Route::get('/spiritualPreference/{id}', [SpiritualPreferenceController::class, 'show']);

    //cardiac
    Route::post('/cardiac/store', [CardiacAssessmentController::class, 'store']);
    Route::get('/cardiac', [CardiacAssessmentController::class, 'index']);
    Route::get('/cardiacList', [CardiacAssessmentController::class, 'cardiacList']);
    Route::get('/cardiac/{id}', [CardiacAssessmentController::class, 'show']);
    //endocrine

    Route::post('/endocrine/store', [EndocrineAssessmentController::class, 'store']);
    Route::get('/endocrine', [EndocrineAssessmentController::class, 'index']);
    Route::get('/endocrineList', [EndocrineAssessmentController::class, 'endocrineList']);
    Route::get('/endocrine/{id}', [EndocrineAssessmentController::class, 'show']);
    //hematological

    Route::post('/hematological/store', [HematologicalAssessmentController::class, 'store']);
    Route::get('/hematological', [HematologicalAssessmentController::class, 'index']);
    Route::get('/hematologicalList', [HematologicalAssessmentController::class, 'hematologicalList']);
    Route::get('/hematological/{id}', [HematologicalAssessmentController::class, 'show']);
    //hematological

    Route::post('/discharge/store', [DischargeController::class, 'store']);
    Route::get('/discharge', [DischargeController::class, 'index']);
    Route::get('/dischargeList', [DischargeController::class, 'DischargeList']);
    Route::get('/discharge/{id}', [DischargeController::class, 'show']);

    //integumentary

    Route::post('/integumentary/store', [IntegumentaryAssessmentController::class, 'store']);
    Route::get('/integumentary', [IntegumentaryAssessmentController::class, 'index']);
    Route::get('/integumentaryList', [IntegumentaryAssessmentController::class, 'integumentaryList']);
    Route::get('/integumentary/{id}', [IntegumentaryAssessmentController::class, 'show']);

    Route::get('/liaisonPrimary', [LiaisonPrimaryController::class, 'index']); // all posts
    Route::post('/liaisonPrimary/store', [LiaisonPrimaryController::class, 'store']); // create post
    Route::get('/liaisonPrimary/{id}', [LiaisonPrimaryController::class, 'show']); // get single post
    Route::put('/liaisonPrimary/{id}', [LiaisonPrimaryController::class, 'update']); // update post
    Route::delete('/liaisonPrimary/{id}', [LiaisonPrimaryController::class, 'destroy']); // delete post

    Route::get('/liaisonSecondary', [LiaisonSecondaryController::class, 'index']); // all posts
    Route::post('/liaisonSecondary/store', [LiaisonSecondaryController::class, 'store']); // create post
    Route::get('/liaisonSecondary/{id}', [LiaisonSecondaryController::class, 'show']); // get single post
    Route::put('/liaisonSecondary/{id}', [LiaisonSecondaryController::class, 'update']); // update post
    Route::delete('/liaisonSecondary/{id}', [LiaisonSecondaryController::class, 'destroy']); // delete post

    Route::get('/raceEthnicity', [RaceEthnicityController::class, 'index']); // all posts
    Route::post('/raceEthnicity/store', [RaceEthnicityController::class, 'store']); // create post
    Route::get('/raceEthnicity/{id}', [RaceEthnicityController::class, 'show']); // get single post
    Route::put('/raceEthnicity/{id}', [RaceEthnicityController::class, 'update']); // update post
    Route::delete('/raceEthnicity/{id}', [RaceEthnicityController::class, 'destroy']); // delete post

    Route::get('/emergencyPreparednessLevel', [EmergencyPreparednessLevelController::class, 'index']); // all posts
    Route::post('/emergencyPreparednessLevel/store', [EmergencyPreparednessLevelController::class, 'store']); // create post
    Route::get('/emergencyPreparednessLevel/{id}', [EmergencyPreparednessLevelController::class, 'show']); // get single post
    Route::put('/emergencyPreparednessLevel/{id}', [EmergencyPreparednessLevelController::class, 'update']); // update post
    Route::delete('/emergencyPreparednessLevel/{id}', [EmergencyPreparednessLevelController::class, 'destroy']); // delete post

    Route::get('/dnr', [DnrController::class, 'index']); // all posts
    Route::post('/dnr/store', [DnrController::class, 'store']); // create post
    Route::get('/dnr/{id}', [DnrController::class, 'show']); // get single post
    Route::put('/dnr/{id}', [DnrController::class, 'update']); // update post
    Route::delete('/dnr/{id}', [DnrController::class, 'destroy']); // delete post

    Route::get('/patient', [PatientController::class, 'index']); // all posts
    Route::post('/patient/store', [PatientController::class, 'store']); // create post
    Route::get('/patient/{id}', [PatientController::class, 'show']); // get single post
    Route::put('/patient/{id}', [PatientController::class, 'update']); // update post
    Route::delete('/patient/{id}', [PatientController::class, 'destroy']); // delete post

    Route::get('/patientIdentifiers', [PatientIdentifiersController::class, 'index']); // all posts
    Route::post('/patientIdentifiers/store', [PatientIdentifiersController::class, 'store']); // create post
    Route::get('/patientIdentifiers/{id}', [PatientIdentifiersController::class, 'show']); // get single post
    Route::put('/patientIdentifiers/{id}', [PatientIdentifiersController::class, 'update']); // update post
    Route::delete('/patientIdentifiers/{id}', [PatientIdentifiersController::class, 'destroy']); // delete post

});

Route::get('/vital_signs/{noteId}', [NursingClinicalNoteController::class, 'getVitalSigns']);
Route::post('/vital_signs/{noteId}', [NursingClinicalNoteController::class, 'autoSaveVitalSigns']);

Route::get('/scales_tools_lab_data/{noteId}', [NursingClinicalNoteController::class, 'indexScaleToolLabData']);
Route::post('/scales_tools_lab_data/{noteId}', [NursingClinicalNoteController::class, 'autoSaveScaleToolLabData']);

Route::get('/pain_data/{noteId}', [NursingClinicalNoteController::class, 'indexPainData']);
Route::post('/pain_data/{noteId}', [NursingClinicalNoteController::class, 'autoSavePainData']);

Route::get('painad_data/{noteId}', [NursingClinicalNoteController::class, 'indexPainadData']);
Route::post('painad_data/{noteId}', [NursingClinicalNoteController::class, 'autoSavePainadData']);

Route::get('/flacc_data/{noteId}', [NursingClinicalNoteController::class, 'indexFlaccData']);
Route::post('/flacc_data/{noteId}', [NursingClinicalNoteController::class, 'autoSaveFlaccData']);

Route::get('cardiovascular_data/{noteId}', [NursingClinicalNoteController::class, 'indexCardiovascularData']);
Route::post('cardiovascular_data/{noteId}', [NursingClinicalNoteController::class, 'autoSaveCardiovascularData']);

Route::get('respiratory_data/{noteId}', [NursingClinicalNoteController::class, 'indexRespiratoryData']);
Route::post('respiratory_data/{noteId}', [NursingClinicalNoteController::class, 'autoSaveRespiratoryData']);

Route::get('genitourinary_data/{noteId}', [NursingClinicalNoteController::class, 'indexGenitourinaryData']);
Route::post('genitourinary_data/{noteId}', [NursingClinicalNoteController::class, 'autoSaveGenitourinaryData']);

Route::get('gastrointestinal_data/{noteId}', [NursingClinicalNoteController::class, 'indexGastrointestinalData']);
Route::post('gastrointestinal_data/{noteId}', [NursingClinicalNoteController::class, 'autoSaveGastrointestinalData']);

Route::get('/nursing_clinical_notes/{id}', [NursingClinicalNoteController::class, 'show']);
Route::post('/nursing_clinical_notes/{id}', [NursingClinicalNoteController::class, 'update']);
Route::post('/benefit-periods/{periodId}/nursing-clinical-notes', [NursingClinicalNoteController::class, 'startNote']);
