<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PDF Content</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      color: #4a5568;
    }
    .container {
      border-radius: 5px;
      box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.1);
      padding: 20px;
      margin: 20px;
    }
    .row {
      display: flex;
      flex-wrap: wrap;
      margin-bottom: 15px;
    }
    .column {
      flex: 1;
      padding: 10px;
    }
    .half {
      flex: 0 0 50%;
      max-width: 50%;
    }
    .full {
      flex: 0 0 100%;
      max-width: 100%;
    }
    .typography-h4 {
      font-size: 1.5em;
      color: #4a5568;
      margin-bottom: 20px;
    }
    .typography-h5 {
      font-size: 1.25em;
      color: #4a5568;
      margin-bottom: 10px;
    }
    .typography-body1 {
      font-size: 1em;
      color: #4a5568;
      margin-bottom: 5px;
    }
    .form-check {
      margin-bottom: 10px;
    }
    .form-check input {
      margin-right: 10px;
    }
    .form-control {
      width: 100%;
      padding: 8px;
      margin-bottom: 10px;
      box-sizing: border-box;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="row full">
      <div class="column full">
        <p class="typography-h4">Chart: 1 Benefit Period: 4 Level of Care Routine Home Care 10/05/2024</p>
      </div>
    </div>
    <div class="row">
      <div class="column half">
        <p class="typography-body1">Time In:</p>
        <input type="time" class="form-control">
      </div>
      <div class="column half">
        <p class="typography-body1">Time Out:</p>
        <input type="time" class="form-control">
      </div>
    </div>
    <div class="row">
      <div class="column half">
        <p class="typography-h5">Patient Name: Last: Adams First: Julie</p>
        <p class="typography-h5">Patient Number:</p>
        <p class="typography-h5">Location Name:</p>
        <p class="typography-h5">Benefit Period:</p>
      </div>
      <div class="column half">
        <p class="typography-h5">DOB:</p>
        <p class="typography-h5">Location Number:</p>
        <div class="form-check">
          <input type="checkbox">
          <label>PRN Visit (Specify):</label>
        </div>
        <p class="typography-h5">Benefit Period Dates: From 09/05/2024 To 10/05/2024</p>
      </div>
    </div>
    <div class="row full">
      <p class="typography-h4">Two (or more) patient identifiers used this visit:</p>
      <div class="column half">
        <div class="form-check">
          <input type="checkbox">
          <label>Assigned identification number (for example, MBI, SSN)</label>
        </div>
        <div class="form-check">
          <input type="checkbox">
          <label>Insurance card</label>
        </div>
        <div class="form-check">
          <input type="checkbox">
          <label>Passport</label>
        </div>
        <div class="form-check">
          <input type="checkbox">
          <label>Other patient identifier(s) used this visit:</label>
        </div>
      </div>
      <div class="column half">
        <div class="form-check">
          <input type="checkbox">
          <label>Direct facial recognition (known to staff)</label>
        </div>
        <div class="form-check">
          <input type="checkbox">
          <label>Patient address confirmed</label>
        </div>
        <div class="form-check">
          <input type="checkbox">
          <label>Social Security Card</label>
        </div>
        <div class="form-check">
          <input type="checkbox">
          <label>Driver's license</label>
        </div>
        <div class="form-check">
          <input type="checkbox">
          <label>Patient Name</label>
        </div>
        <div class="form-check">
          <input type="checkbox">
          <label>Unknown or not assessed</label>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
