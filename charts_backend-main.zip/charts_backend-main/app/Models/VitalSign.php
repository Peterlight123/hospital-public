<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VitalSign extends Model
{
    use HasFactory;

    protected $fillable = [
        'note_id',
        'degrees_fahrenheit',
        'temperature_method',
        'heart_rate',
        'heart_rhythm',
        'heart_rate_location',
        'other_heart_rate_location',
        'bp_systolic',
        'bp_diastolic',
        'bp_position',
        'bp_location',
        'other_bp_location',
        'bp_additional_readings',
        'respiratory_rate',
        'respiratory_rhythm',
        'pulse_oximetry_percentage',
        'pulse_ox_location',
        'pulse_ox_other_location',
        'body_height_inches',
        'body_weight_ibs',
        'body_weight_kg',
        'body_weight_period',
        'bmi_kg_m2',
        'bmi_percentage',
        'bp_mmhg',
    ];

    public function nursingClinicalNote()
    {
        return $this->belongsTo(NursingClinicalNote::class, 'note_id');
    }
}
