<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dnr extends Model
{
    use HasFactory;
    protected $table = 'dnr';
    protected $guarded = ['id'];
    public function patient()
    {
        return $this->hasMany(Patient::class, 'dnr_id');
    }
}
