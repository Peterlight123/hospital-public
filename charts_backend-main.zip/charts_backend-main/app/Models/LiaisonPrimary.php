<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LiaisonPrimary extends Model
{
    use HasFactory;
    /**
     * Nom de la table associée au modèle.
     *
     * @var string
     */
    protected $table = 'liaison_primary';
    protected $guarded = ['id'];
    public function patient()
    {
        return $this->hasMany(Patient::class, 'liaison_primary_id');
    }
}
