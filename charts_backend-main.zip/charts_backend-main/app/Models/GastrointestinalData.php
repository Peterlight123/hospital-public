<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GastrointestinalData extends Model
{
    use HasFactory;

    protected $fillable = [
        'note_id','last_bm', 'unknown', 'bowel_sounds', 'present', 'hyper_active', 'hypo_active', 'absent',
        'rectal_bleeding', 'hemorrhoids', 'bowel_incontinence', 'change_bowel_incontinence', 'constipation',
        'diarrhea', 'ascites', 'ostomy_details', 'drain_details', 'anorexia', 'cachexia', 'nausea', 'vomiting',
        'no_intake_last_24hrs', 'swallowing_deficits', 'inability_swallow', 'diet', 'percentage_eaten', 'npo',
        'tube_feeding', 'placement_checked', 'most_recent_rbs', 'hyperglycemia', 'hypoglycemia', 'other',
        'no_deficit', 'describe_deficits'
    ];

    protected $casts = [
        'present' => 'array',
        'hyper_active' => 'array',
        'hypo_active' => 'array',
        'absent' => 'array',
    ];
}
