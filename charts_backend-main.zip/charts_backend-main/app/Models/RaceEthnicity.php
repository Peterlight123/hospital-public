<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RaceEthnicity extends Model
{
    use HasFactory;
    protected $table = 'race_ethnicity';
    protected $guarded = ['id'];
    public function patient()
    {
        return $this->hasMany(Patient::class, 'race_ethnicity_id');
    }
}
