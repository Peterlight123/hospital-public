<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CardiovascularData extends Model
{
    use HasFactory;

    protected $fillable = [
        'note_id',
        'chest_pain',
        'dizziness',
        'edema',
        'pedal',
        'right',
        'left',
        'sacral',
        'dependent',
        'irregular_heart_sounds',
        'neck_vein_distention',
        'devices',
        'additional_details',
        'present',
        'bounding',
        'weak_thready',
        'absent',
        'cardiovascular_note',
        'right_foot',
        'left_foot',
        'right_ankle',
        'left_ankle',
        'right_calf',
        'left_calf',
        'right_upper_leg',
        'left_upper_leg',
        'right_hand',
        'left_hand',
        'right_arm',
        'left_arm',
        'right_scrotum',
        'left_scrotum',
        'right_face',
        'left_face',
    ];

    protected $casts = [
        'edema' => 'array',
        'devices' => 'array',
        'present' => 'array',
        'bounding' => 'array',
        'weak_thready' => 'array',
        'absent' => 'array',
    ];
}
