<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class BenefitPeriod extends Model
{
    use HasFactory;

    protected $fillable = [
        'patient_id', 'start_date', 'end_date', 'period_number'
    ];

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    public function nursingClinicalNotes()
    {
        return $this->hasMany(NursingClinicalNote::class);
    }

    public static function createNextBenefitPeriod($patientId)
    {
        $lastBenefitPeriod = self::where('patient_id', $patientId)->orderBy('end_date', 'desc')->first();

        if ($lastBenefitPeriod) {
            $startDate = Carbon::parse($lastBenefitPeriod->end_date)->addDay();
            $periodNumber = $lastBenefitPeriod->period_number + 1;
        } else {
            // No previous benefit periods, starting the first one
            $startDate = Carbon::today();
            $periodNumber = 1;
        }

        if ($periodNumber == 1 || $periodNumber == 2) {
            $duration = 90;
        } else {
            $duration = 60;
        }

        $endDate = $startDate->copy()->addDays($duration - 1);

        return self::create([
            'patient_id' => $patientId,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'period_number' => $periodNumber
        ]);
    }
}
