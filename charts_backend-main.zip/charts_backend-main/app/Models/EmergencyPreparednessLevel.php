<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmergencyPreparednessLevel extends Model
{
    use HasFactory;
    protected $table = 'emergency_preparedness_level';
    protected $guarded = ['id'];
    public function patient()
    {
        return $this->hasMany(Patient::class, 'emergency_preparedness_level_id');
    }
}
