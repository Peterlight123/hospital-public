<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdmissionInformation extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    // protected $table = 'admission_information';
    public function patient()
    {
        return $this->belongsTo(Patient::class, 'patient_id');
    }
    public function siteOfService()
    {
        return $this->belongsTo(SiteOfService::class, 'site_of_service_id');
    }
    public function admittedForm()
    {
        return $this->belongsTo(AdmittedForm::class, 'admitted_form_id');
    }
}
