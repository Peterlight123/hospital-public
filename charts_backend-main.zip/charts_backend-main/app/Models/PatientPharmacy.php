<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PatientPharmacy extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $table = 'patient_pharmacies';
    /**
     * Get the patient associated with the patient pharmacy.
     */
    public function patient()
    {
        return $this->hasMany(Patient::class, 'patient_pharmacy_id');
    }
}
