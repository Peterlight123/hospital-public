<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PayerInformation extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $table = 'payer_informations';
    /**
     * Get the patient associated with the payer information.
     */
    public function patient()
    {
        return $this->belongsTo(Patient::class, 'patient_id');
    }
}
