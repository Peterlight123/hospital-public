<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdmittedForm extends Model
{
    use HasFactory;
    protected $table = 'admitted_form';
    protected $guarded = ['id'];
    public function AdmissionInformation()
    {
        return $this->hasMany(AdmissionInformation::class, 'admitted_form_id');
    }
}
