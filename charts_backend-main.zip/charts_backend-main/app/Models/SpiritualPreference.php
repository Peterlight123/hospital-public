<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SpiritualPreference extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $table = 'spiritual_preference';
    public function patient()
    {
        return $this->belongsTo(Patient::class, 'patient_id');
    }
}
