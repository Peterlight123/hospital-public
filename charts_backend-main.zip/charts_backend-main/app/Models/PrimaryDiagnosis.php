<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PrimaryDiagnosis extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $table = 'primary_diagnoses';
    /**
     * Get the patient associated with the primary diagnosis.
     */
    public function patient()
    {
        return $this->hasMany(Patient::class, 'primary_diagnosis_id');
    }
}
