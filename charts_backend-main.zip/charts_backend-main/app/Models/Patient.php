<?php

namespace App\Models;

use App\Models\BenefitPeriod;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Patient extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $table = 'patients';
    /**
     * Get the pharmacy associated with the patient.
     */
    public function patientPharmacy()
    {
        return $this->belongsTo(PatientPharmacy::class, 'patient_pharmacy_id');
    }
    /**
     * Get the primary diagnosis associated with the patient.
     */
    public function primaryDiagnosis()
    {
        return $this->belongsTo(PrimaryDiagnosis::class, 'primary_diagnosis_id');
    }
    /**
     * Get the race ethnicity associated with the patient.
     */
    public function raceEthnicity()
    {
        return $this->belongsTo(RaceEthnicity::class, 'race_ethnicity_id');
    }
    /**
     * Get the DME provider associated with the patient.
     */
    public function dmeProvider()
    {
        return $this->belongsTo(DmeProvider::class, 'dme_provider_id');
    }
    /**
     * Get the liaison primary associated with the patient.
     */
    public function liaisonPrimary()
    {
        return $this->belongsTo(LiaisonPrimary::class, 'liaison_primary_id');
    }
    /**
     * Get the liaison secondary associated with the patient.
     */
    public function liaisonSecondary()
    {
        return $this->belongsTo(LiaisonSecondary::class, 'liaison_secondary_id');
    }
    /**
     * Get the DNR associated with the patient.
     */
    public function dnr()
    {
        return $this->belongsTo(Dnr::class, 'dnr_id');
    }
    /**
     * Get the emergency preparedness level associated with the patient.
     */
    public function emergencyPreparednessLevel()
    {
        return $this->belongsTo(EmergencyPreparednessLevel::class, 'emergency_preparedness_level_id');
    }
    /**
     * Get the admission information associated with the patient.
     */
    public function admissionInformation()
    {
        return $this->hasMany(AdmissionInformation::class, 'patient_id');
    }
    /**
     * Get the address associated with the patient.
     */
    public function address()
    {
        return $this->hasMany(Address::class, 'patient_id');
    }
    /**
     * Get the payer information associated with the patient.
     */
    public function payerInformation()
    {
        return $this->hasMany(PayerInformation::class, 'patient_id');
    }
    /**
     * Get the visit information associated with the patient.
     */
    public function visitInformation()
    {
        return $this->hasMany(VisitInformation::class, 'patient_id');
    }
    /**
     * Get the cardiac assessment associated with the patient.
     */
    public function cardiac()
    {
        return $this->hasMany(CardiacAssessment::class, 'patient_id');
    }
    /**
     * Get the endocrine assessment associated with the patient.
     */
    public function endocrine()
    {
        return $this->hasMany(EndocrineAssessment::class, 'patient_id');
    }
    /**
     * Get the hematological assessment associated with the patient.
     */
    public function hematological()
    {
        return $this->hasMany(HematologicalAssessment::class, 'patient_id');
    }
    /**
     * Get the integumentary assessment associated with the patient.
     */
    public function integumentary()
    {
        return $this->hasMany(IntegumentaryAssessment::class, 'patient_id');
    }
    /**
     * Get the nutrition assessment associated with the patient.
     */
    public function nutritionAssessment()
    {
        return $this->hasMany(NutritionAssessment::class, 'patient_id');
    }
    /**
     * Get the living arrangements associated with the patient.
     */
    public function livingArrangements()
    {
        return $this->hasMany(LivingArrangements::class, 'patient_id');
    }
    /**
     * Get the spiritual preference associated with the patient.
     */
    public function spiritualPreference()
    {
        return $this->hasMany(SpiritualPreference::class, 'patient_id');
    }
    /**
     * Get the patient identifier associated with the patient.
     */
    public function patientIdentifier()
    {
        return $this->belongsTo(PatientIdentifier::class, 'patient_identifier_id');
    }
    /**
     * Get the discharge associated with the patient.
     */
    public function discharge()
    {
        return $this->hasMany(Discharge::class, 'patient_id');
    }
    /**
     * Get the pharmacy associated with the patient.
     */
    public function pharmacy()
    {
        return $this->belongsTo(PatientPharmacy::class, 'patient_pharmacy_id');
    }
    /**
     * Get the patient identifiers associated with the patient.
    */

    public function benefitPeriods()
    {
        return $this->hasMany(BenefitPeriod::class);
    }
     /**
     * Get the identifiers for the patient.
     */
    public function identifiers()
    {
        return $this->hasMany(PatientIdentifier::class);
    }
    /**
     * Get the pain assessment associated with the patient.
     */
    public function painAssessment()
    {
        return $this->hasMany(PainAssessment::class);
    }
    /**
     * Get the comprehensive pain assessment associated with the patient.
     */
    public function comprehensivePainAssessment()
    {
        return $this->hasMany(ComprehensivePainAssessment::class);
    }
    /**
     * Get the pain type associated with the patient.
     */
    public function painType()
    {
        return $this->hasMany(PainType::class);
    }
    /**
     * Get the pain level severity associated with the patient.
     */
    public function painLevelSeverity()
    {
        return $this->hasMany(PainLevelSeverity::class);
    }
    /**
     * Get the pain summary interventions goals associated with the patient.
     */
    public function painSummaryInterventionsGoals()
    {
        return $this->hasMany(PainSummaryInterventionsGoals::class);
    }
    
}
