<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ScaleToolLabData extends Model
{
    use HasFactory;

    protected $fillable = [
        'note_id',
        'mac',
        'mtc',
        'sleep_time',
        'fast',
        'nyha',
        'other_reading_1',
        'blood_sugar',
        'pt_inr',
        'other_reading_2',
        'other_reading_3',
        'other_reading_4',
    ];
}
