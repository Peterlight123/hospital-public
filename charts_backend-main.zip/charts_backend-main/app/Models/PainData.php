<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PainData extends Model
{
    use HasFactory;

    protected $fillable = [
        'note_id',
        'pain_level_now',
        'pain_right',
        'pain_left',
        'pain_acceptable_level',
        'pain_rated_by',
        'respiratory_rhythm',
        'pain_observations',
        'pain_duration',
        'pain_frequency',
        'pain_character',
        'worsened_by',
        'relieved_by',
        'effects_on_function',
        'current_pain_management',
        'breakthrough_pain',
        'additional_pain_information',
    ];

    protected $casts = [
        'pain_rated_by' => 'array',
        'pain_observations' => 'array',
        'pain_duration' => 'array',
        'pain_frequency' => 'array',
        'pain_character' => 'array',
        'worsened_by' => 'array',
        'relieved_by' => 'array',
        'effects_on_function' => 'array',
        'breakthrough_pain' => 'array',
    ];
}
