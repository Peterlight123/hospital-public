<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PrognosisPatient extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $table = 'prognosis_patient';
    // public function prognosis()
    // {
    //     return $this->hasMany(prognosis::class, 'prognosis_patient_id');
    // }
}
