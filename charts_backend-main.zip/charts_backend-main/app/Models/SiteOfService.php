<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SiteOfService extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $table = 'site_of_service';
    public function AdmissionInformation()
    {
        return $this->hasMany(AdmissionInformation::class, 'site_of_service_id');
    }
}
