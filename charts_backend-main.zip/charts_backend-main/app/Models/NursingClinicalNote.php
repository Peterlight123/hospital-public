<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NursingClinicalNote extends Model
{
    use HasFactory;

    // protected $fillable = [
    //     'benefit_period_id',
    //     'note_date',
    //     // 'note'
    //     'time_in',
    //     'time_out',
    //     'prn_visit',
    //     'patient_identifiers'
    // ];

    // protected $casts = [
    //     'prn_visit' => 'boolean',
    //     'patient_identifiers' => 'array',
    // ];

    // public function benefitPeriod()
    // {
    //     return $this->belongsTo(BenefitPeriod::class);
    // }

    protected $fillable = [
        // 'benefit_period_id',
        // 'note_date',
        'time_in',
        'time_out',
        'patient_name',
        'patient_number',
        'location_name',
        'benefit_period',
        'dob',
        'location_number',
        'prn_visit',
        'patient_identifiers'
    ];

    protected $casts = [
        'benefit_period' => 'array',
        'patient_identifiers' => 'array',
    ];

    public function benefitPeriod()
    {
        return $this->belongsTo(BenefitPeriod::class, 'benefit_period_id');
    }

}
