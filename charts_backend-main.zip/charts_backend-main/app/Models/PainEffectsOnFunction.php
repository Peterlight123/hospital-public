<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PainEffectsOnFunction extends Model
{
    use HasFactory;
    protected $table="pain_effects_on_function";
    protected $guarded = ['id'];
    public function patient()
    {
        return $this->belongsTo(Patient::class, 'patient_id');
    }
}
