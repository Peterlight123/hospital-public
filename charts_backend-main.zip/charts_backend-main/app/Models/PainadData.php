<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PainadData extends Model
{
    use HasFactory;
    protected $fillable = [
        'note_id',
        'pain_assessment_behavior',
        'pain_assessment_negative_vocalizations',
        'pain_assessment_facial_expression',
        'pain_assessment_body_language',
        'pain_consolability',
        'painad_total_score',
    ];
}
