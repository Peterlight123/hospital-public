<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PatientIdentifier extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $table = 'patient_identifiers';
    /**
     * Get the patient associated with the patient identifier.
     */ 
    public function patient()
    {
        return $this->hasMany(Patient::class, 'patient_identifier_id');
    }
}
