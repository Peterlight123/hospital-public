<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PainVitalSigns extends Model
{
    use HasFactory;
    protected $table="pain_vital_signs";
    protected $guarded = ['id'];
    public function patient()
    {
        return $this->belongsTo(Patient::class, 'patient_id');
    }
}
