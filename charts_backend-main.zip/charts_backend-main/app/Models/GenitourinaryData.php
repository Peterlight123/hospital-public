<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GenitourinaryData extends Model
{
    use HasFactory;

    protected $fillable = [
        'note_id',
        'absence_urinary_output',
        'decrease_urinary_output',
        'change_bladder_incontinence',
        'distension',
        'incontinence',
        'retention',
        'current_ss_infection', // This will be stored as JSON
        'indwelling_catheter_flush',
        'other_catheter',
        'no_deficit',
        'urinary_diversion_ostomy_ileal_conduit',
        'urinary_diversion_ostomy_nephrostomy',
        'urinary_diversion_ostomy_ureterostomy',
        'urinary_diversion_ostomy_other',
        'urinary_diversion_ostomy_suprapubic_catheter',
        'urinary_diversion_ostomy_condom_catheter',
        'flush',
        'size_balloon',
        'describe_deficits',
    ];
    

    protected $casts = [
        'absence_urinary_output' => 'boolean',
        'decrease_urinary_output' => 'boolean',
        'change_bladder_incontinence' => 'boolean',
        'distension' => 'boolean',
        'incontinence' => 'boolean',
        'retention' => 'boolean',
        'current_ss_infection' => 'array',
        'indwelling_catheter_flush' => 'boolean',
        'other_catheter' => 'boolean',
        'no_deficit' => 'boolean',
        'urinary_diversion_ostomy_ileal_conduit' => 'boolean',
        'urinary_diversion_ostomy_nephrostomy' => 'boolean',
        'urinary_diversion_ostomy_ureterostomy' => 'boolean',
        'urinary_diversion_ostomy_other' => 'boolean',
        'urinary_diversion_ostomy_suprapubic_catheter' => 'boolean',
        'urinary_diversion_ostomy_condom_catheter' => 'boolean',
    ];
}
