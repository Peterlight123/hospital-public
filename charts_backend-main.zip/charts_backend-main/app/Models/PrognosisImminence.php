<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PrognosisImminence extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $table = 'prognosis_imminence_of_death';
    // public function prognosis()
    // {
    //     return $this->hasMany(prognosis::class, 'prognosis_imminence_of_death_id');
    // }
}
