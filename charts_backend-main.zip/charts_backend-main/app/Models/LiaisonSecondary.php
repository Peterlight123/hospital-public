<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LiaisonSecondary extends Model
{
    use HasFactory;
    protected $table = 'liaison_secondary';
    protected $guarded = ['id'];
    public function patient()
    {
        return $this->hasMany(Patient::class, 'liaison_secondary_id');
    }
}
