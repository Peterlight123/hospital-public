<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RespiratoryData extends Model
{
    use HasFactory;

    protected $fillable = [
        'note_id',
        'clear',
        'diminished',
        'crackles',
        'rhonchi',
        'wheezing',
        'rales',
        'absent',
        'note',
        'breathing',
        'oxygen_use',
        'shortness_of_breath',
    ];

    protected $casts = [
        'clear' => 'array',
        'diminished' => 'array',
        'crackles' => 'array',
        'rhonchi' => 'array',
        'wheezing' => 'array',
        'rales' => 'array',
        'absent' => 'array',
        'breathing' => 'array',
        'oxygen_use' => 'array',
        'shortness_of_breath' => 'array',
    ];
}
