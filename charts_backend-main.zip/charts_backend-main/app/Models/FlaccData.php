<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FlaccData extends Model
{
    use HasFactory;

    protected $fillable = [
        'note_id',
        'flacc_face',
        'flacc_legs',
        'flacc_activity',
        'flacc_cry',
        'flacc_consolability',
        'total_score',
    ];
}
