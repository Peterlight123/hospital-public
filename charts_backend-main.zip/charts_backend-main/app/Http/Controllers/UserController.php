<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;


class UserController extends Controller
{
    public function index()
    {
        //$users = User::all();
        $users = User::with('roles')->get();
        return response()->json($users);
    }

     /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // public function store(Request $request)
    // {
    //     $user = new User;
    //     $user->name = $request->username;
    //     $user->email = $request->email;
    //     $user->password = Hash::make($request->password);
    //     $user->profil = $request->profil;
    //     $user->save();

    //     return response()->json($user);
    // }

    public function store(Request $request)
    {
        $user = new User;
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->contact = $request->contact;

        // Traitement de l'avatar
        if ($request->hasFile('avatar')) {
            $avatar = $request->file('avatar');
            $fileName = uniqid() . '.' . $avatar->getClientOriginalExtension(); // Utilisation de uniqid() pour générer un nom unique
            $avatar->storeAs('avatars', $fileName); // Stockage de l'avatar
            $user->avatar = $fileName;
        }

        // Attribution du rôle
        if ($request->has('role')) {
            $user->assignRole($request->role);
        }

        $user->save();

        return response()->json($user);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::findOrFail($id);
        $rolesString = $user->roles->pluck('name')->implode(', ');
        return response()->json([
            'user' => $user,
            'role' => $rolesString,
        ]);
    }
    
    

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function update(Request $request, $id)
    // {
    //     $user = User::findOrFail($id);
    //     $user->name = $request->name;
    //     $user->email = $request->email;
    //     $user->profil = $request->profil;

    //     if ($user->update()) {
    //         return response()->json($user);
    //     }
    // }

    public function update(Request $request, $id)
    {
        // Récupérer l'utilisateur à mettre à jour
        $user = User::findOrFail($id);
    
        // Stocker le rôle actuel de l'utilisateur
        $currentRole = $user->roles->first()->name;
    
        // Mettre à jour les champs modifiables
        $user->first_name = $request->input('first_name');
        $user->last_name = $request->input('last_name');
        $user->email = $request->input('email');
        $user->contact = $request->input('contact');
    
        // Vérifier si le mot de passe a été modifié
        if ($request->has('password')) {
            $user->password = Hash::make($request->input('password'));
        }
    
        // Traitement de l'avatar
        if ($request->hasFile('avatar')) {
            $avatar = $request->file('avatar');
            $fileName = uniqid() . '.' . $avatar->getClientOriginalExtension();
            $avatar->storeAs('avatars', $fileName);
            $user->avatar = $fileName;
        }
    
        // Vérifier si le champ du rôle est vide
        if ($request->filled('role')) {
            // Attribution du nouveau rôle
            $user->syncRoles([$request->input('role')]);
        } else {
            // Garder l'ancien rôle
            $user->syncRoles([$currentRole]);
        }
    
        // Sauvegarder les modifications
        $user->save();
    
        // Retourner la réponse JSON avec l'utilisateur mis à jour
        return response()->json($user);
    }
    
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();
        return response()->json(['message' => 'User deleted successfully']);
    }
}
