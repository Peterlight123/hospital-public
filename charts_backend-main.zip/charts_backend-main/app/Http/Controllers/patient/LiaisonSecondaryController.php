<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\LiaisonSecondary;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LiaisonSecondaryController extends Controller
{
    public function index()
    {
        $liaisonSecondary = LiaisonSecondary::all();
        return response()->json($liaisonSecondary);
    }

    public function store(Request $request)
    {
         // Validation des données de la requête
         $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:liaison_secondary,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        $liaisonSecondary = LiaisonSecondary::create([
            'name' => $request->name,
        ]);

        // Réponse JSON en cas de succès
        return response()->json([
                    'message' => 'Liaison secondary created successfully ',
                   'data' => $liaisonSecondary,
                 ], 200);
    }
    public function show($id)
    {
        try {
            $liaisonSecondary = LiaisonSecondary::findOrFail($id);
            return response()->json($liaisonSecondary);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No  Liaison secondary found'], 404);
        }
    }
    public function update(Request $request, $id)
    {
          // Validation des données de la requête
          $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:liaison_secondary,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        try {
            $liaisonSecondary =   LiaisonSecondary::findOrFail($id);
            $liaisonSecondary->update([
                'name' => $request->name,
            ]);
            // Réponse JSON en cas de succès
            return response()->json([
                        'message' => 'Liaison secondary update successfully ',
                       'data' => $liaisonSecondary,
                     ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No  Liaison secondary found.'], 404);
        }
    }

    public function destroy($id)
    {
        try {
    $liaisonSecondary = LiaisonSecondary::findOrFail($id);
    $liaisonSecondary->delete();
    return response()->json( ['message' => ' Liaison secondary delete successfully ']);
    //code...
} catch (ModelNotFoundException $e) {
    return response()->json(['error' => 'No  Liaison secondary found.'], 404);
}
    }
}
