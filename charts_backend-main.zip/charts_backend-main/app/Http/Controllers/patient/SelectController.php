<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\AdmittedForm;
use App\Models\NutritionProblemsType;
use App\Models\NutritionTemplate;
use App\Models\PrognosisCaregiver;
use App\Models\PrognosisImminence;
use App\Models\PrognosisPatient;
use App\Models\SiteOfService;
use Illuminate\Http\Request;

class SelectController extends Controller
{
    public function siteOfServiceList()
    {
        $SiteOfService = SiteOfService::all();
        return response()->json($SiteOfService);
    }
    public function admittedFormList()
    {
        $admittedForm = AdmittedForm::all();
        return response()->json($admittedForm);
    }
    public function prognosisPatientList()
    {
        $prognosisPatient = PrognosisPatient::all();
        return response()->json($prognosisPatient);
    }
    public function prognosisImminence()
    {
        $prognosisImminence = PrognosisImminence::all();
        return response()->json($prognosisImminence);
    }

    public function prognosisCaregiver()
    {
        $prognosisCaregiver = PrognosisCaregiver::all();
        return response()->json($prognosisCaregiver);
    }
    public function nutitionTemplate()
    {
        $nutritionTemplate = NutritionTemplate::all();
        return response()->json($nutritionTemplate);
    }
    public function nutitionProblem()
    {
        $nutritionProblemsType = NutritionProblemsType::all();
        return response()->json($nutritionProblemsType);
    }

}
