<?php

namespace App\Http\Controllers\patient\Pain;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Enums\Pain\PainBreakthrough;
use App\Enums\Pain\PainCharacter;
use App\Enums\Pain\PainFrequency;
use App\Enums\Pain\PainObservation;
use App\Enums\Pain\PainEffectsOnFunction;
use App\Enums\Pain\TypeOfPainRatingScaleUsed;
use App\Enums\Pain\PainRatedBy;
use App\Enums\Pain\PainWorsened;
use App\Enums\Pain\PainRelivedBy;
use App\Enums\Pain\PainDuration;
use App\Enums\painAssessmentInAdvanced\NegativeVocalization;
use App\Enums\painAssessmentInAdvanced\FacialExpression;
use App\Enums\painAssessmentInAdvanced\BodyLanguage;
use App\Enums\painAssessmentInAdvanced\Consolability;
use App\Enums\painAssessmentInAdvanced\Breathing;
use App\Enums\PainScreening\PainServerity;
use App\Enums\PainScreening\StandardizedPainTool;
use App\Enums\flaaccBehavioral\Activity;
use App\Enums\flaaccBehavioral\Cry;
use App\Enums\flaaccBehavioral\Face;
use App\Enums\flaaccBehavioral\Legs;
use App\Enums\flaaccBehavioral\FlaaccBehavioralConsolability;
use App\Enums\ComprehensinPain\ComprehensivePainIncluded;

class PainTypeController extends Controller
{
    public function PainBreakthrough()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => PainBreakthrough::toArray()
        ]);
    }

    public function PainCharacter()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => PainCharacter::toArray()
        ]);
    }

    public function PainFrequency()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => PainFrequency::toArray()
        ]);
    }

    public function PainObservation()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => PainObservation::toArray()
        ]);
    }

    public function PainEffectsOnFunction()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => PainEffectsOnFunction::toArray()
        ]);
    }

    public function TypeOfPainRatingScaleUsed()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => TypeOfPainRatingScaleUsed::toArray()
        ]);
    }

    public function PainRatedBy()
    {
        return response()->json([
            'status' => 200,
            'data' => PainRatedBy::toArray()
        ]);
    }

    public function PainWorsened()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => PainWorsened::toArray()
        ]);
    }

    public function PainRelivedBy()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => PainRelivedBy::toArray()
        ]);
    }

    public function PainDuration()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => PainDuration::toArray()
        ]);
    }

    public function NegativeVocalization()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => NegativeVocalization::toArray()
        ]);
    }

    public function FacialExpression()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => FacialExpression::toArray()
        ]);
    }

    public function BodyLanguage()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => BodyLanguage::toArray()
        ]);
    }

    public function Consolability()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => Consolability::toArray()
        ]);
    }

    public function Breathing()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => Breathing::toArray()
        ]);
    }

    public function ComprehensivePainIncluded()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => ComprehensivePainIncluded::toArray()
        ]);
    }

    public function Activity()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => Activity::toArray()
        ]);
    }

    public function Cry()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => Cry::toArray()
        ]);
    }

    public function FlaaccBehavioralConsolability()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => FlaaccBehavioralConsolability::toArray()
        ]);
    }

    public function Face()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => Face::toArray()
        ]);
    }

    public function Legs()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => Legs::toArray()
        ]);
    }

    public function PainServerity()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => PainServerity::toArray()
        ]);
    }

    public function StandardizedPainTool()
    {
        return response()->json([
            'status' => 200,
            'message' => 'Pain type retrieved successfully',
            'data' => StandardizedPainTool::toArray()
        ]);
    }

}
