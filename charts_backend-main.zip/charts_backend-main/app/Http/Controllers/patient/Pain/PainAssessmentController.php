<?php

namespace App\Http\Controllers\patient\Pain;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\PainAssessment;
use App\Models\PainRatedBy;
use App\Models\PainDuration;
use App\Models\PainFrequency;
use App\Models\PainWorsenedBy;
use App\Models\PainCharacter;
use App\Models\PainRelievedBy;
use App\Models\PainEffectsOnFunction;
use App\Models\PainBreakthrough;
use App\Models\TypeOfPainRatingScaleUsed;
use App\Models\PainObservations;
use App\Models\PainVitalSigns;
use App\Models\painScalesToolsLabDataReviews;
use App\Models\PainAssessmentInDementiaScale;
use App\Models\FlaccBehavioralPain;
use App\Models\PainScreening;
use App\Models\PainSummaryInterventionsGoals;
use App\Models\ComprehensivePainAssessment;
use App\Models\PainActiveProblem;

use Illuminate\Database\Eloquent\ModelNotFoundException;
class PainAssessmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $painAssessments = PainAssessment::all();
        return response()->json([
            'message' => 'Pain assessments retrieved successfully',
            'data' => $painAssessments
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function painLevelSeveritystore(Request $request)
    {
        // Validate request data
        // Example JSON request body:
        /*
        {
            "patient_id": 123,
            "pain_level_now": 5,
            "acceptable_level_of_pain": 3,
            "worst_pain_level": 8,
            "primary_pain_site": "Lower back",
            "pain_rated_by_id": ["self", "nurse"],
            "type_of_pain_rating_scale_used_id": ["numeric", "faces"],
            "pain_duration_id": ["chronic"],
            "pain_frequency_id": ["constant"],
            "pain_observations_id": ["grimacing", "guarding"],
            "pain_worsened_by_id": ["movement", "sitting"],
            "pain_character_id": ["aching", "sharp"],
            "pain_relieved_by_id": ["rest", "medication"],
            "pain_effects_on_function_id": ["sleep", "mobility"],
            "pain_breakthrough_id": ["yes"]
        }
        */
        
        $validated = $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'pain_level_now' => 'nullable|integer|min:0|max:10',
            'acceptable_level_of_pain' => 'nullable|integer|min:0|max:10',
            'worst_pain_level' => 'nullable|integer|min:0|max:10',
            'primary_pain_site' => 'nullable|string|max:255'
        ]);
        // Convert array fields to JSON strings
       

        // Check if patient already has a pain assessment
        $painAssessment = PainAssessment::where('patient_id', $validated['patient_id'])->first();

       

        if ($painAssessment) {
            // Update existing record
            
            $painAssessment->update($validated);
        } else {
            // Create new record
            $painAssessment = PainAssessment::create($validated);
        }

        return response()->json([
            'message' => 'Pain assessment created successfully',
            'data' => $painAssessment
        ], 201);
    }
    public function painRatedByStore(Request $request)
    {
            // Valider les données entrantes
            $validatedData = $request->validate([
                'patient_id' => 'required',
                'pain_rated_by_id' => 'required',
            ]);

            $painRatedBy = PainRatedBy::where('patient_id', $validatedData['patient_id'])->first();

            if ($painRatedBy) {
                // Vérifier et ajouter les champs non vides
                if (!empty($validatedData['pain_rated_by_id'])) {
                    $updateData['pain_rated_by_id'] = implode(',', $validatedData['pain_rated_by_id']);
                }
                $painRatedBy->update($updateData);
            } else {
                // Créer de nouvelles données
                $createData = [
                    'patient_id' => $validatedData['patient_id'],
                ];

                // Vérifier et ajouter les champs non vides
                if (!empty($validatedData['pain_rated_by_id'])) {
                    $createData['pain_rated_by_id'] = implode(',', $validatedData['pain_rated_by_id']);
                }
                $painRatedBy = PainRatedBy::create($createData);
            }

            // Réponse JSON en cas de succès
            return response()->json([
                'message' => 'painRatedBy créé ou mis à jour avec succès.',
                'data' => $painRatedBy,
            ], 201);
    }
    public function painRatedById($id)
    {
        try {
            // Recherchez les informations de visite correspondant à l'ID du patient
            $painRatedBy = PainRatedBy::where('patient_id', $id)->firstOrFail();
            return response()->json($painRatedBy);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No painRatedBy found for this painRatedBy'], 404);
        }
    }

    public function painDurationStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'pain_duration_id' => 'required',
        ]);
        $painDuration = PainDuration::where('patient_id', $validatedData['patient_id'])->first();
        if ($painDuration) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_duration_id'])) {
                $updateData['pain_duration_id'] = implode(',', $validatedData['pain_duration_id']);
            }
            $painDuration->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];

            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_duration_id'])) {
                $createData['pain_duration_id'] = implode(',', $validatedData['pain_duration_id']);
            }
            $painDuration = PainDuration::create($createData);
        }
        return response()->json($painDuration);
    }

    public function painDurationById($id)
    {
        try {
            $painDuration = PainDuration::where('patient_id', $id)->firstOrFail();
            return response()->json($painDuration);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No painDuration found for this painDuration'], 404);
        }
    }
    public function painFrequencyStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'pain_frequency_id' => 'required',
        ]);
        $painFrequency = PainFrequency::where('patient_id', $validatedData['patient_id'])->first();
        if ($painFrequency) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_frequency_id'])) {
                $updateData['pain_frequency_id'] = implode(',', $validatedData['pain_frequency_id']);
            }
            $painFrequency->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];

            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_frequency_id'])) {
                $createData['pain_frequency_id'] = implode(',', $validatedData['pain_frequency_id']);
            }
            $painFrequency = PainFrequency::create($createData);
        }
        return response()->json($painFrequency);
    }
    public function painFrequencyById($id)
    {
        try {
            $painFrequency = PainFrequency::where('patient_id', $id)->firstOrFail();
            return response()->json($painFrequency);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No painFrequency found for this painFrequency'], 404);
        }
    }
    public function painObservationStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'pain_observations_id' => 'required',
        ]); 
        $painObservation = PainObservations::where('patient_id', $validatedData['patient_id'])->first();
        if ($painObservation) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_observations_id'])) {
                $updateData['pain_observations_id'] = implode(',', $validatedData['pain_observations_id']);
            }
            $painObservation->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];

            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_observations_id'])) {
                $createData['pain_observations_id'] = implode(',', $validatedData['pain_observations_id']);
            }
            $painObservation = PainObservations::create($createData);
        }
        return response()->json($painObservation);
    }
    public function painObservationById($id)
    {
        try {
            $painObservation = PainObservations::where('patient_id', $id)->firstOrFail();
            return response()->json($painObservation);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No painObservation found for this painObservation'], 404);
        }
    }   

    public function painWorsenedByStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'pain_worsened_by_id' => 'required',
        ]);
        $painWorsenedBy = PainWorsenedBy::where('patient_id', $validatedData['patient_id'])->first();
        if ($painWorsenedBy) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_worsened_by_id'])) {
                $updateData['pain_worsened_by_id'] = implode(',', $validatedData['pain_worsened_by_id']);
            }
            $painWorsenedBy->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];

            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_worsened_by_id'])) {
                $createData['pain_worsened_by_id'] = implode(',', $validatedData['pain_worsened_by_id']);
            }
            $painWorsenedBy = PainWorsenedBy::create($createData);
        }
        return response()->json($painWorsenedBy);
    }
    public function painWorsenedById($id)
    {
        try {
            $painWorsenedBy = PainWorsenedBy::where('patient_id', $id)->firstOrFail();
            return response()->json($painWorsenedBy);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No painWorsenedBy found for this painWorsenedBy'], 404);
        }
    }

    public function painCharacterStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'pain_character_id' => 'required',
        ]);
        $painCharacter = PainCharacter::where('patient_id', $validatedData['patient_id'])->first();
        if ($painCharacter) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_character_id'])) {
                $updateData['pain_character_id'] = implode(',', $validatedData['pain_character_id']);
            }
                $painCharacter->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];

            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_character_id'])) {
                $createData['pain_character_id'] = implode(',', $validatedData['pain_character_id']);
            }
            $painCharacter = PainCharacter::create($createData);
        }
        return response()->json($painCharacter);
    }
    public function painCharacterById($id)
    {
        try {
            $painCharacter = PainCharacter::where('patient_id', $id)->firstOrFail();
            return response()->json($painCharacter);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No painCharacter found for this painCharacter'], 404);
        }
    }
    public function painRelievedByStore(Request $request)
    {   
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'pain_relieved_by_id' => 'required',
        ]);
        $painRelievedBy = PainRelievedBy::where('patient_id', $validatedData['patient_id'])->first();
        if ($painRelievedBy) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_relieved_by_id'])) {
                $updateData['pain_relieved_by_id'] = implode(',', $validatedData['pain_relieved_by_id']);
            }
            $painRelievedBy->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];

            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_relieved_by_id'])) {
                $createData['pain_relieved_by_id'] = implode(',', $validatedData['pain_relieved_by_id']);
            }
                $painRelievedBy = PainRelievedBy::create($createData);
        }
        return response()->json($painRelievedBy);
    }
    public function painRelievedById($id)
    {
        try {
            $painRelievedBy = PainRelievedBy::where('patient_id', $id)->firstOrFail();
            return response()->json($painRelievedBy);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No painRelievedBy found for this painRelievedBy'], 404);
        }
    }

    public function painEffectsOnFunctionStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'pain_effects_on_function_id' => 'required',
        ]); 
        $painEffectsOnFunction = PainEffectsOnFunction::where('patient_id', $validatedData['patient_id'])->first();
        if ($painEffectsOnFunction) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_effects_on_function_id'])) {
                $updateData['pain_effects_on_function_id'] = implode(',', $validatedData['pain_effects_on_function_id']);
            }
            $painEffectsOnFunction->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];

            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_effects_on_function_id'])) {
                $createData['pain_effects_on_function_id'] = implode(',', $validatedData['pain_effects_on_function_id']);
            }
            $painEffectsOnFunction = PainEffectsOnFunction::create($createData);
        }
        return response()->json($painEffectsOnFunction);
    }
    public function painEffectsOnFunctionById($id)
    {
        try {
            $painEffectsOnFunction = PainEffectsOnFunction::where('patient_id', $id)->firstOrFail();
            return response()->json($painEffectsOnFunction);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No painEffectsOnFunction found for this painEffectsOnFunction'], 404);
        }
    }

    public function painBreakthroughStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'pain_breakthrough_id' => 'required',
        ]); 
        $painBreakthrough = PainBreakthrough::where('patient_id', $validatedData['patient_id'])->first();
        if ($painBreakthrough) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_breakthrough_id'])) {
                $updateData['pain_breakthrough_id'] = implode(',', $validatedData['pain_breakthrough_id']);
            }
            $painBreakthrough->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];

            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['pain_breakthrough_id'])) {
                $createData['pain_breakthrough_id'] = implode(',', $validatedData['pain_breakthrough_id']);
            }
            $painBreakthrough = PainBreakthrough::create($createData);
        }
        return response()->json($painBreakthrough);
    }
    public function painBreakthroughById($id)
    {
        try {
            $painBreakthrough = PainBreakthrough::where('patient_id', $id)->firstOrFail();
            return response()->json($painBreakthrough);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No painBreakthrough found for this painBreakthrough'], 404);
        }
    }

    public function typeOfPainRatingScaleUsedStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'type_of_pain_rating_scale_used_id' => 'required',
        ]); 
        $typeOfPainRatingScaleUsed = TypeOfPainRatingScaleUsed::where('patient_id', $validatedData['patient_id'])->first();
        if ($typeOfPainRatingScaleUsed) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['type_of_pain_rating_scale_used_id'])) {
                $updateData['type_of_pain_rating_scale_used_id'] = implode(',', $validatedData['type_of_pain_rating_scale_used_id']);
            }
            $typeOfPainRatingScaleUsed->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];

            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['type_of_pain_rating_scale_used_id'])) {
                $createData['type_of_pain_rating_scale_used_id'] = implode(',', $validatedData['type_of_pain_rating_scale_used_id']);
            }
            $typeOfPainRatingScaleUsed = TypeOfPainRatingScaleUsed::create($createData);
        }
        return response()->json($typeOfPainRatingScaleUsed);
    }   
    public function typeOfPainRatingScaleUsedById($id)
    {
        try {
            $typeOfPainRatingScaleUsed = TypeOfPainRatingScaleUsed::where('patient_id', $id)->firstOrFail();
            return response()->json($typeOfPainRatingScaleUsed);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No typeOfPainRatingScaleUsed found for this typeOfPainRatingScaleUsed'], 404);
        }
    }

    public function painScalesToolsLabDataReviewsStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'mid_arm_circumference' => 'nullable',
            'mid_thigh_circumference' => 'nullable',
            'sleep_hours' => 'nullable',
            'fast' => 'nullable',
            'nyha' => 'nullable',
            'pps' => 'nullable',
            'blood_sugar' => 'nullable',
            'pt_inr' => 'nullable',
            'other_reading_2' => 'nullable',
            'other_reading_3' => 'nullable',
            'other_reading_4' => 'nullable',
        ]); 
        $painScalesToolsLabDataReviews = PainScalesToolsLabDataReviews::where('patient_id', $validatedData['patient_id'])->first();
        if ($painScalesToolsLabDataReviews) {
            $painScalesToolsLabDataReviews->update($validatedData);
        } else {
            $painScalesToolsLabDataReviews = PainScalesToolsLabDataReviews::create($validatedData);
        }
        return response()->json($painScalesToolsLabDataReviews);
    }   

    public function painScalesToolsLabDataReviewsById($id)
    {
        try {
            $painScalesToolsLabDataReviews = PainScalesToolsLabDataReviews::where('patient_id', $id)->firstOrFail();
            return response()->json($painScalesToolsLabDataReviews);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No painScalesToolsLabDataReviews found for this painScalesToolsLabDataReviews'], 404);
        }
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try {
            $painAssessment = PainAssessment::where('patient_id', $id)->firstOrFail();
            return response()->json($painAssessment);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No pain assessment found for this patient'], 404);
        }
    }


    public function painVitalSignsStore(Request $request)
    {

        $validatedData = $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'temperature_fahrenheit' => 'nullable',
            'temperature_method' => 'nullable',
            'heart_rate' => 'nullable',
            'heart_rhythm' => 'nullable',
            'heart_rate_location' => 'nullable',
            'respiratory_rate' => 'nullable',
            'respiratory_rhythm' => 'nullable',
            'blood_pressure_systolic' => 'nullable',
            'blood_pressure_diastolic' => 'nullable',
            'bp_location' => 'nullable',
            'bp_position' => 'nullable',
            'bp_additional_details' => 'nullable',
            'pulse_oximetry' => 'nullable',
            'pulse_ox_location' => 'nullable',
            'pulse_ox_other_location' => 'nullable',
            'bmi' => 'nullable',
            'bmi_percentile' => 'nullable',
            'body_height_inches' => 'nullable',
            'body_weight_lbs' => 'nullable',
            'body_weight_kg' => 'nullable',
            'weight_source' => 'nullable',
        ]); 

        // Check if patient already has pain vital signs
        $painVitalSigns = PainVitalSigns::where('patient_id', $validatedData['patient_id'])->first();

        if ($painVitalSigns) {
            // Update existing record
            $painVitalSigns->update($validatedData);
            return response()->json([
                'message' => 'Pain vital signs updated successfully',
                'data' => $painVitalSigns
            ], 200);
        } else {
            // Create new record
            $painVitalSigns = PainVitalSigns::create($validatedData);
            return response()->json([
                'message' => 'Pain vital signs created successfully', 
                'data' => $painVitalSigns
            ], 201);
        }
    }

    public function painVitalSignsById($id)
    {
        try {
            $painVitalSigns = PainVitalSigns::where('patient_id', $id)->firstOrFail();
            return response()->json($painVitalSigns);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No pain vital signs found for this patient'], 404);
        }
    }

    public function painAssessmentInDementiaScaleStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'breathing' => 'nullable',
            'vocalization' => 'nullable',
            'facial_expression' => 'nullable',
            'body_language' => 'nullable',
            'consolability' => 'nullable',
            'total_score' => 'nullable',
        ]); 
        $painAssessmentInDementiaScale = PainAssessmentInDementiaScale::where('patient_id', $validatedData['patient_id'])->first();
        if ($painAssessmentInDementiaScale) {
            $painAssessmentInDementiaScale->update($validatedData);
        } else {
            $painAssessmentInDementiaScale = PainAssessmentInDementiaScale::create($validatedData);
        }
        return response()->json($painAssessmentInDementiaScale);
    }

    public function painAssessmentInDementiaScaleById($id)
    {
        try {
            $painAssessmentInDementiaScale = PainAssessmentInDementiaScale::where('patient_id', $id)->firstOrFail();
            return response()->json($painAssessmentInDementiaScale);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No pain assessment in dementia scale found for this patient'], 404);
        }
    }

    public function flaccBehavioralPainStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'face' => 'nullable',
            'legs' => 'nullable',
            'activity' => 'nullable',
            'cry' => 'nullable',
            'consolability' => 'nullable',
        ]); 
        $flaccBehavioralPain = FlaccBehavioralPain::where('patient_id', $validatedData['patient_id'])->first();
        if ($flaccBehavioralPain) {
            $flaccBehavioralPain->update($validatedData);
        } else {
            $flaccBehavioralPain = FlaccBehavioralPain::create($validatedData);
        }
        return response()->json($flaccBehavioralPain);
    }

    public function flaccBehavioralPainById($id)
    {
        try {
            $flaccBehavioralPain = FlaccBehavioralPain::where('patient_id', $id)->firstOrFail();
            return response()->json($flaccBehavioralPain);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No flacc behavioral pain found for this patient'], 404);
        }
    }
   
    public function painScreeningStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'patient_screened' => 'nullable',
            'date_of_first_pain' => 'nullable',
            'pain_severity' => 'nullable',
            'standardized_tool_pain_used' => 'nullable',
        ]); 
        $painScreening = PainScreening::where('patient_id', $validatedData['patient_id'])->first();
        if ($painScreening) {
            $painScreening->update($validatedData);
        } else {
            $painScreening = PainScreening::create($validatedData);
        }
        return response()->json($painScreening);
    }

    public function painScreeningById($id)
    {
        try {
            $painScreening = PainScreening::where('patient_id', $id)->firstOrFail();
            return response()->json($painScreening);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No pain screening found for this patient'], 404);
        }
    }   

    public function painSummaryInterventionsGoalsStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'summary_of_problem' => 'nullable',
            'pain_interventions_administer_medication' => 'nullable',
            'pain_interventions_administer_medication_start_date' => 'nullable|date',
            'pain_interventions_assess_effectiveness' => 'nullable|date',
            'pain_interventions_assess_effectiveness_start_date' => 'nullable',
            'pain_interventions_assess_pain_status' => 'nullable',
            'pain_interventions_assess_pain_status_start_date' => 'nullable',
            'pain_interventions_non_pharmacological' => 'nullable',
            'pain_interventions_non_pharmacological_start_date' => 'nullable',
            'pain_goals_caregiver' => 'nullable',
            'pain_goals_rating' => 'nullable',
            'pain_goals_start_date' => 'nullable|date',
            'pain_goals_end_date' => 'nullable|date',
            'pain_caregiver_discussion_methods' => 'nullable',
            'pain_achive_by_date' => 'nullable',
            'pain_achive_by_date_start_date' => 'nullable',

        ]); 
        $painSummaryInterventionsGoals = PainSummaryInterventionsGoals::where('patient_id', $validatedData['patient_id'])->first();
        if ($painSummaryInterventionsGoals) {
            $painSummaryInterventionsGoals->update($validatedData);
        } else {
            $painSummaryInterventionsGoals = PainSummaryInterventionsGoals::create($validatedData);
        }
        return response()->json($painSummaryInterventionsGoals);
    }

    public function painSummaryInterventionsGoalsById($id)
    {
        try {
            $painSummaryInterventionsGoals = PainSummaryInterventionsGoals::where('patient_id', $id)->firstOrFail();
            return response()->json($painSummaryInterventionsGoals);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No pain summary interventions goals found for this patient'], 404);
        }
    }

    public function comprehensivePainAssessmentStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'comprehensive_pain' => 'nullable|integer|max:255',
            'date_of_assessment' => 'nullable|date',
            'comprehensive_pain_included' => 'nullable',
            'comments' => 'nullable|string'

        ]); 
        $comprehensivePainAssessment = ComprehensivePainAssessment::where('patient_id', $validatedData['patient_id'])->first();
        if ($comprehensivePainAssessment) {
            $updateData = [
                'comprehensive_pain' => $validatedData['comprehensive_pain'],
                'date_of_assessment' => $validatedData['date_of_assessment'],
                'comments' => $validatedData['comments']
            ];
            if (!empty($validatedData['comprehensive_pain_included']) && is_array($validatedData['comprehensive_pain_included'])) {
                $updateData['comprehensive_pain_included'] = implode(',', $validatedData['comprehensive_pain_included']);
            } else {
                $updateData['comprehensive_pain_included'] = $validatedData['comprehensive_pain_included'];
            }
            $comprehensivePainAssessment->update($updateData);
        } else {
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];
            if (!empty($validatedData['comprehensive_pain_included'])) {
                $createData['comprehensive_pain_included'] = implode(',', $validatedData['comprehensive_pain_included']);
            }
            $comprehensivePainAssessment = ComprehensivePainAssessment::create($createData);
        }
        return response()->json($comprehensivePainAssessment);
    }

    public function comprehensivePainAssessmentById($id)
    {
        try {
            $comprehensivePainAssessment = ComprehensivePainAssessment::where('patient_id', $id)->firstOrFail();
            return response()->json($comprehensivePainAssessment);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No comprehensive pain assessment found for this patient'], 404);
        }
    }

    public function painActiveProblemStore(Request $request)
    {
        $validatedData = $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'pain_active_problem_patient' => 'nullable',
            'comments' => 'nullable',
        ]); 
        $painActiveProblem = PainActiveProblem::where('patient_id', $validatedData['patient_id'])->first();
        if ($painActiveProblem) {
            $painActiveProblem->update($validatedData);
        } else {
            $painActiveProblem = PainActiveProblem::create($validatedData);
        }
        return response()->json($painActiveProblem);
    }

    public function painActiveProblemById($id)
    {
        try {
            $painActiveProblem = PainActiveProblem::where('patient_id', $id)->firstOrFail();
            return response()->json($painActiveProblem);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No pain active problem found for this patient'], 404);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
