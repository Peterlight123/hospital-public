<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\PrimaryDiagnosis;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PrimaryDiagnosisController extends Controller
{
    public function index()
    {
        $primaryDiagnosis = PrimaryDiagnosis::all();
        return response()->json($primaryDiagnosis);
    }

    public function store(Request $request)
    {
         // Validation des données de la requête
         $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:primary_diagnoses,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        $primaryDiagnosis = PrimaryDiagnosis::create([
            'name' => $request->name,
        ]);

        // Réponse JSON en cas de succès
        return response()->json([
                    'message' => 'primary diagnonsis created successfully ',
                   'data' => $primaryDiagnosis,
                 ], 200);
    }
    public function show($id)
    {
        try {
            $primaryDiagnosis = PrimaryDiagnosis::findOrFail($id);
            return response()->json($primaryDiagnosis);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No primary diagnonsis found.'], 404);
        }
    }
    public function update(Request $request, $id)
    {
          // Validation des données de la requête
          $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:primary_diagnosis,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        try {
            $primaryDiagnosis =   PrimaryDiagnosis::findOrFail($id);
            $primaryDiagnosis->update([
                'name' => $request->name,
            ]);
            // Réponse JSON en cas de succès
            return response()->json([
                        'message' => 'primary diagnonsis update successfully ',
                       'data' => $primaryDiagnosis,
                     ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No found.'], 404);
        }
    }

    public function destroy($id)
    {
        try {
    $primaryDiagnosis = PrimaryDiagnosis::findOrFail($id);
    $primaryDiagnosis->delete();
    return response()->json( ['message' => 'primary diagnonsis delete successfully ']);
    //code...
} catch (ModelNotFoundException $e) {
    return response()->json(['error' => 'No primary diagnonsis found '], 404);
}
    }
}
