<?php
namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;

use App\Models\DmeProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class DmeProviderController extends Controller
{
    public function index()
    {
        $dmeProvider = DmeProvider::all();
        return response()->json($dmeProvider);
    }

    public function store(Request $request)
    {
         // Validation des données de la requête
         $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:dme_providers,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        $dmeProvider = DmeProvider::create([
            'name' => $request->name,
        ]);

        // Réponse JSON en cas de succès
        return response()->json([
                    'message' => 'dme providers created successfully ',
                   'data' => $dmeProvider,
                 ], 200);
    }
    public function show($id)
    {
        try {
            $dmeProvider = DmeProvider::findOrFail($id);
            return response()->json($dmeProvider);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No DME Provider found with the provided ID.'], 404);
        }
    }
    public function update(Request $request, $id)
    {
          // Validation des données de la requête
          $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:dme_providers,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        try {
            $dmeProvider =   DmeProvider::findOrFail($id);
            $dmeProvider->update([
                'name' => $request->name,
            ]);
            // Réponse JSON en cas de succès
            return response()->json([
                        'message' => 'dme providers update successfully ',
                       'data' => $dmeProvider,
                     ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No DME Provider found with the provided ID.'], 404);
        }
    }

    public function destroy($id)
    {
        try {
    $dmeProvider = DmeProvider::findOrFail($id);
    $dmeProvider->delete();
    return response()->json( ['message' => 'dme providers delete successfully ']);
    //code...
} catch (ModelNotFoundException $e) {
    return response()->json(['error' => 'No DME Provider found with the provided ID.'], 404);
}
    }
}
