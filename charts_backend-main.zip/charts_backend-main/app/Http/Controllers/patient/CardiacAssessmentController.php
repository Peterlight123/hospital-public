<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\Cardiac;
use App\Models\CardiacAssessment;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class CardiacAssessmentController extends Controller
{
    public function index()
    {
        $cardiac = CardiacAssessment::all();
        return response()->json($cardiac);
    }
    public function cardiacList()
    {
        $cardiac = Cardiac::all();
        return response()->json($cardiac);
    }
    public function store(Request $request)
    {
        // Valider les données entrantes
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'cardiac_ids' => 'required',
        ]);

        $cardiac = CardiacAssessment::where('patient_id', $validatedData['patient_id'])->first();

        if ($cardiac) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['cardiac_ids'])) {
                $updateData['cardiac_ids'] = implode(',', $validatedData['cardiac_ids']);
            }
            $cardiac->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];

            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['cardiac_ids'])) {
                $createData['cardiac_ids'] = implode(',', $validatedData['cardiac_ids']);
            }
            $cardiac = CardiacAssessment::create($createData);
        }

        // Réponse JSON en cas de succès
        return response()->json([
            'message' => 'cardiac créé ou mis à jour avec succès.',
            'data' => $cardiac,
        ], 201);
    }

    public function show($id)
    {
        try {
            // Recherchez les informations de visite correspondant à l'ID du patient
            $cardiac = CardiacAssessment::where('patient_id', $id)->firstOrFail();
            return response()->json($cardiac);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No cardiac found for this cardiac'], 404);
        }
    }
}
