<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\Dnr;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DnrController extends Controller
{
    public function index()
    {
        $dnr = Dnr::all();
        return response()->json($dnr);
    }

    public function store(Request $request)
    {
         // Validation des données de la requête
         $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:dnr,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        $dnr = Dnr::create([
            'name' => $request->name,
        ]);

        // Réponse JSON en cas de succès
        return response()->json([
                    'message' => 'dnr created successfully ',
                   'data' => $dnr,
                 ], 200);
    }
    public function show($id)
    {
        try {
            $dnr = Dnr::findOrFail($id);
            return response()->json($dnr);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No  dnr found'], 404);
        }
    }
    public function update(Request $request, $id)
    {
          // Validation des données de la requête
          $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:dnr,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        try {
            $dnr =   Dnr::findOrFail($id);
            $dnr->update([
                'name' => $request->name,
            ]);
            // Réponse JSON en cas de succès
            return response()->json([
                        'message' => 'dnr update successfully ',
                       'data' => $dnr,
                     ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No  dnr found.'], 404);
        }
    }

    public function destroy($id)
    {
        try {
    $dnr = Dnr::findOrFail($id);
    $dnr->delete();
    return response()->json( ['message' => ' dnr delete successfully ']);
    //code...
} catch (ModelNotFoundException $e) {
    return response()->json(['error' => 'No  dnr found.'], 404);
}
    }
}

