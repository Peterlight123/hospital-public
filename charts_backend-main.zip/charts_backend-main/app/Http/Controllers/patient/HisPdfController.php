<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Log;

class HisPdfController extends Controller
{
    public function generatePdf(Request $request)
    {
        try {
            Log::info('API generate-pdf called');

            // HTML content for Visit Information
            $visitInformationHtml = '
            <div class="container">
                <div class="header">
                    <h2>Visit Information</h2>
                </div>
                <table>
                    <tr>
                        <th>Visit Date <span style="color:red">*</span></th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Visit Time In <span style="color:red">*</span></th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Visit Time Out <span style="color:red">*</span></th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Travel Time In</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Travel Time Out</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Documention Time Minutes</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Associated Mileage</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Surcharge</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                </table>
            </div>';


            // HTML content for Demographics
            $demographicsHtml = '
            <div class="container">
                <div class="header">
                    <h2>Demographics</h2>
                </div>
                <table>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0500A</span> First Name <span style="color:red">*</span></th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0500B</span> MI</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0500C</span> Last Name</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0900</span> Date of Birth</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0800</span> Gender</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0500D</span> Suffix</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Marital Status</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0100</span> Race / Ethnicity</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Address Line 1</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Address Line 2</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>City</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>State</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0550</span> ZIP Code</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Primary Phone Number</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Alternate Phone Number</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                </table>
            </div>';

            // HTML content for Admission Information
            $admissionInformationHtml = '
            <div class="container">
                <div class="header">
                    <h2>Admission Information</h2>
                </div>
                <table>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0220</span> Admission Date</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0245</span> Date Initial Nursing Assessment Initiated</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0205</span> Site of Service at Admission</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A1802</span> Admitted From (Immediately preceding this admission, where was the patient?)</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                </table>
            </div>';

            // HTML content for Payer Information
            $payerInformationHtml = '
            <div class="container">
                <div class="header">
                    <h2>Payer Information</h2>
                </div>
                <table>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0600A</span> Social Security Number</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0600B</span> Medicare Beneficiary Identification</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A0700</span> Medicaid Number</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Medicaid Recipient</th>
                        <td>
                            <div class="form-check"><input type="radio" name="medicaid_recipient" value="0"> Not a Medicaid Recipient</div>
                            <div class="form-check"><input type="radio" name="medicaid_recipient" value="1"> Medicaid Number is Pending</div>
                        </td>
                    </tr>
                    <tr>
                        <th><span style="background:#36B1749F;border-radius:4px;color:#fff">A1400</span> Payer Information</th>
                        <td>
                            <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                </table>
            </div>';

            // HTML content for Vital Signs/Additional Measurements
            $vitalSignsHtml = '
            <div class="container">
                <div class="header">
                    <h2>Vital Signs/Additional Measurements</h2>
                </div>
                <table>
                    <tr>
                        <th>Temperature</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>Scale</th>
                        <td>
                        <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Route</th>
                        <td>
                        <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>O2 Saturation (%)</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>Method</th>
                        <td>
                        <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Pulse Rate (/min)</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>Location</th>
                        <td>
                        <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Respiration(/min)</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>Blood Pressure (mmHg)</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>Position</th>
                        <td>
                        <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Mid-Arm Circumference (cm)</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>Arm</th>
                        <td>
                        <span class="dotted-line">..........................</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Weight</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>Scales</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>Height</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>Scales</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>BMI</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>Abdominal Girth (cm)</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>FAST</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>NYHA</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                    <tr>
                        <th>PPS Score</th>
                        <td><span class="dotted-line">..........................</span></td>
                    </tr>
                </table>
            </div>';


            $diagnosisHtml = '
            <!-- Diagnosis Section -->
            <div class="container">
                <div class="header">
                    <h2>Diagnosis</h2>
                </div>
                <table>
                    <tr>
                        <th colspan="2">Principal Diagnosis</th>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="principal-diagnosis" value="1"> Cancer
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="principal-diagnosis" value="2"> Dementia/Alzheimer\'s
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="principal-diagnosis" value="3" checked> None of the Above
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Terminal Diagnosis</th>
                    </tr>
                    <tr>
                        <td>
                            <span class="dotted-line">150.21 Acute systolic (congestive heart failure)</span>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Comorbidities</th>
                    </tr>
                    <tr>
                        <td>
                            <span class="dotted-line">150.21 Acute systolic (congestive heart failure)</span>
                        </td>
                    </tr>
                </table>
            </div>
            ';

            $prognosisHtml = '
            <!-- Prognosis Section -->
            <div class="container">
                <div class="header">
                    <h2>Prognosis</h2>
                </div>
                <table>
                    <tr>
                        <th colspan="2">Patient:</th>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check">
                                <input type="checkbox" name="prognosis-patient-1" value="1"> Patient 1
                            </div>
                            <div class="form-check">
                                <input type="checkbox" name="prognosis-patient-2" value="2"> Patient 2
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th colspan="2">Caregiver:</th>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check">
                                <input type="checkbox" name="prognosis-caregiver-1" value="1"> Caregiver 1
                            </div>
                            <div class="form-check">
                                <input type="checkbox" name="prognosis-caregiver-2" value="2"> Caregiver 2
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th colspan="2">Imminence of Death:</th>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check">
                                <input type="checkbox" name="prognosis-imminence-1" value="1"> Imminence 1
                            </div>
                            <div class="form-check">
                                <input type="checkbox" name="prognosis-imminence-2" value="2"> Imminence 2
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Patient is Imminent:</th>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="patient-is-imminent" value="1"> Yes
                            </div>
                            <div class="form-check">
                                <input type="radio" name="patient-is-imminent" value="0" checked> No
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
            ';

            $planOfCareHtml = '
            <!-- Plan of Care Orders Section -->
            <div class="container">
                <div class="header">
                    <h2>Plan of Care Orders</h2>
                </div>
                <table>
                    <tr>
                        <td>
                            <div class="form-check">
                                <input type="checkbox" name="imminent-death" value="1"> Imminent Death .Terminal Decline:
                            </div>
                            <div class="form-check">
                                <input type="checkbox" name="other" value="1"> Other:
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
            ';






            








            // Combine both HTML contents with a page break between them
            $html = '
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>PDF Content</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        color: #4a5568;
                    }
                    .container {
                        border-radius: 5px;
                        box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.1);
                        padding: 20px;
                        margin: 20px;
                    }
                    .header {
                        background-color: #44BBB59F;
                        color: #ffffff;
                        border-top-right-radius: 5px;
                        padding-left: 10px;
                        padding: 10px;
                    }
                    h2 {
                        margin: 0;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-bottom: 5px;
                    }
                    th, td {
                        padding: 10px;
                        border: 1px solid #ddd;
                        text-align: left;
                    }
                    th {
                        background-color: #f4f4f4;
                        width: 30%;
                    }
                    .dotted-line {
                        border-bottom: 1px dotted #000;
                        width: 100%;
                        display: inline-block;
                    }
                    .form-check {
                        margin-bottom: 10px;
                    }
                    .form-check input {
                        margin-right: 10px;
                    }
                </style>
            </head>
            <body>
                ' . $visitInformationHtml . '
                <div style="page-break-before: always;"></div>
                ' . $demographicsHtml . '
                <div style="page-break-before: always;"></div>
                ' . $admissionInformationHtml  . '
                <div style="page-break-before: always;"></div>
                ' . $payerInformationHtml  . '
                <div style="page-break-before: always;"></div>
                ' . $vitalSignsHtml  . '
                <div style="page-break-before: always;"></div>
                ' . $diagnosisHtml  . '
                <div style="page-break-before: always;"></div>
                ' . $prognosisHtml  . '
                <div style="page-break-before: always;"></div>
                ' . $planOfCareHtml  . '
                
               
                <div class="footer">
                    Page {PAGE_NUM} of {PAGE_COUNT}
                </div>
            </body>
            </html>
            ';

            // Configure Dompdf options using array
            $pdf = \PDF::loadHTML($html)->setPaper('a4', 'portrait')->setWarnings(false)->setOptions([
                'isHtml5ParserEnabled' => true,
                'isRemoteEnabled' => true,
            ]);

            return $pdf->download('output.pdf');
        } catch (\Exception $e) {
            Log::error('Error generating PDF: ' . $e->getMessage());
            return response()->json(['error' => 'Error generating PDF'], 500);
        }
    }
}
