<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;

use App\Models\PatientPharmacy;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PatientPharmacyController extends Controller
{
    public function index()
    {
        $patientPharmacy = PatientPharmacy::all();
        return response()->json($patientPharmacy);
    }

    public function store(Request $request)
    {
         // Validation des données de la requête
         $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:patient_pharmacies,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        $patientPharmacy = PatientPharmacy::create([
            'name' => $request->name,
        ]);

        // Réponse JSON en cas de succès
        return response()->json([
                    'message' => 'patient Pharmacy created successfully ',
                   'data' => $patientPharmacy,
                 ], 200);
    }
    public function show($id)
    {
        try {
            $patientPharmacy = PatientPharmacy::findOrFail($id);
            return response()->json($patientPharmacy);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No patient Pharmacy found.'], 404);
        }
    }
    public function update(Request $request, $id)
    {
          // Validation des données de la requête
          $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:patient_pharmacies,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        try {
            $patientPharmacy =   PatientPharmacy::findOrFail($id);
            $patientPharmacy->update([
                'name' => $request->name,
            ]);
            // Réponse JSON en cas de succès
            return response()->json([
                        'message' => ' patient Pharmacy update successfully ',
                       'data' => $patientPharmacy,
                     ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No patient Pharmacy found.'], 404);
        }
    }

    public function destroy($id)
    {
        try {
    $patientPharmacy = PatientPharmacy::findOrFail($id);
    $patientPharmacy->delete();
    return response()->json( ['message' => ' patient Pharmacy delete successfully ']);
    //code...
} catch (ModelNotFoundException $e) {
    return response()->json(['error' => 'No patient Pharmacy found.'], 404);
}
    }
}
