<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\Prognosis;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PrognosisController extends Controller
{
    public function index()
    {
        $prognosis = Prognosis::all();
        return response()->json($prognosis);
    }
    public function store(Request $request)
    {
        // Valider les données entrantes
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'prognosis_patient_is_imminent' => 'nullable',
            'prognosis_patient_id' => 'nullable',
            'prognosis_caregiver_id' => 'nullable',
            'prognosis_imminence_id' => 'nullable'
        ]);
    
        $prognosis = Prognosis::where('patient_id', $validatedData['patient_id'])->first();
    
        if ($prognosis) {
            // Mettre à jour les informations
            if (!empty($validatedData['prognosis_patient_is_imminent'])) {
                $updateData = [
                    'prognosis_patient_is_imminent' => $validatedData['prognosis_patient_is_imminent']
                ];

            }
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['prognosis_patient_id'])) {
                $updateData['prognosis_patient_id'] = implode(',', $validatedData['prognosis_patient_id']);
            }
            if (!empty($validatedData['prognosis_caregiver_id'])) {
                $updateData['prognosis_caregiver_id'] = implode(',', $validatedData['prognosis_caregiver_id']);
            }
            if (!empty($validatedData['prognosis_imminence_id'])) {
                $updateData['prognosis_imminence_id'] = implode(',', $validatedData['prognosis_imminence_id']);
            }
    
            $prognosis->update($updateData);
    
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
                'prognosis_patient_is_imminent' => $validatedData['prognosis_patient_is_imminent']
            ];
    
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['prognosis_patient_id'])) {
                $createData['prognosis_patient_id'] = implode(',', $validatedData['prognosis_patient_id']);
            }
            if (!empty($validatedData['prognosis_caregiver_id'])) {
                $createData['prognosis_caregiver_id'] = implode(',', $validatedData['prognosis_caregiver_id']);
            }
            if (!empty($validatedData['prognosis_imminence_id'])) {
                $createData['prognosis_imminence_id'] = implode(',', $validatedData['prognosis_imminence_id']);
            }
    
            $prognosis = Prognosis::create($createData);
        }
    
        // Réponse JSON en cas de succès
        return response()->json([
            'message' => 'Prognosis créé ou mis à jour avec succès.',
            'data' => $prognosis,
        ], 201);
    }
        
    public function show($id)
    {
        try {
            // Recherchez les informations de visite correspondant à l'ID du patient
            $admission_information =Prognosis::where('patient_id', $id)->firstOrFail();
            return response()->json($admission_information);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No prognosis found for this Prognosis'], 404);
        }
    }
    
}
