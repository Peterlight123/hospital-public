<?php

namespace App\Http\Controllers\patient;

use App\Models\Discharge;
use Illuminate\Http\Request;
use App\Models\DischargeSection;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class DischargeController extends Controller
{
    public function index()
    {
        $discharge = Discharge::all();
        return response()->json($discharge);
    }
    
    public function DischargeList()
    {
        $discharge = Discharge::all();
        return response()->json($discharge);
    }
    public function store(Request $request)
    {
        // Valider les données entrantes
        $validatedData = $request->validate([
            'patient_id' => 'nullable',
            'type_of_record' => 'nullable',
            'national_provider_identifier' => 'nullable',
            'certification_number' => 'nullable',
            'admission_date' => 'nullable',
            'reason_for_record' => 'nullable',
            'discharge_date' => 'nullable',
            'social_security_number' => 'nullable',
            'medicare_number' => 'nullable',
            'medicaid_recipient' => 'nullable',
            'reason_for_discharge' => 'nullable',
        ]);

        $discharge = Discharge::where('patient_id', $validatedData['patient_id'])->first();

        if ($discharge) {
            // Vérifier et ajouter les champs non vides
           
            $updateData = [
                'type_of_record' => $validatedData['type_of_record'],
                'national_provider_identifier' => $validatedData['national_provider_identifier'],
                'certification_number' => $validatedData['certification_number'],
                'reason_for_record' => $validatedData['reason_for_record'],
                'admission_date' => $validatedData['admission_date'],
                'discharge_date' => $validatedData['discharge_date'],
                'social_security_number' => $validatedData['social_security_number'],
                'medicare_number' => $validatedData['medicare_number'],
                'medicaid_recipient' => $validatedData['medicaid_recipient'],
            ];
            $reason_for_discharge_ids = $validatedData['reason_for_discharge'];
            if (!empty($reason_for_discharge_ids )) {
               $updateData['reason_for_discharge'] = implode(',', $validatedData['reason_for_discharge']);
           }
            $discharge->update($updateData);
        } else {
            // Créer de nouvelles données
           
            $createData = [
                'patient_id' => $validatedData['patient_id'],
                'type_of_record' => $validatedData['type_of_record'],
                'national_provider_identifier' => $validatedData['national_provider_identifier'],
                'certification_number' => $validatedData['certification_number'],
                'reason_for_record' => $validatedData['reason_for_record'],
                'admission_date' => $validatedData['admission_date'],
                'discharge_date' => $validatedData['discharge_date'],
                'social_security_number' => $validatedData['social_security_number'],
                'medicare_number' => $validatedData['medicare_number'],
                'medicaid_recipient' => $validatedData['medicaid_recipient'],
            ];
            // Vérifier et ajouter les champs non vides
            $reason_for_discharge_ids = $validatedData['reason_for_discharge'];
            if (!empty($reason_for_discharge_ids )) {
                $createData['reason_for_discharge'] = implode(',', $validatedData['reason_for_discharge']);
            }
            $discharge = Discharge::create($createData);
        }
        // Réponse JSON en cas de succès
        return response()->json([
            'message' => 'Discharge créé ou mis à jour avec succès.',
            'data' => $discharge,
        ], 201);
    }

    public function show($id)
    {
        try {
            // Recherchez les Discharge correspondant à l'ID du patient
            $discharge = Discharge::where('patient_id', $id)->firstOrFail();
            return response()->json($discharge);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No Discharge found for this Discharge'], 404);
        }
    }

    public function dischargeSections()
    {
        $dischargeSections = DischargeSection::all();
        return response()->json($dischargeSections);
    }
}
