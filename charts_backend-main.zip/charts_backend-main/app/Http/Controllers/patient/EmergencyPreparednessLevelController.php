<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\EmergencyPreparednessLevel;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class EmergencyPreparednessLevelController extends Controller
{
    public function index()
    {
        $EmergencyPreparednessLevel = EmergencyPreparednessLevel::all();
        return response()->json($EmergencyPreparednessLevel);
    }

    public function store(Request $request)
    {
         // Validation des données de la requête
         $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:emergency_preparedness_level,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        $EmergencyPreparednessLevel = EmergencyPreparednessLevel::create([
            'name' => $request->name,
        ]);

        // Réponse JSON en cas de succès
        return response()->json([
                    'message' => 'EmergencyPreparednessLevels created successfully ',
                   'data' => $EmergencyPreparednessLevel,
                 ], 200);
    }
    public function show($id)
    {
        try {
            $EmergencyPreparednessLevel = EmergencyPreparednessLevel::findOrFail($id);
            return response()->json($EmergencyPreparednessLevel);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No  Emergency Preparedness Level found'], 404);
        }
    }
    public function update(Request $request, $id)
    {
          // Validation des données de la requête
          $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:emergency_preparedness_level,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        try {
            $EmergencyPreparednessLevel =   EmergencyPreparednessLevel::findOrFail($id);
            $EmergencyPreparednessLevel->update([
                'name' => $request->name,
            ]);
            // Réponse JSON en cas de succès
            return response()->json([
                        'message' => 'Emergency Preparedness Levels update successfully ',
                       'data' => $EmergencyPreparednessLevel,
                     ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No  Emergency Preparedness Levels found.'], 404);
        }
    }

    public function destroy($id)
    {
        try {
    $EmergencyPreparednessLevel = EmergencyPreparednessLevel::findOrFail($id);
    $EmergencyPreparednessLevel->delete();
    return response()->json( ['message' => ' Emergency Preparedness Levels delete successfully ']);
    //code...
} catch (ModelNotFoundException $e) {
    return response()->json(['error' => 'No  Emergency Preparedness Levels found.'], 404);
}
    }
}

