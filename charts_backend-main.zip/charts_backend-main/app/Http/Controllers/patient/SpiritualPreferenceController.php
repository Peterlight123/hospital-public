<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\SpiritualPreference;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class SpiritualPreferenceController extends Controller
{
    public function index()
    {
        $spiritualPreference = SpiritualPreference::all();
        return response()->json($spiritualPreference);
    }
    public function store(Request $request)
    {
        // Valider les données entrantes
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'patient_spiritual' => 'nullable',
            'not_religious' => 'nullable',
            'comments' => 'nullable'
        ]);

        $spiritualPreference = SpiritualPreference::where('patient_id', $validatedData['patient_id'])->first();

        if ($spiritualPreference) {
            // Vérifier et ajouter les champs non vides
           
            $updateData = [
                'not_religious' => $validatedData['not_religious'],
                'patient_spiritual' => $validatedData['patient_spiritual'],
                'comments' => $validatedData['comments'],
            ];
            $spiritualPreference->update($updateData);
        } else {
            // Créer de nouvelles données
           
            $createData = [
                'patient_id' => $validatedData['patient_id'],
                'patient_spiritual' => $validatedData['patient_spiritual'],
                'comments' => $validatedData['comments'],
                'not_religious' => $validatedData['not_religious']
            ];
            // Vérifier et ajouter les champs non vides
            $spiritualPreference = SpiritualPreference::create($createData);
        }
        // Réponse JSON en cas de succès
        return response()->json([
            'message' => 'Spiritual Preference créé ou mis à jour avec succès.',
            'data' => $spiritualPreference,
        ], 201);
    }

    public function show($id)
    {
        try {
            // Recherchez les SpiritualPreference correspondant à l'ID du patient
            $spiritualPreference = SpiritualPreference::where('patient_id', $id)->firstOrFail();
            return response()->json($spiritualPreference);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No Spiritual Preference found for this SpiritualPreference'], 404);
        }
    }
}
