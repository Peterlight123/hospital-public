<?php

namespace App\Http\Controllers\patient;

use PDF;
use App\Models\PainData;
use App\Models\FlaccData;
use App\Models\VitalSign;
use App\Models\PainadData;
use Illuminate\Http\Request;
use App\Models\RespiratoryData;
// use Barryvdh\DomPDF\Facade\Pdf;
use App\Models\ScaleToolLabData;
use App\Models\GenitourinaryData;
use App\Models\CardiovascularData;
use Illuminate\Support\Facades\DB;
use App\Models\NursingClinicalNote;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Models\GastrointestinalData;

class NursingClinicalNoteController extends Controller
{


    public function autoSaveVitalSigns(Request $request , $noteId)
    {
        $validatedData = $request->validate([
            'degrees_fahrenheit' => 'nullable|integer',
            'temperature_method' => 'nullable|string',
            'heart_rate' => 'nullable|integer',
            'heart_rhythm' => 'nullable|string',
            'heart_rate_location' => 'nullable|string',
            'other_heart_rate_location' => 'nullable|string',
            'bp_mmhg' => 'nullable|integer',
            'bp_position' => 'nullable|string',
            'bp_location' => 'nullable|string',
            'other_bp_location' => 'nullable|string',
            'bp_additional_readings' => 'nullable|string',
            'respiratory_rate' => 'nullable|integer',
            'respiratory_rhythm' => 'nullable|string',
            'pulse_oximetry_percentage' => 'nullable|numeric',
            'pulse_ox_location' => 'nullable|string',
            'pulse_ox_other_location' => 'nullable|string',
            'body_height_inches' => 'nullable|numeric',
            'body_weight_ibs' => 'nullable|numeric',
            'body_weight_kg' => 'nullable|numeric',
            'body_weight_period' => 'nullable|string',
            'bmi_kg_m2' => 'nullable|numeric',
            'bmi_percentage' => 'nullable|numeric',
        ]);

        $vitalSign = VitalSign::updateOrCreate(
            
            // ['note_id' => $request->note_id],
            ['note_id' => $noteId], // Assuming you have note_id to link with
            $validatedData
        );

        return response()->json($vitalSign);
    }
    // public function show($id)
    // {
    //     $note = NursingClinicalNote::findOrFail($id);
    //     return response()->json($note);
    // }


    public function getVitalSigns($noteId)
    {
        $vitalSigns = VitalSign::where('note_id', $noteId)->first();

        if ($vitalSigns) {
            return response()->json($vitalSigns, 200);
        } else {
            return response()->json(['message' => 'No vital signs found for the given note ID.'], 404);
        }
    }


    public function indexScaleToolLabData($noteId)
    {
        $data = ScaleToolLabData::where('note_id', $noteId)->first();
        return response()->json($data);
    }

    public function autoSaveScaleToolLabData(Request $request, $noteId)
    {
        $validatedData = $request->validate([
            'mac' => 'nullable|string',
            'mtc' => 'nullable|string',
            'sleep_time' => 'nullable|string',
            'fast' => 'nullable|string',
            'nyha' => 'nullable|string',
            'other_reading_1' => 'nullable|string',
            'blood_sugar' => 'nullable|string',
            'pt_inr' => 'nullable|string',
            'other_reading_2' => 'nullable|string',
            'other_reading_3' => 'nullable|string',
            'other_reading_4' => 'nullable|string',
        ]);

        $scaleToolLabData = ScaleToolLabData::updateOrCreate(
            ['note_id' => $noteId], // Assuming you have note_id to link with
            $validatedData
        );

        return response()->json($scaleToolLabData);
    }


    public function indexPainData($noteId)
    {
        $data = PainData::where('note_id', $noteId)->first();
        return response()->json($data);
    }

    public function autoSavePainData(Request $request, $noteId)
    {
        $validatedData = $request->validate([
            'pain_level_now' => 'nullable|string',
            'pain_right' => 'nullable|string',
            'pain_left' => 'nullable|string',
            'pain_acceptable_level' => 'nullable|string',
            'pain_rated_by' => 'nullable|array',
            'respiratory_rhythm' => 'nullable|string',
            'pain_observations' => 'nullable|array',
            'pain_duration' => 'nullable|array',
            'pain_frequency' => 'nullable|array',
            'pain_character' => 'nullable|array',
            'worsened_by' => 'nullable|array',
            'relieved_by' => 'nullable|array',
            'effects_on_function' => 'nullable|array',
            'current_pain_management' => 'nullable|string',
            'breakthrough_pain' => 'nullable|array',
            'additional_pain_information' => 'nullable|string',
        ]);

        $painData = PainData::updateOrCreate(
            ['note_id' => $noteId],
            $validatedData
        );

        return response()->json($painData);
    }


    public function indexPainadData($noteId)
    {
        $painadData = PainadData::where('note_id', $noteId)->first();
        return response()->json($painadData);
    }

    public function autoSavePainadData(Request $request, $noteId)
    {
        $validatedData = $request->validate([
            'pain_assessment_behavior' => 'nullable|string',
            'pain_assessment_negative_vocalizations' => 'nullable|string',
            'pain_assessment_facial_expression' => 'nullable|string',
            'pain_assessment_body_language' => 'nullable|string',
            'pain_consolability' => 'nullable|string',
            'painad_total_score' => 'nullable|integer',
        ]);

        $painadData = PainadData::updateOrCreate(
            ['note_id' => $noteId],
            $validatedData
        );

        return response()->json($painadData);
    }

    public function indexFlaccData($noteId)
    {
        $flaccData = FlaccData::where('note_id', $noteId)->first();
        return response()->json($flaccData);
    }

    public function autoSaveFlaccData(Request $request, $noteId)
    {
        $validatedData = $request->validate([
            'flacc_face' => 'nullable|string',
            'flacc_legs' => 'nullable|string',
            'flacc_activity' => 'nullable|string',
            'flacc_cry' => 'nullable|string',
            'flacc_consolability' => 'nullable|string',
            'total_score' => 'nullable|integer',
        ]);

        $flaccData = FlaccData::updateOrCreate(
            ['note_id' => $noteId],
            $validatedData
        );

        return response()->json($flaccData);
    }

    public function indexCardiovascularData($noteId)
    {
        $data = CardiovascularData::where('note_id', $noteId)->first();
        return response()->json($data);
    }

    public function autoSaveCardiovascularData(Request $request, $noteId)
    {
        $validatedData = $request->validate([
            'chest_pain' => 'boolean',
            'dizziness' => 'boolean',
            'edema' => 'array',
            'pedal' => 'boolean',
            'right' => 'boolean',
            'left' => 'boolean',
            'sacral' => 'boolean',
            'dependent' => 'boolean',
            'irregular_heart_sounds' => 'boolean',
            'neck_vein_distention' => 'boolean',
            'devices' => 'array',
            'additional_details' => 'boolean',
            'present' => 'array',
            'bounding' => 'array',
            'weak_thready' => 'array',
            'absent' => 'array',
            'cardiovascular_note' => 'boolean',
            'right_foot' => 'nullable|string',
            'left_foot' => 'nullable|string',
            'right_ankle' => 'nullable|string',
            'left_ankle' => 'nullable|string',
            'right_calf' => 'nullable|string',
            'left_calf' => 'nullable|string',
            'right_upper_leg' => 'nullable|string',
            'left_upper_leg' => 'nullable|string',
            'right_hand' => 'nullable|string',
            'left_hand' => 'nullable|string',
            'right_arm' => 'nullable|string',
            'left_arm' => 'nullable|string',
            'right_scrotum' => 'nullable|string',
            'left_scrotum' => 'nullable|string',
            'right_face' => 'nullable|string',
            'left_face' => 'nullable|string',
        ]);

        $validatedData['note_id'] = $noteId;

        $data = CardiovascularData::updateOrCreate(
            ['note_id' => $noteId],
            $validatedData
        );
        

        return response()->json($data);
    }


    public function indexRespiratoryData($noteId)
    {
        $respiratoryData = RespiratoryData::where('note_id', $noteId)->first();
        return response()->json($respiratoryData);
    }

    public function autoSaveRespiratoryData(Request $request, $noteId)
    {
        $validatedData = $request->validate([
            'clear' => 'array',
            'diminished' => 'array',
            'crackles' => 'array',
            'rhonchi' => 'array',
            'wheezing' => 'array',
            'rales' => 'array',
            'absent' => 'array',
            'note' => 'string|nullable',
            'breathing' => 'array',
            'oxygen_use' => 'array',
            'shortness_of_breath' => 'array',
        ]);

        $respiratoryData = RespiratoryData::updateOrCreate(
            ['note_id' => $noteId],
            $validatedData
        );

        return response()->json($respiratoryData);
    }

    public function indexGenitourinaryData($noteId)
    {
        $genitourinaryData = GenitourinaryData::where('note_id', $noteId)->first();
        return response()->json($genitourinaryData);
    }

    public function autoSaveGenitourinaryData(Request $request, $noteId)
    {
        $validatedData = $request->validate([
            'absence_urinary_output' => 'required|boolean',
            'decrease_urinary_output' => 'required|boolean',
            'change_bladder_incontinence' => 'required|boolean',
            'distension' => 'required|boolean',
            'incontinence' => 'required|boolean',
            'retention' => 'required|boolean',
            'current_ss_infection' => 'required|array',
            'current_ss_infection.burning' => 'required|boolean',
            'current_ss_infection.hematuria' => 'required|boolean',
            'current_ss_infection.fever' => 'required|boolean',
            'current_ss_infection.spasms' => 'required|boolean',
            'current_ss_infection.foul_smelling_urine' => 'required|boolean',
            'current_ss_infection.cloudy_urine' => 'required|boolean',
            'current_ss_infection.other' => 'required|boolean',
            'indwelling_catheter_flush' => 'required|boolean',
            'other_catheter' => 'required|boolean',
            'no_deficit' => 'required|boolean',
            'urinary_diversion_ostomy_ileal_conduit' => 'required|boolean',
            'urinary_diversion_ostomy_nephrostomy' => 'required|boolean',
            'urinary_diversion_ostomy_ureterostomy' => 'required|boolean',
            'urinary_diversion_ostomy_other' => 'required|boolean',
            'urinary_diversion_ostomy_suprapubic_catheter' => 'required|boolean',
            'urinary_diversion_ostomy_condom_catheter' => 'required|boolean',
            'flush' => 'nullable|string',
            'size_balloon' => 'nullable|string',
            'describe_deficits' => 'nullable|string',
        ]);

        $genitourinaryData = GenitourinaryData::updateOrCreate(
            ['note_id' => $noteId],
            $validatedData
        );

        return response()->json($genitourinaryData);
    }

    public function indexGastrointestinalData($noteId)
    {
        $data = GastrointestinalData::where('note_id', $noteId)->firstOrFail();
        return response()->json($data);
    }

    public function autoSaveGastrointestinalData(Request $request, $noteId)
    {
        $validatedData = $request->validate([
            'last_bm' => 'boolean',
            'unknown' => 'boolean',
            'bowel_sounds' => 'boolean',
            'present' => 'array',
            'hyper_active' => 'array',
            'hypo_active' => 'array',
            'absent' => 'array',
            'rectal_bleeding' => 'boolean',
            'hemorrhoids' => 'boolean',
            'bowel_incontinence' => 'boolean',
            'change_bowel_incontinence' => 'boolean',
            'constipation' => 'boolean',
            'diarrhea' => 'boolean',
            'ascites' => 'boolean',
            'ostomy_details' => 'boolean',
            'drain_details' => 'boolean',
            'anorexia' => 'boolean',
            'cachexia' => 'boolean',
            'nausea' => 'boolean',
            'vomiting' => 'boolean',
            'no_intake_last_24hrs' => 'boolean',
            'swallowing_deficits' => 'boolean',
            'inability_swallow' => 'boolean',
            'diet' => 'string|nullable',
            'percentage_eaten' => 'string|nullable',
            'npo' => 'boolean',
            'tube_feeding' => 'boolean',
            'placement_checked' => 'boolean',
            'most_recent_rbs' => 'boolean',
            'hyperglycemia' => 'boolean',
            'hypoglycemia' => 'boolean',
            'other' => 'boolean',
            'no_deficit' => 'boolean',
            'describe_deficits' => 'string|nullable',
        ]);

        $validatedData['note_id'] = $noteId;

        $data = GastrointestinalData::updateOrCreate(['note_id' => $noteId], $validatedData);

        return response()->json($data);
    }


    public function show($noteId)
    {
        $note = NursingClinicalNote::with(['benefitPeriod.patient'])
            ->where('id', $noteId)
            ->first();

        if (!$note) {
            return response()->json(['message' => 'Note not found'], 404);
        }

        return response()->json($note);
    }

    // public function update(Request $request, $id)
    // {
    //     $note = NursingClinicalNote::findOrFail($id);
    //     $note->update($request->all());
    //     return response()->json($note);
    // }

    // public function update(Request $request, $id)
    // {
    //     $validatedData = $request->validate([
    //         'time_in' => 'nullable|date_format:H:i',
    //         'time_out' => 'nullable|date_format:H:i',
    //         'prn_visit' => 'boolean',
    //         'patient_identifiers' => 'array'
    //     ]);

    //     $note = NursingClinicalNote::findOrFail($id);
    //     $note->update($validatedData);

    //     return response()->json($note);
    // }

    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'benefit_period_id' => 'sometimes|required|exists:benefit_periods,id',
            'note_date' => 'sometimes|required|date',
            'time_in' => 'nullable',
            'time_out' => 'nullable',
            'patient_name' => 'nullable|string|max:255',
            'patient_number' => 'nullable|string|max:255',
            'location_name' => 'nullable|string|max:255',
            'benefit_period' => 'nullable|array',
            'dob' => 'nullable|date',
            'location_number' => 'nullable|string|max:255',
            'prn_visit' => 'nullable|boolean',
            'patient_identifiers' => 'nullable|array',
        ]);

        $note = NursingClinicalNote::findOrFail($id);
        $note->update($validatedData);

        return response()->json($note, 200);
    }

    public function startNote(Request $request, $periodId)
    {
        $noteId = DB::table('nursing_clinical_notes')->insertGetId([
            'benefit_period_id' => $periodId,
            'note_date' => $request->input('note_date'),
            //'note' => $request->input('note'),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $newNote = DB::table('nursing_clinical_notes')->where('id', $noteId)->first();

        return response()->json($newNote, 201);
    }
    
    public function generatePdf(Request $request, $noteId)
    {
        // try {
            Log::info('API generate-pdf called');

            // Récupérer les données des signes vitaux pour la note donnée
            $vitalSign = VitalSign::where('note_id', $noteId)->first();
            $scaleToolLabData = ScaleToolLabData::where('note_id', $noteId)->first();
            $painData = PainData::where('note_id', $noteId)->first();
            $painadData = PainadData::where('note_id', $noteId)->first();
            $flaccData= FlaccData::where('note_id', $noteId)->first();
            $cardiovascularData= CardiovascularData::where('note_id', $noteId)->first();
            $respiratoryData= RespiratoryData::where('note_id', $noteId)->first();
            $genitourinaryData= GenitourinaryData::where('note_id', $noteId)->first();
            $gastrointestinalData= GastrointestinalData::where('note_id', $noteId)->first();
            $noteData= NursingClinicalNote::where('id', $noteId)->first();

            if (!$vitalSign) {
                return response()->json(['error' => 'Vital signs not found for the given note ID'], 404);
            }
            // HTML content for VITAL SIGNS
            // Construire le contenu HTML avec les données des signes vitaux

            $vitalSignsHtml = '
                <div class="container">
                    <div class="header">
                        <h2>VITAL SIGNS</h2>
                    </div>
                    <table>
                        <tr>
                            <th>Body Temperature / Route</th>
                            <td>
                                <p>Degrees fahrenheit: ' . htmlspecialchars($vitalSign->degrees_fahrenheit) . '</p>
                                <p>Temperature Method: ' . htmlspecialchars($vitalSign->temperature_method) . '</p>
                            </td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <th>Heart Rate</th>
                            <td>
                                <p>beats / minute: ' . htmlspecialchars($vitalSign->heart_rate) . '</p>
                                <p>Heart Rhythm: ' . htmlspecialchars($vitalSign->heart_rhythm) . '</p>
                                <p>Heart Rate Location: ' . htmlspecialchars($vitalSign->heart_rate_location) . '</p>
                                <p>Other Heart Rate Location: ' . htmlspecialchars($vitalSign->other_heart_rate_location) . '</p>
                            </td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <th>Blood Pressure - Systolic / Diastolic</th>
                            <td>
                                <p>mmHg: ' . htmlspecialchars($vitalSign->bp_mmhg) . '</p>
                                <p>Position: ' . htmlspecialchars($vitalSign->bp_position) . '</p>
                                <p>BP Location: ' . htmlspecialchars($vitalSign->bp_location) . '</p>
                                <p>Other BP Location: ' . htmlspecialchars($vitalSign->other_bp_location) . '</p>
                                <p>Additional Readings / Details: ' . htmlspecialchars($vitalSign->bp_additional_readings) . '</p>
                            </td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <th>Respiratory Rate</th>
                            <td>
                                <p>breaths / minute: ' . htmlspecialchars($vitalSign->respiratory_rate) . '</p>
                                <p>Respiratory Rhythm: ' . htmlspecialchars($vitalSign->respiratory_rhythm) . '</p>
                            </td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <th>Pulse Oximetry</th>
                            <td>
                                <p>%: ' . htmlspecialchars($vitalSign->pulse_oximetry_percentage) . '</p>
                                <p>Pulse Ox Location: ' . htmlspecialchars($vitalSign->pulse_ox_location) . '</p>
                                <p>Other Location: ' . htmlspecialchars($vitalSign->pulse_ox_other_location) . '</p>
                            </td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <th>Body Height</th>
                            <td>
                                <p>inches: ' . htmlspecialchars($vitalSign->body_height_inches) . '</p>
                            </td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <th>Body Weight</th>
                            <td>
                                <p>lbs: ' . htmlspecialchars($vitalSign->body_weight_ibs) . '</p>
                                <p>Kg: ' . htmlspecialchars($vitalSign->body_weight_kg) . '</p>
                                <p>Weight Type: ' . htmlspecialchars($vitalSign->body_weight_period) . '</p>
                            </td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <th>BMI</th>
                            <td>
                                <p>KG / m2: ' . htmlspecialchars($vitalSign->bmi_kg_m2) . '</p>
                            </td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <th>BMI Percentile</th>
                            <td>
                                <p>%: ' . htmlspecialchars($vitalSign->bmi_percentage) . '</p>
                            </td>
                        </tr>
                    </table>
                </div>';


            // HTML content for SCALES TOOLS & LAB DATA REVIEW
            $scalesToolsHtml = '
            <div class="container">
                <div class="header">
                    <h2>SCALES TOOLS & LAB DATA REVIEW</h2>
                </div>
                <table>
                    <tr>
                        <th>Scales & Tools And Value / Reading THIS VISIT</th>
                        <td>
                            <p>Mid-Arm Circumference (MAC) (include unit of measure / location on arm): ' . htmlspecialchars($scaleToolLabData->mac) . '</p>
                            <p>Mid-Thigh Circumference (MTC) (include unit of measure / location on thigh): ' . htmlspecialchars($scaleToolLabData->mtc) . '</p>
                            <p>SLEEP (time in last 24 hours): ' . htmlspecialchars($scaleToolLabData->sleep_time) . '</p>
                            <p>FAST: ' . htmlspecialchars($scaleToolLabData->fast) . '</p>
                            <p>NYHA: ' . htmlspecialchars($scaleToolLabData->nyha) . '</p>
                            <p>Other Reading 1: ' . htmlspecialchars($scaleToolLabData->other_reading_1) . '</p>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Lab (POC or Other) And Value / Reading THIS VISIT</th>
                        <td>
                            <p>Blood Sugar: ' . htmlspecialchars($scaleToolLabData->blood_sugar) . '</p>
                            <p>PT / INR: ' . htmlspecialchars($scaleToolLabData->pt_inr) . '</p>
                            <p>Other Reading 2: ' . htmlspecialchars($scaleToolLabData->other_reading_2) . '</p>
                            <p>Other Reading 3: ' . htmlspecialchars($scaleToolLabData->other_reading_3) . '</p>
                            <p>Other Reading 4: ' . htmlspecialchars($scaleToolLabData->other_reading_4) . '</p>
                        </td>
                    </tr>
                </table>
            </div>';


            // pain 
            $painHtml = '
            <div class="container">
                <div class="header">
                    <h2>*PAIN</h2>
                </div>
                <table>
                    <tr>
                        <th>Pain Information</th>
                        <td>
                            <p>Pain level now: ' . htmlspecialchars($painData->pain_level_now) . '</p>
                            <p>Right: ' . htmlspecialchars($painData->pain_right) . '</p>
                            <p>Left: ' . htmlspecialchars($painData->pain_left) . '</p>
                            <p>Acceptable level of pain: ' . htmlspecialchars($painData->pain_acceptable_level) . '</p>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Pain rated by:</th>
                        <td>' .
                            (in_array('Patient', $painData->pain_rated_by) ? '<div class="form-check"><input type="checkbox" checked> Patient</div>' : '<div class="form-check"><input type="checkbox"> Patient</div>') .
                            (in_array('Caregiver', $painData->pain_rated_by) ? '<div class="form-check"><input type="checkbox" checked> Caregiver</div>' : '<div class="form-check"><input type="checkbox"> Caregiver</div>') .
                            (in_array('Hospice Nurse', $painData->pain_rated_by) ? '<div class="form-check"><input type="checkbox" checked> Hospice Nurse</div>' : '<div class="form-check"><input type="checkbox"> Hospice Nurse</div>') . '
                        </td>
                    </tr>
                </table>
                <table>
                   <tr>
                        <th>Respiratory Rhythm</th>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="pain_scale" value="numeric" ' . ($painData->respiratory_rhythm === 'Numeric i.e ESAS' ? 'checked' : '') . '> Numeric i.e ESAS
                            </div>
                            <div class="form-check">
                                <input type="radio" name="pain_scale" value="verbal" ' . ($painData->respiratory_rhythm === 'Verbal descriptor' ? 'checked' : '') . '> Verbal descriptor
                            </div>
                            <div class="form-check">
                                <input type="radio" name="pain_scale" value="visual" ' . ($painData->respiratory_rhythm === 'Patient Visual i.e FACES' ? 'checked' : '') . '> Patient Visual i.e FACES
                            </div>
                            <div class="form-check">
                                <input type="radio" name="pain_scale" value="observation" ' . ($painData->respiratory_rhythm === 'Staff Observation (i.e. PAINAD)' ? 'checked' : '') . '> Staff Observation (i.e. PAINAD)
                            </div>
                            <div class="form-check">
                                <input type="radio" name="pain_scale" value="none" ' . ($painData->respiratory_rhythm === 'No scale used' ? 'checked' : '') . '> No scale used
                            </div>
                        </td>
                    </tr>

                </table>
                <table>
                    <tr>
                        <th>Pain Observations</th>
                        <td>' .
                            (in_array('Crying', $painData->pain_observations) ? '<div class="form-check"><input type="checkbox" checked> Crying</div>' : '<div class="form-check"><input type="checkbox"> Crying</div>') .
                            (in_array('Facial grimacing', $painData->pain_observations) ? '<div class="form-check"><input type="checkbox" checked> Facial grimacing</div>' : '<div class="form-check"><input type="checkbox"> Facial grimacing</div>') .
                            (in_array('Grabbing/holding body part', $painData->pain_observations) ? '<div class="form-check"><input type="checkbox" checked> Grabbing/holding body part</div>' : '<div class="form-check"><input type="checkbox"> Grabbing/holding body part</div>') .
                            (in_array('Guarded movements', $painData->pain_observations) ? '<div class="form-check"><input type="checkbox" checked> Guarded movements</div>' : '<div class="form-check"><input type="checkbox"> Guarded movements</div>') .
                            (in_array('Splinting', $painData->pain_observations) ? '<div class="form-check"><input type="checkbox" checked> Splinting</div>' : '<div class="form-check"><input type="checkbox"> Splinting</div>') .
                            (in_array('Thrashing', $painData->pain_observations) ? '<div class="form-check"><input type="checkbox" checked> Thrashing</div>' : '<div class="form-check"><input type="checkbox"> Thrashing</div>') .
                            (in_array('Wincing upon movement', $painData->pain_observations) ? '<div class="form-check"><input type="checkbox" checked> Wincing upon movement</div>' : '<div class="form-check"><input type="checkbox"> Wincing upon movement</div>') .
                            '<div class="form-check"><input type="checkbox"> Other:</div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Pain duration</th>
                        <td>' .
                            (in_array('Intermittent', $painData->pain_duration) ? '<div class="form-check"><input type="checkbox" checked> Intermittent</div>' : '<div class="form-check"><input type="checkbox"> Intermittent</div>') .
                            (in_array('Frequent', $painData->pain_duration) ? '<div class="form-check"><input type="checkbox" checked> Frequent</div>' : '<div class="form-check"><input type="checkbox"> Frequent</div>') .
                            (in_array('Constant', $painData->pain_duration) ? '<div class="form-check"><input type="checkbox" checked> Constant</div>' : '<div class="form-check"><input type="checkbox"> Constant</div>') .
                            '<div class="form-check"><input type="checkbox"> Other:</div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Pain Frequency</th>
                        <td>' .
                            (in_array('No pattern', $painData->pain_frequency) ? '<div class="form-check"><input type="checkbox" checked> No pattern</div>' : '<div class="form-check"><input type="checkbox"> No pattern</div>') .
                            (in_array('Constant', $painData->pain_frequency) ? '<div class="form-check"><input type="checkbox" checked> Constant</div>' : '<div class="form-check"><input type="checkbox"> Constant</div>') .
                            (in_array('Intermittent', $painData->pain_frequency) ? '<div class="form-check"><input type="checkbox" checked> Intermittent</div>' : '<div class="form-check"><input type="checkbox"> Intermittent</div>') .
                            (in_array('At right time', $painData->pain_frequency) ? '<div class="form-check"><input type="checkbox" checked> At right time</div>' : '<div class="form-check"><input type="checkbox"> At right time</div>') .
                            (in_array('In the morning', $painData->pain_frequency) ? '<div class="form-check"><input type="checkbox" checked> In the morning</div>' : '<div class="form-check"><input type="checkbox"> In the morning</div>') .
                            (in_array('Breakthrough', $painData->pain_frequency) ? '<div class="form-check"><input type="checkbox" checked> Breakthrough</div>' : '<div class="form-check"><input type="checkbox"> Breakthrough</div>') .
                            '<div class="form-check"><input type="checkbox"> Other:</div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Pain character</th>
                        <td>' .
                            (in_array('Aching', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Aching</div>' : '<div class="form-check"><input type="checkbox"> Aching</div>') .
                            (in_array('Cramping', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Cramping</div>' : '<div class="form-check"><input type="checkbox"> Cramping</div>') .
                            (in_array('Numb', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Numb</div>' : '<div class="form-check"><input type="checkbox"> Numb</div>') .
                            (in_array('Tender', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Tender</div>' : '<div class="form-check"><input type="checkbox"> Tender</div>') .
                            '<div class="form-check"><input type="checkbox"> Other</div>' .
                            (in_array('Burning', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Burning</div>' : '<div class="form-check"><input type="checkbox"> Burning</div>') .
                            (in_array('Deep', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Deep</div>' : '<div class="form-check"><input type="checkbox"> Deep</div>') .
                            (in_array('Penetrating', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Penetrating</div>' : '<div class="form-check"><input type="checkbox"> Penetrating</div>') .
                            (in_array('Tiring', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Tiring</div>' : '<div class="form-check"><input type="checkbox"> Tiring</div>') .
                            (in_array('Dull', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Dull</div>' : '<div class="form-check"><input type="checkbox"> Dull</div>') .
                            (in_array('Exhausting', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Exhausting</div>' : '<div class="form-check"><input type="checkbox"> Exhausting</div>') .
                            (in_array('Pressure', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Pressure</div>' : '<div class="form-check"><input type="checkbox"> Pressure</div>') .
                            (in_array('Unbearable', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Unbearable</div>' : '<div class="form-check"><input type="checkbox"> Unbearable</div>') .
                            (in_array('Radiating', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Radiating</div>' : '<div class="form-check"><input type="checkbox"> Radiating</div>') .
                            (in_array('Gnawing', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Gnawing</div>' : '<div class="form-check"><input type="checkbox"> Gnawing</div>') .
                            (in_array('Sharp', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Sharp</div>' : '<div class="form-check"><input type="checkbox"> Sharp</div>') .
                            (in_array('Patient unable to describe', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Patient unable to describe</div>' : '<div class="form-check"><input type="checkbox"> Patient unable to describe</div>') .
                            (in_array('Stabbing', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Stabbing</div>' : '<div class="form-check"><input type="checkbox"> Stabbing</div>') .
                            (in_array('Miserable', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Miserable</div>' : '<div class="form-check"><input type="checkbox"> Miserable</div>') .
                            (in_array('Shooting', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Shooting</div>' : '<div class="form-check"><input type="checkbox"> Shooting</div>') .
                            (in_array('Throbbing', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Throbbing</div>' : '<div class="form-check"><input type="checkbox"> Throbbing</div>') .
                            (in_array('Nagging', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Nagging</div>' : '<div class="form-check"><input type="checkbox"> Nagging</div>') .
                            (in_array('Squeezing', $painData->pain_character) ? '<div class="form-check"><input type="checkbox" checked> Squeezing</div>' : '<div class="form-check"><input type="checkbox"> Squeezing</div>') . '
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Worsened by</th>
                        <td>' .
                            (in_array('Change in position', $painData->worsened_by) ? '<div class="form-check"><input type="checkbox" checked> Change in position</div>' : '<div class="form-check"><input type="checkbox"> Change in position</div>') .
                            (in_array('Cold', $painData->worsened_by) ? '<div class="form-check"><input type="checkbox" checked> Cold</div>' : '<div class="form-check"><input type="checkbox"> Cold</div>') .
                            (in_array('Heat', $painData->worsened_by) ? '<div class="form-check"><input type="checkbox" checked> Heat</div>' : '<div class="form-check"><input type="checkbox"> Heat</div>') .
                            (in_array('Movement', $painData->worsened_by) ? '<div class="form-check"><input type="checkbox" checked> Movement</div>' : '<div class="form-check"><input type="checkbox"> Movement</div>') .
                            (in_array('Sitting', $painData->worsened_by) ? '<div class="form-check"><input type="checkbox" checked> Sitting</div>' : '<div class="form-check"><input type="checkbox"> Sitting</div>') .
                            (in_array('Standing', $painData->worsened_by) ? '<div class="form-check"><input type="checkbox" checked> Standing</div>' : '<div class="form-check"><input type="checkbox"> Standing</div>') .
                            (in_array('Walking', $painData->worsened_by) ? '<div class="form-check"><input type="checkbox" checked> Walking</div>' : '<div class="form-check"><input type="checkbox"> Walking</div>') . '
                            <div class="form-check"><input type="checkbox"> Other:</div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Relieved by</th>
                        <td>' .
                            (in_array('Heat', $painData->relieved_by) ? '<div class="form-check"><input type="checkbox" checked> Heat</div>' : '<div class="form-check"><input type="checkbox"> Heat</div>') .
                            (in_array('Ice', $painData->relieved_by) ? '<div class="form-check"><input type="checkbox" checked> Ice</div>' : '<div class="form-check"><input type="checkbox"> Ice</div>') .
                            (in_array('Massage', $painData->relieved_by) ? '<div class="form-check"><input type="checkbox" checked> Massage</div>' : '<div class="form-check"><input type="checkbox"> Massage</div>') .
                            (in_array('Medication', $painData->relieved_by) ? '<div class="form-check"><input type="checkbox" checked> Medication</div>' : '<div class="form-check"><input type="checkbox"> Medication</div>') .
                            (in_array('Repositioning', $painData->relieved_by) ? '<div class="form-check"><input type="checkbox" checked> Repositioning</div>' : '<div class="form-check"><input type="checkbox"> Repositioning</div>') .
                            (in_array('Rest / relaxation', $painData->relieved_by) ? '<div class="form-check"><input type="checkbox" checked> Rest / relaxation</div>' : '<div class="form-check"><input type="checkbox"> Rest / relaxation</div>') . '
                            <div class="form-check"><input type="checkbox"> Other:</div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Effects on function / quality of life</th>
                        <td>' .
                            (in_array('Activities', $painData->effects_on_function) ? '<div class="form-check"><input type="checkbox" checked> Activities</div>' : '<div class="form-check"><input type="checkbox"> Activities</div>') .
                            (in_array('Appetite', $painData->effects_on_function) ? '<div class="form-check"><input type="checkbox" checked> Appetite</div>' : '<div class="form-check"><input type="checkbox"> Appetite</div>') .
                            (in_array('Energy', $painData->effects_on_function) ? '<div class="form-check"><input type="checkbox" checked> Energy</div>' : '<div class="form-check"><input type="checkbox"> Energy</div>') .
                            (in_array('Socialization', $painData->effects_on_function) ? '<div class="form-check"><input type="checkbox" checked> Socialization</div>' : '<div class="form-check"><input type="checkbox"> Socialization</div>') .
                            (in_array('Sleep', $painData->effects_on_function) ? '<div class="form-check"><input type="checkbox" checked> Sleep</div>' : '<div class="form-check"><input type="checkbox"> Sleep</div>') . '
                            <div class="form-check"><input type="checkbox"> Other:</div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Current pain management and effectiveness</th>
                        <td>
                            <span class="dotted-line">' . htmlspecialchars($painData->current_pain_management) . '</span>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Breakthrough pain</th>
                        <td>' .
                            (in_array('Never', $painData->breakthrough_pain) ? '<div class="form-check"><input type="checkbox" checked> Never</div>' : '<div class="form-check"><input type="checkbox"> Never</div>') .
                            (in_array('Less than daily', $painData->breakthrough_pain) ? '<div class="form-check"><input type="checkbox" checked> Less than daily</div>' : '<div class="form-check"><input type="checkbox"> Less than daily</div>') .
                            (in_array('Daily', $painData->breakthrough_pain) ? '<div class="form-check"><input type="checkbox" checked> Daily</div>' : '<div class="form-check"><input type="checkbox"> Daily</div>') .
                            (in_array('Several times a day', $painData->breakthrough_pain) ? '<div class="form-check"><input type="checkbox" checked> Several times a day</div>' : '<div class="form-check"><input type="checkbox"> Several times a day</div>') . '
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Additional pain information</th>
                        <td>
                            <span class="dotted-line">' . htmlspecialchars($painData->additional_pain_information) . '</span>
                        </td>
                    </tr>
                </table>
            </div>';

            // pain assessement

            $painAssessmentHtml = '
            <div class="container">
                <div class="header">
                    <h2>PAIN ASSESSMENT IN ADVANCED DEMENTIA SCALE - PAINAD</h2>
                </div>
                <div>
                    <h3>Instructions</h3>
                    <p>Observe the patient for five minutes before scoring their behaviors.</p>
                    <p>Assess the patient during active periods, such as turning, walking, and transferring.</p>
                    <p>Rate the patient for each of the five observed behaviors.</p>
                    <p>Obtain a total score by adding the scores of the five behaviors.</p>
                    <p>The total score can range from 0 to 10.</p>
                    <p>Note that the 0-10 score of the PAINAD scale is not the same as the 0-10 verbal descriptive pain rating scale.</p>
                </div>
                <table>
                    <tr>
                        <th>Behavior</th>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="behavior" value="0" ' . ($painadData->pain_assessment_behavior == "0" ? 'checked' : '') . '> Normal (0)
                            </div>
                            <div class="form-check">
                                <input type="radio" name="behavior" value="1" ' . ($painadData->pain_assessment_behavior == "1" ? 'checked' : '') . '> Occasional labored breathing or short periods of hyperventilation (1)
                            </div>
                            <div class="form-check">
                                <input type="radio" name="behavior" value="2" ' . ($painadData->pain_assessment_behavior == "2" ? 'checked' : '') . '> Noisy labored breathing, long periods of hyperventilation, Cheyne-Stokes respirations (2)
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>*Negative Vocalizations</th>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="negative-vocalizations" value="0" ' . ($painadData->pain_assessment_negative_vocalizations == "0" ? 'checked' : '') . '> None (0)
                            </div>
                            <div class="form-check">
                                <input type="radio" name="negative-vocalizations" value="1" ' . ($painadData->pain_assessment_negative_vocalizations == "1" ? 'checked' : '') . '> Occasional moaning or groaning, low-level speech with negative or disapproving quality (1)
                            </div>
                            <div class="form-check">
                                <input type="radio" name="negative-vocalizations" value="2" ' . ($painadData->pain_assessment_negative_vocalizations == "2" ? 'checked' : '') . '> Repeated, troubled calls, loud moaning or groaning, crying (2)
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>*Facial Expression</th>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="facial-expression" value="0" ' . ($painadData->pain_assessment_facial_expression == "0" ? 'checked' : '') . '> Smiling or expressionless (0)
                            </div>
                            <div class="form-check">
                                <input type="radio" name="facial-expression" value="1" ' . ($painadData->pain_assessment_facial_expression == "1" ? 'checked' : '') . '> Sad, frightened, frowning (1)
                            </div>
                            <div class="form-check">
                                <input type="radio" name="facial-expression" value="2" ' . ($painadData->pain_assessment_facial_expression == "2" ? 'checked' : '') . '> Facial grimacing (2)
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Body Language</th>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="body-language" value="0" ' . ($painadData->pain_assessment_body_language == "0" ? 'checked' : '') . '> Relaxed (0)
                            </div>
                            <div class="form-check">
                                <input type="radio" name="body-language" value="1" ' . ($painadData->pain_assessment_body_language == "1" ? 'checked' : '') . '> Tense, distressed pacing, fidgeting (1)
                            </div>
                            <div class="form-check">
                                <input type="radio" name="body-language" value="2" ' . ($painadData->pain_assessment_body_language == "2" ? 'checked' : '') . '> Rigid, fists clenched, knees pulled up, pulling or pushing away, striking out (2)
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>*Consolability</th>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="consolability" value="0" ' . ($painadData->pain_consolability == "0" ? 'checked' : '') . '> No need to console (0)
                            </div>
                            <div class="form-check">
                                <input type="radio" name="consolability" value="1" ' . ($painadData->pain_consolability == "1" ? 'checked' : '') . '> Distracted or reassured by voice or touch (1)
                            </div>
                            <div class="form-check">
                                <input type="radio" name="consolability" value="2" ' . ($painadData->pain_consolability == "2" ? 'checked' : '') . '> Unable to console, distract, reassure (2)
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>*PAINAD Total Score:</th>
                        <td>
                            <span class="dotted-line">' . $painadData->painad_total_score . '</span>
                        </td>
                    </tr>
                </table>
            </div>';


            //flacc

            $flaccHtml = '
            <div class="container">
                <div class="header">
                    <h2>FLACC Behavioral Pain Assessment Scale</h2>
                </div>
                <table>
                    <tr>
                        <th>Face</th>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="face" value="0" ' . ($flaccData->flacc_face == "0" ? 'checked' : '') . '> No Particular expression or smile
                            </div>
                            <div class="form-check">
                                <input type="radio" name="face" value="1" ' . ($flaccData->flacc_face == "1" ? 'checked' : '') . '> Occasional grimace or frown; withdrawn, disinterested
                            </div>
                            <div class="form-check">
                                <input type="radio" name="face" value="2" ' . ($flaccData->flacc_face == "2" ? 'checked' : '') . '> Frequent to constant frown, clenched jaw, quivering chin
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Legs</th>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="legs" value="0" ' . ($flaccData->flacc_legs == "0" ? 'checked' : '') . '> Normal position or relaxed
                            </div>
                            <div class="form-check">
                                <input type="radio" name="legs" value="1" ' . ($flaccData->flacc_legs == "1" ? 'checked' : '') . '> Uneasy, restless, tense
                            </div>
                            <div class="form-check">
                                <input type="radio" name="legs" value="2" ' . ($flaccData->flacc_legs == "2" ? 'checked' : '') . '> Arched, rigid, or jerking
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Activity</th>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="activity" value="0" ' . ($flaccData->flacc_activity == "0" ? 'checked' : '') . '> Lying quietly, normal position, moves easily
                            </div>
                            <div class="form-check">
                                <input type="radio" name="activity" value="1" ' . ($flaccData->flacc_activity == "1" ? 'checked' : '') . '> Squirming, shifting back and forth, tense
                            </div>
                            <div class="form-check">
                                <input type="radio" name="activity" value="2" ' . ($flaccData->flacc_activity == "2" ? 'checked' : '') . '> Arched, rigid, or jerking
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Cry</th>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="cry" value="0" ' . ($flaccData->flacc_cry == "0" ? 'checked' : '') . '> No cry (awake or asleep)
                            </div>
                            <div class="form-check">
                                <input type="radio" name="cry" value="1" ' . ($flaccData->flacc_cry == "1" ? 'checked' : '') . '> Moans or whimpers, occasional complaint
                            </div>
                            <div class="form-check">
                                <input type="radio" name="cry" value="2" ' . ($flaccData->flacc_cry == "2" ? 'checked' : '') . '> Crying steadily, screams or sobs, frequent complaints
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Consolability</th>
                        <td>
                            <div class="form-check">
                                <input type="radio" name="consolability" value="0" ' . ($flaccData->flacc_consolability == "0" ? 'checked' : '') . '> Content, relaxed
                            </div>
                            <div class="form-check">
                                <input type="radio" name="consolability" value="1" ' . ($flaccData->flacc_consolability == "1" ? 'checked' : '') . '> Reassured by occasional touching, hugging, or being talked to; distractible
                            </div>
                            <div class="form-check">
                                <input type="radio" name="consolability" value="2" ' . ($flaccData->flacc_consolability == "2" ? 'checked' : '') . '> Difficult to console or comfort
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Total Score</th>
                        <td>
                            <span class="dotted-line">' . $flaccData->total_score . '</span>
                        </td>
                    </tr>
                </table>
            </div>
            ';


            //cardio vasculary

            $cardiovascularHtml = '
            <div class="container">
                <div class="header">
                    <h2>CARDIOVASCULAR</h2>
                </div>
                <table>
                    <tr>
                        <th>Symptoms</th>
                        <td>
                            <div class="form-check">
                                <input type="checkbox" ' . ($cardiovascularData->chest_pain ? 'checked' : '') . '> Chest pain
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($cardiovascularData->dizziness ? 'checked' : '') . '> Dizziness
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th>Edema</th>
                        <td>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('Edema', $cardiovascularData->edema) ? 'checked' : '') . '> Edema
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($cardiovascularData->pedal ? 'checked' : '') . '> Pedal
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($cardiovascularData->right ? 'checked' : '') . '> Right
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($cardiovascularData->left ? 'checked' : '') . '> Left
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($cardiovascularData->sacral ? 'checked' : '') . '> Sacral
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($cardiovascularData->dependent ? 'checked' : '') . '> Dependent
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Pitting Edema Scale</th>
                        <td>
                            <p>1+ Trace: sight indentation, no perceptible swelling, rapid response</p>
                            <p>2+ Mild: indentation subsides rapidly, within 10-15 seconds</p>
                            <p>3+ Moderate: indentation remains for 1-2 minutes</p>
                            <p>4+ Severe: indentation remains for greater than 2 minutes</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Edema Measurements</th>
                        <td>
                            <p>Right Foot:</p>
                            <span class="dotted-line">' . $cardiovascularData->right_foot . '</span>
                            <p>Left Foot:</p>
                            <span class="dotted-line">' . $cardiovascularData->left_foot . '</span>
                            <p>Right Ankle:</p>
                            <span class="dotted-line">' . $cardiovascularData->right_ankle . '</span>
                            <p>Left Ankle:</p>
                            <span class="dotted-line">' . $cardiovascularData->left_ankle . '</span>
                            <p>Right Calf:</p>
                            <span class="dotted-line">' . $cardiovascularData->right_calf . '</span>
                            <p>Left Calf:</p>
                            <span class="dotted-line">' . $cardiovascularData->left_calf . '</span>
                            <p>Right Leg:</p>
                            <span class="dotted-line">' . $cardiovascularData->right_upper_leg . '</span>
                            <p>Left Leg:</p>
                            <span class="dotted-line">' . $cardiovascularData->left_upper_leg . '</span>
                            <p>Right Hand:</p>
                            <span class="dotted-line">' . $cardiovascularData->right_hand . '</span>
                            <p>Left Hand:</p>
                            <span class="dotted-line">' . $cardiovascularData->left_hand . '</span>
                            <p>Right Arm:</p>
                            <span class="dotted-line">' . $cardiovascularData->right_arm . '</span>
                            <p>Left Arm:</p>
                            <span class="dotted-line">' . $cardiovascularData->left_arm . '</span>
                            <p>Right Scrotum:</p>
                            <span class="dotted-line">' . $cardiovascularData->right_scrotum . '</span>
                            <p>Left Scrotum:</p>
                            <span class="dotted-line">' . $cardiovascularData->left_scrotum . '</span>
                            <p>Right Face:</p>
                            <span class="dotted-line">' . $cardiovascularData->right_face . '</span>
                            <p>Left Face:</p>
                            <span class="dotted-line">' . $cardiovascularData->left_face . '</span>
                            </td>
                            </tr>
                            </table>
                            <table>
                            <tr>
                            <th>Irregular heart sounds</th>
                            <td>
                            <div class="form-check">
                            <input type="checkbox" ' . ($cardiovascularData->irregular_heart_sounds ? 'checked' : '') . '> Irregular heart sounds
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . ($cardiovascularData->neck_vein_distention ? 'checked' : '') . '> Neck Vein Distention
                            </div>
                            </td>
                            </tr>
                            </table>
                            <table>
                            <tr>
                            <th>Devices</th>
                            <td>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('Pacemaker', $cardiovascularData->devices) ? 'checked' : '') . '> Pacemaker: date Inserted
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('Left Ventricular Assist Device', $cardiovascularData->devices) ? 'checked' : '') . '> Left Ventricular Assist Device
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('Activated Automated Implantable Cardioverter Defibrillator', $cardiovascularData->devices) ? 'checked' : '') . '> Activated Automated Implantable Cardioverter Defibrillator
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('Deactivated Automated Implantable Cardioverter Defibrillator', $cardiovascularData->devices) ? 'checked' : '') . '> Deactivated Automated Implantable Cardioverter Defibrillator
                            </div>
                            </td>
                            </tr>
                            </table>
                            <table>
                            <tr>
                            <th>Additional details - cardiovascular</th>
                            <td>
                            <div class="form-check">
                            <input type="checkbox" ' . ($cardiovascularData->additional_details ? 'checked' : '') . '> Peripheral Pulses:
                            </div>
                            </td>
                            </tr>
                            </table>
                            <table>
                            <tr>
                            <th>Present</th>
                            <td>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('RUE', $cardiovascularData->present) ? 'checked' : '') . '> RUE
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('RLE', $cardiovascularData->present) ? 'checked' : '') . '> RLE
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('LUE', $cardiovascularData->present) ? 'checked' : '') . '> LUE
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('LLE', $cardiovascularData->present) ? 'checked' : '') . '> LLE
                            </div>
                            </td>
                            </tr>
                            </table>
                            <table>
                            <tr>
                            <th>Bounding</th>
                            <td>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('RUE', $cardiovascularData->bounding) ? 'checked' : '') . '> RUE
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('RLE', $cardiovascularData->bounding) ? 'checked' : '') . '> RLE
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('LUE', $cardiovascularData->bounding) ? 'checked' : '') . '> LUE
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('LLE', $cardiovascularData->bounding) ? 'checked' : '') . '> LLE
                            </div>
                            </td>
                            </tr>
                            </table>
                            <table>
                            <tr>
                            <th>Weak / Thready</th>
                            <td>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('RUE', $cardiovascularData->weak_thready) ? 'checked' : '') . '> RUE
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('RLE', $cardiovascularData->weak_thready) ? 'checked' : '') . '> RLE
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('LUE', $cardiovascularData->weak_thready) ? 'checked' : '') . '> LUE
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('LLE', $cardiovascularData->weak_thready) ? 'checked' : '') . '> LLE
                            </div>
                            </td>
                            </tr>
                            </table>
                            <table>
                            <tr>
                            <th>Absent</th>
                            <td>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('RUE', $cardiovascularData->absent) ? 'checked' : '') . '> RUE
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('RLE', $cardiovascularData->absent) ? 'checked' : '') . '> RLE
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('LUE', $cardiovascularData->absent) ? 'checked' : '') . '> LUE
                            </div>
                            <div class="form-check">
                            <input type="checkbox" ' . (in_array('LLE', $cardiovascularData->absent) ? 'checked' : '') . '> LLE
                            </div>
                            </td>
                            </tr>
                            </table>
                            <table>
                            <tr>
                            <th>Cardiovascular Note</th>
                            <td>
                            <div class="form-check">
                            <input type="checkbox" ' . ($cardiovascularData->cardiovascular_note ? 'checked' : '') . '> Other:
                            </div>
                            </td>
                            </tr>
                            </table>
            </div>
            ';



            // respiratory
            $respiratoryHtml = '
            <div class="container">
                <div class="header">
                    <h2>RESPIRATORY</h2>
                </div>
                <table>
                    <tr>
                        <th>Clear</th>
                        <td>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RUL', $respiratoryData->clear) ? 'checked' : '') . '> RUL
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RML', $respiratoryData->clear) ? 'checked' : '') . '> RML
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RLL', $respiratoryData->clear) ? 'checked' : '') . '> RLL
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('LUL', $respiratoryData->clear) ? 'checked' : '') . '> LUL
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('LLL', $respiratoryData->clear) ? 'checked' : '') . '> LLL
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th>Diminished</th>
                        <td>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RUL', $respiratoryData->diminished) ? 'checked' : '') . '> RUL
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RML', $respiratoryData->diminished) ? 'checked' : '') . '> RML
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RLL', $respiratoryData->diminished) ? 'checked' : '') . '> RLL
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('LUL', $respiratoryData->diminished) ? 'checked' : '') . '> LUL
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('LLL', $respiratoryData->diminished) ? 'checked' : '') . '> LLL
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th>Note</th>
                        <td>
                            <span class="dotted-line">' . $respiratoryData->note . '</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Breathing</th>
                        <td>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('Apnea', $respiratoryData->breathing) ? 'checked' : '') . '> Apnea
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('Agonal', $respiratoryData->breathing) ? 'checked' : '') . '> Agonal
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('Cheyne-Stokes', $respiratoryData->breathing) ? 'checked' : '') . '> Cheyne-Stokes
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('Other', $respiratoryData->breathing) ? 'checked' : '') . '> Other
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th>Oxygen use</th>
                        <td>
                            <p>Fio2 - Inhaled O2 Concentration:</p>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('CPAP', $respiratoryData->oxygen_use) ? 'checked' : '') . '> CPAP
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('BIPAP', $respiratoryData->oxygen_use) ? 'checked' : '') . '> BIPAP
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('Cough', $respiratoryData->oxygen_use) ? 'checked' : '') . '> Cough
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('Increase in respiratory secretions/audible congestion', $respiratoryData->oxygen_use) ? 'checked' : '') . '> Increase in respiratory secretions/audible congestion
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('Other', $respiratoryData->oxygen_use) ? 'checked' : '') . '> Other
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('Sputum', $respiratoryData->oxygen_use) ? 'checked' : '') . '> Sputum
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('Hemoptysis', $respiratoryData->oxygen_use) ? 'checked' : '') . '> Hemoptysis
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('Other', $respiratoryData->oxygen_use) ? 'checked' : '') . '> Other
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th>Shortness of Breath Screening</th>
                        <td>
                            <p>Key: 0 - None 1-3 - Mild 4-7 - Moderate 8-10 - Severe</p>
                            <p>Shortness of Breath level now:</p>
                            <span class="dotted-line">' . $respiratoryData->shortness_of_breath['level_now'] . '</span>
                            <p>Worst Shortness of Breath level experienced:</p>
                            <span class="dotted-line">' . $respiratoryData->shortness_of_breath['worst_level'] . '</span>
                            <p>Best Shortness of Breath level experienced:</p>
                            <span class="dotted-line">' . $respiratoryData->shortness_of_breath['best_level'] . '</span>
                            <p>Patient\'s acceptable level of Shortness of Breath:</p>
                            <span class="dotted-line">' . $respiratoryData->shortness_of_breath['acceptable_level'] . '</span>
                            <div class="form-check">
                                <input type="checkbox" ' . ($respiratoryData->shortness_of_breath['walk_without_shortness'] ? 'checked' : '') . '> Able to walk 20 ft without shortness of breath
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
            ';

            // genitourinary
            $genitourinaryHtml = '
            <div class="container">
                <div class="header">
                    <h2>GENITOURINARY</h2>
                </div>
                <table>
                    <tr>
                        <th>Absence of urinary output in 24 hr.</th>
                        <td>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->absence_urinary_output ? 'checked' : '') . '> Absence of urinary output in 24 hr.
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->decrease_urinary_output ? 'checked' : '') . '> Decrease in urinary output
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->change_bladder_incontinence ? 'checked' : '') . '> Change in bladder incontinence
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->distension ? 'checked' : '') . '> Distension
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->incontinence ? 'checked' : '') . '> Incontinence
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->retention ? 'checked' : '') . '> Retention
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->current_ss_infection['burning'] ? 'checked' : '') . '> Burning
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->current_ss_infection['hematuria'] ? 'checked' : '') . '> Hematuria
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->current_ss_infection['fever'] ? 'checked' : '') . '> Fever
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->current_ss_infection['spasms'] ? 'checked' : '') . '> Spasms
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->current_ss_infection['foul_smelling_urine'] ? 'checked' : '') . '> Foul or strong smelling urine
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->current_ss_infection['cloudy_urine'] ? 'checked' : '') . '> Cloudy urine
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->current_ss_infection['other'] ? 'checked' : '') . '> Other
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->indwelling_catheter_flush ? 'checked' : '') . '> Indwelling Catheter: Flush: Size fr ml balloon Size :
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->other_catheter ? 'checked' : '') . '> Other catheter :
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->no_deficit ? 'checked' : '') . '> No deficit :
                            </div>
                            <p>Urinary Diversion /Ostomy:</p>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->urinary_diversion_ostomy_ileal_conduit ? 'checked' : '') . '> Ileal conduit Site / flush :
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->urinary_diversion_ostomy_nephrostomy ? 'checked' : '') . '> Nephrostomy Site / flush
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->urinary_diversion_ostomy_ureterostomy ? 'checked' : '') . '> Ureterostomy Site / flush :
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->urinary_diversion_ostomy_other ? 'checked' : '') . '> Other Site / flush
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->urinary_diversion_ostomy_suprapubic_catheter ? 'checked' : '') . '> Suprapubic Catheter:
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($genitourinaryData->urinary_diversion_ostomy_condom_catheter ? 'checked' : '') . '> Condom Catheter
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Flush</th>
                        <td>
                            <span class="dotted-line">' . $genitourinaryData->flush . '</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Size / Balloon</th>
                        <td>
                            <span class="dotted-line">' . $genitourinaryData->size_balloon . '</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Describe deficits</th>
                        <td>
                            <span class="dotted-line">' . $genitourinaryData->describe_deficits . '</span>
                        </td>
                    </tr>
                </table>
            </div>
            ';


            //GASTROINTESTINAL
            $gastrointestinalHtml = '
            <div class="container">
                <div class="header">
                    <h2>GASTROINTESTINAL</h2>
                </div>
                <table style="margin-top: -1em;">
                    <tr style="margin-top: -1em;">
                        <th style="margin-top: -1em;">Assessment</th>
                        <td style="margin-top: -1em;">
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->last_bm ? 'checked' : '') . '> Last BM
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->unknown ? 'checked' : '') . '> Unknown
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->bowel_sounds ? 'checked' : '') . '> Bowel sounds
                            </div>
                            <p>Present:</p>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RUQ', $gastrointestinalData->present) ? 'checked' : '') . '> RUQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RLQ', $gastrointestinalData->present) ? 'checked' : '') . '> RLQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('LUQ', $gastrointestinalData->present) ? 'checked' : '') . '> LUQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('LLQ', $gastrointestinalData->present) ? 'checked' : '') . '> LLQ
                            </div>
                            <p>Hyper-active:</p>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RUQ', $gastrointestinalData->hyper_active) ? 'checked' : '') . '> RUQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RLQ', $gastrointestinalData->hyper_active) ? 'checked' : '') . '> RLQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('LUQ', $gastrointestinalData->hyper_active) ? 'checked' : '') . '> LUQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('LLQ', $gastrointestinalData->hyper_active) ? 'checked' : '') . '> LLQ
                            </div>
                            <p>Hypo-active:</p>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RUQ', $gastrointestinalData->hypo_active) ? 'checked' : '') . '> RUQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RLQ', $gastrointestinalData->hypo_active) ? 'checked' : '') . '> RLQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('LUQ', $gastrointestinalData->hypo_active) ? 'checked' : '') . '> LUQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('LLQ', $gastrointestinalData->hypo_active) ? 'checked' : '') . '> LLQ
                            </div>
                            <p>Absent:</p>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RUQ', $gastrointestinalData->absent) ? 'checked' : '') . '> RUQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('RLQ', $gastrointestinalData->absent) ? 'checked' : '') . '> RLQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('LUQ', $gastrointestinalData->absent) ? 'checked' : '') . '> LUQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . (in_array('LLQ', $gastrointestinalData->absent) ? 'checked' : '') . '> LLQ
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->rectal_bleeding ? 'checked' : '') . '> Rectal bleeding
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->hemorrhoids ? 'checked' : '') . '> Hemorrhoids
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->bowel_incontinence ? 'checked' : '') . '> Bowel Incontinence
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->change_bowel_incontinence ? 'checked' : '') . '> Change in bowel incontinence
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->constipation ? 'checked' : '') . '> Constipation
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->diarrhea ? 'checked' : '') . '> Diarrhea
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->ascites ? 'checked' : '') . '> Ascites
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->ostomy_details ? 'checked' : '') . '> Ostomy Details
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->drain_details ? 'checked' : '') . '> Drain Details
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->anorexia ? 'checked' : '') . '> Anorexia
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->cachexia ? 'checked' : '') . '> Cachexia
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->nausea ? 'checked' : '') . '> Nausea
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->vomiting ? 'checked' : '') . '> Vomiting
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->no_intake_last_24hrs ? 'checked' : '') . '> No intake last 24 hrs
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->swallowing_deficits ? 'checked' : '') . '> Swallowing deficits
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->inability_swallow ? 'checked' : '') . '> Inability to swallow (change)
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Diet</th>
                        <td>
                            <span class="dotted-line">' . $gastrointestinalData->diet . '</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Percentage eaten in 24 hr</th>
                        <td>
                            <span class="dotted-line">' . $gastrointestinalData->percentage_eaten . '</span>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->npo ? 'checked' : '') . '> NPO
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th>Tube feeding</th>
                        <td>
                            <p>Type /Amount:</p>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->tube_feeding ? 'checked' : '') . '> Tube feeding
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->placement_checked ? 'checked' : '') . '> Placement checked
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th>Most Recent RBS</th>
                        <td>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->hyperglycemia ? 'checked' : '') . '> Hyperglycemia
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->hypoglycemia ? 'checked' : '') . '> Hypoglycemia
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->other ? 'checked' : '') . '> Other
                            </div>
                            <div class="form-check">
                                <input type="checkbox" ' . ($gastrointestinalData->no_deficit ? 'checked' : '') . '> No deficit
                            </div>
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th>Describe deficits</th>
                        <td>
                            <span class="dotted-line">' . $gastrointestinalData->describe_deficits . '</span>
                        </td>
                    </tr>
                </table>
            </div>
            ';

            $chartHtml = '
                <div class="container">
                    <div class="header">
                        <h2>Clinical Note</h2>
                    </div>
                    <div>
                        <h4>Chart: 1 Benefit Period: '.$noteData['benefit_period']['period_number'].' Level of Care Routine Home Care 10/05/2024</h4>
                    </div>
                    <table>
                        <tr>
                            <th>Time In:</th>
                            <td>'.$noteData['time_in'].'</td>
                        </tr>
                        <tr>
                            <th>Time Out:</th>
                            <td>'.$noteData['time_out'].'</td>
                        </tr>
                    </table>
                    <h4>Patient Information</h4>
                    <table>
                        <tr>
                            <th>Patient Name:</th>
                            <td>'.$noteData['benefit_period']['patient']['last_name'].' '.$noteData['benefit_period']['patient']['first_name'].'</td>
                        </tr>
                        <tr>
                            <th>Patient Number:</th>
                            <td>'.$noteData['patient_number'].'</td>
                        </tr>
                        <tr>
                            <th>Location Name:</th>
                            <td>'.$noteData['location_name'].'</td>
                        </tr>
                        <tr>
                            <th>Benefit Period:</th>
                            <td>'.$noteData['benefit_period']['start_date'].' to '.$noteData['benefit_period']['end_date'].'</td>
                        </tr>
                        <tr>
                            <th>DOB:</th>
                            <td>'.$noteData['benefit_period']['patient']['date_of_birth'].'</td>
                        </tr>
                        <tr>
                            <th>Location Number:</th>
                            <td>'.$noteData['location_number'].'</td>
                        </tr>
                        <tr>
                            <th>PRN Visit:</th>
                            <td>'.($noteData['prn_visit'] ? 'Yes' : 'No').'</td>
                        </tr>
                    </table>
                    <h4>Benefit Period Dates</h4>
                    <p>From '.$noteData['benefit_period']['start_date'].' To '.$noteData['benefit_period']['end_date'].'</p>
                    <h4>Two (or more) patient identifiers used this visit:</h4>
                    <table>
                        <tr>
                            <th>Identifiers:</th>
                            <td>
                                <div class="form-check">
                                    '.(in_array('Assigned identification number (for example, MBI, SSN)', $noteData['patient_identifiers']) ? '<input type="checkbox" checked> Assigned identification number (for example, MBI, SSN)' : '<input type="checkbox"> Assigned identification number (for example, MBI, SSN)').'
                                </div>
                                <div class="form-check">
                                    '.(in_array('Insurance card', $noteData['patient_identifiers']) ? '<input type="checkbox" checked> Insurance card' : '<input type="checkbox"> Insurance card').'
                                </div>
                                <div class="form-check">
                                    '.(in_array('Passport', $noteData['patient_identifiers']) ? '<input type="checkbox" checked> Passport' : '<input type="checkbox"> Passport').'
                                </div>
                                <div class="form-check">
                                    '.(in_array('Other patient identifier(s) used this visit:', $noteData['patient_identifiers']) ? '<input type="checkbox" checked> Other patient identifier(s) used this visit:' : '<input type="checkbox"> Other patient identifier(s) used this visit:').'
                                </div>
                                <div class="form-check">
                                    '.(in_array('Direct facial recognition (known to staff)', $noteData['patient_identifiers']) ? '<input type="checkbox" checked> Direct facial recognition (known to staff)' : '<input type="checkbox"> Direct facial recognition (known to staff)').'
                                </div>
                                <div class="form-check">
                                    '.(in_array('Patient address confirmed', $noteData['patient_identifiers']) ? '<input type="checkbox" checked> Patient address confirmed' : '<input type="checkbox"> Patient address confirmed').'
                                </div>
                                <div class="form-check">
                                    '.(in_array('Social Security Card', $noteData['patient_identifiers']) ? '<input type="checkbox" checked> Social Security Card' : '<input type="checkbox"> Social Security Card').'
                                </div>
                                <div class="form-check">
                                    '.(in_array('Driver\'s license', $noteData['patient_identifiers']) ? '<input type="checkbox" checked> Driver\'s license' : '<input type="checkbox"> Driver\'s license').'
                                </div>
                                <div class="form-check">
                                    '.(in_array('Patient Name', $noteData['patient_identifiers']) ? '<input type="checkbox" checked> Patient Name' : '<input type="checkbox"> Patient Name').'
                                </div>
                                <div class="form-check">
                                    '.(in_array('Unknown or not assessed', $noteData['patient_identifiers']) ? '<input type="checkbox" checked> Unknown or not assessed' : '<input type="checkbox"> Unknown or not assessed').'
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>';

            // Combine both HTML contents with a page break between them
            $html = '
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>PDF Content</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        color: #4a5568;
                    }
                    .container {
                        border-radius: 5px;
                        box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.1);
                        padding: 20px;
                        margin: 20px;
                    }
                    .header {
                        background-color: #44BBB59F;
                        color: #ffffff;
                        border-top-right-radius: 5px;
                        padding-left: 10px;
                        padding: 10px;
                    }
                    h2 {
                        margin: 0;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-bottom: 5px;
                    }
                    th, td {
                        padding: 10px;
                        border: 1px solid #ddd;
                        text-align: left;
                    }
                    th {
                        background-color: #f4f4f4;
                        width: 30%;
                    }
                    .dotted-line {
                        border-bottom: 1px dotted #000;
                        width: 100%;
                        display: inline-block;
                    }
                    .form-check {
                        margin-bottom: 10px;
                    }
                    .form-check input {
                        margin-right: 10px;
                    }
                </style>
            </head>
            <body>
           
                ' .   $chartHtml   . '
                <div style="page-break-before: always;"></div>
                ' . $vitalSignsHtml . '
                <div style="page-break-before: always;"></div>
                ' . $scalesToolsHtml . '
                <div style="page-break-before: always;"></div>
                ' . $painHtml  . '
                <div style="page-break-before: always;"></div>
                ' . $painAssessmentHtml  . '
                <div style="page-break-before: always;"></div>
                ' .  $flaccHtml  . '
                <div style="page-break-before: always;"></div>
                ' .   $cardiovascularHtml   . '
                <div style="page-break-before: always;"></div>
                ' .   $respiratoryHtml   . '
                <div style="page-break-before: always;"></div>
                ' .   $genitourinaryHtml   . '
                <div style="page-break-before: always;"></div>
                ' .   $gastrointestinalHtml   . '
                <div class="footer">
                    Page {PAGE_NUM} of {PAGE_COUNT}
                </div>
            </body>
            </html>
            ';

            // Configure Dompdf options using array
            $pdf = PDF::loadHTML($html)->setPaper('a4', 'portrait')->setWarnings(false)->setOptions([
                'isHtml5ParserEnabled' => true,
                'isRemoteEnabled' => true,
            ]);

            return $pdf->download('output.pdf');
        // } catch (\Exception $e) {
        //     Log::error('Error generating PDF: ' . $e->getMessage());
            return response()->json(['error' => 'Error generating PDF'], 500);
        // }
    }

    
    

}
