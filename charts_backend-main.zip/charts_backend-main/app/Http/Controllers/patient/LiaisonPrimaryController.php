<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\LiaisonPrimary;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LiaisonPrimaryController extends Controller
{
    public function index()
    {
        $liaisonPrimary = LiaisonPrimary::all();
        return response()->json($liaisonPrimary);
    }

    public function store(Request $request)
    {
         // Validation des données de la requête
         $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:liaison_primary,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        $liaisonPrimary = LiaisonPrimary::create([
            'name' => $request->name,
        ]);

        // Réponse JSON en cas de succès
        return response()->json([
                    'message' => 'liaison primary created successfully ',
                   'data' => $liaisonPrimary,
                 ], 200);
    }
    public function show($id)
    {
        try {
            $liaisonPrimary = LiaisonPrimary::findOrFail($id);
            return response()->json($liaisonPrimary);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No  liaison primary found'], 404);
        }
    }
    public function update(Request $request, $id)
    {
          // Validation des données de la requête
          $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:liaison_primary,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        try {
            $liaisonPrimary =   LiaisonPrimary::findOrFail($id);
            $liaisonPrimary->update([
                'name' => $request->name,
            ]);
            // Réponse JSON en cas de succès
            return response()->json([
                        'message' => 'liaison primary update successfully ',
                       'data' => $liaisonPrimary,
                     ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No  liaison primary found.'], 404);
        }
    }

    public function destroy($id)
    {
        try {
    $liaisonPrimary = LiaisonPrimary::findOrFail($id);
    $liaisonPrimary->delete();
    return response()->json( ['message' => ' liaison primary delete successfully ']);
    //code...
} catch (ModelNotFoundException $e) {
    return response()->json(['error' => 'No  liaison primary found.'], 404);
}
    }
}

