<?php

namespace App\Http\Controllers\patient;

use App\Models\Patient;

use Illuminate\Http\Request;
use App\Models\BenefitPeriod;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class PatientController extends Controller
{
    public function index()
    {
        $patients = Patient::select(
            'patients.id', // Utilisez l'alias 'patient_id' pour éviter les conflits
                'patients.first_name',
                'patients.preferred_name',
                'patients.mi',
                'patients.suffix',
                'patients.last_name',
                'patients.oxygen_dependent',
                'patients.patient_consents',
                'patients.ssn',
                'patients.genders',
                'patients.date_of_birth',
                'race_ethnicity.name as race_ethnicity_name',
                'dme_providers.name as dme_provider_name',
                'primary_diagnoses.name as primary_diagnosis_name',
                'patient_pharmacies.name as patient_pharmacy_name',
                'emergency_preparedness_level.name as emergency_preparedness_level_name',
                )
                ->leftJoin('patient_pharmacies', 'patients.patient_pharmacy_id', '=', 'patient_pharmacies.id')
                ->leftJoin('dme_providers', 'patients.dme_provider_id', '=', 'dme_providers.id')
                ->leftJoin('primary_diagnoses', 'patients.primary_diagnosis_id', '=', 'primary_diagnoses.id')
                ->leftJoin('race_ethnicity', 'patients.race_ethnicity_id', '=', 'race_ethnicity.id')
                ->leftJoin('emergency_preparedness_level', 'patients.emergency_preparedness_level_id', '=', 'emergency_preparedness_level.id')
        ->get();
    
        return response()->json($patients);
    }

    public function store(Request $request)
    {
         // Validation des données de la requête
         $validatedData = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'mi' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'preferred_name' => 'required|string|max:255',
            'date_of_birth' => 'required|date_format:Y-m-d',
            'dnr_id' => 'required|exists:dnr,id',
            'suffix' => 'required|string',
            'ssn' => 'required|integer',
            'hipaa_received' => 'required',
            'race_ethnicity_id' => 'required|exists:race_ethnicity,id',
            'liaison_primary_id' => 'required|exists:liaison_primary,id',
            'liaison_secondary_id' => 'required|exists:liaison_secondary,id',
            'emergency_preparedness_level_id' => 'required|exists:emergency_preparedness_level,id',
            'oxygen_dependent' => 'required',
            'patient_consents' => 'required',
            'genders' => 'required',
            'dme_provider_id' => 'required|exists:dme_providers,id',
            'primary_diagnosis_id' => 'required|exists:primary_diagnoses,id',
            'patient_pharmacy_id' => 'required|exists:patient_pharmacies,id',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        $patient = Patient::create([
            'first_name' => $request->first_name,
            'mi' => $request->mi,
            'last_name' => $request->last_name,
            'preferred_name' => $request->preferred_name,
            'date_of_birth' => $request->date_of_birth,
            'dnr_id' => $request->dnr_id,
            'recert' => $request->recert,
            'suffix' => $request->suffix,
            'ssn' => $request->ssn,
            'hipaa_received' => $request->hipaa_received,
            'race_ethnicity_id' => $request->race_ethnicity_id,
            'liaison_primary_id' => $request->liaison_primary_id,
            'liaison_secondary_id' => $request->liaison_secondary_id,
            'emergency_preparedness_level_id' => $request->emergency_preparedness_level_id,
            'oxygen_dependent' => $request->oxygen_dependent,
            'patient_consents' => $request->patient_consents,
            'genders' => $request->genders,
            'dme_provider_id' => $request->dme_provider_id,
            'primary_diagnosis_id' => $request->primary_diagnosis_id,
            'patient_pharmacy_id' => $request->patient_pharmacy_id,
        ]);

        // Création du "benefit period"
        
        $startDate = now(); // Date de début actuelle
        $endDate = $startDate->copy()->addMonths(3); // Exemple: 6 mois après la date de début
        $periodNumber = 1; // Numéro de période initiale, ajustez si nécessaire

        BenefitPeriod::create([
            'patient_id' => $patient->id,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'period_number' => $periodNumber,
        ]);


        // Réponse JSON en cas de succès
        return response()->json([
                    'message' => 'Patient created successfully ',
                   'data' => $patient,
                 ], 200);
    }
    public function show($id)
    {
        try {
            $patient = Patient::findOrFail($id);
    
            return response()->json($patient);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No Patient found.'], 404);
        }
    }
    
    
    public function update(Request $request, $id)
    {
        $validatedData = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'mi' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'preferred_name' => 'required|string|max:255',
            'date_of_birth' => 'required|date_format:Y-m-d',
            'dnr_id' => 'required|exists:dnr,id',
            'suffix' => 'required|string',
            'ssn' => 'required|integer',
            'hipaa_received' => 'required',
            'race_ethnicity_id' => 'required|exists:race_ethnicity,id',
            'liaison_primary_id' => 'required|exists:liaison_primary,id',
            'liaison_secondary_id' => 'required|exists:liaison_secondary,id',
            'emergency_preparedness_level_id' => 'required|exists:emergency_preparedness_level,id',
            'oxygen_dependent' => 'required',
            'patient_consents' => 'required|',
            'genders' => 'required',
            'dme_provider_id' => 'required|exists:dme_providers,id',
            'primary_diagnosis_id' => 'required|exists:primary_diagnoses,id',
            'patient_pharmacy_id' => 'required|exists:patient_pharmacies,id',
        ]);
        


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        try {
            $patient =   Patient::findOrFail($id);
            $patient->update([
                'first_name' => $request->first_name,
                'mi' => $request->mi,
                'last_name' => $request->last_name,
                'preferred_name' => $request->preferred_name,
                'date_of_birth' => $request->date_of_birth,
                'dnr_id' => $request->dnr_id,
                'recert' => $request->recert,
                'suffix' => $request->suffix,
                'ssn' => $request->ssn,
                'hipaa_received' => $request->hipaa_received,
                'race_ethnicity_id' => $request->race_ethnicity_id,
                'liaison_primary_id' => $request->liaison_primary_id,
                'liaison_secondary_id' => $request->liaison_secondary_id,
                'emergency_preparedness_level_id' => $request->emergency_preparedness_level_id,
                'oxygen_dependent' => $request->oxygen_dependent,
                'patient_consents' => $request->patient_consents,
                'genders' => $request->genders,
                'dme_provider_id' => $request->dme_provider_id,
                'primary_diagnosis_id' => $request->primary_diagnosis_id,
                'patient_pharmacy_id' => $request->patient_pharmacy_id,
            ]);
            // Réponse JSON en cas de succès
            return response()->json([
                        'message' => 'Patient update successfully ',
                       'data' => $patient,
                     ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Patient not found.'], 404);
        }
    }

    public function destroy($id)
    {
        try {
    $patient = Patient::findOrFail($id);
    $patient->delete();
    return response()->json( ['message' => 'Patient delete successfully ']);
    //code...
} catch (ModelNotFoundException $e) {
    return response()->json(['error' => 'Patient not found.'], 404);
}
    }
}
