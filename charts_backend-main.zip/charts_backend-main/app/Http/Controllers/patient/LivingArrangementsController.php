<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\LivingArrangements;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class LivingArrangementsController extends Controller
{
    public function index()
    {
        $livingArrangements = LivingArrangements::all();
        return response()->json($livingArrangements);
    }
    public function livingArrangementsList()
    {
        $livingArrangements = LivingArrangements::all();
        return response()->json($livingArrangements);
    }
    public function store(Request $request)
    {
        // Valider les données entrantes
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'primary_caregiver' => 'required',
            'primary_location_of_patient' => 'required',
            'caregiver_availability' => 'required',
            'patient_able' => 'required',
            'need_hospice_service' => 'required',
        ]);

        $livingArrangements = LivingArrangements::where('patient_id', $validatedData['patient_id'])->first();

        if ($livingArrangements) {
            // Vérifier et ajouter les champs non vides
           
            $updateData = [
                'primary_caregiver' => $validatedData['primary_caregiver'],
                'primary_location_of_patient' => $validatedData['primary_location_of_patient'],
                'caregiver_availability' => $validatedData['caregiver_availability'],
                'patient_able' => $validatedData['patient_able'],
            ];
            $need_hospice_service_ids = $validatedData['need_hospice_service'];
            if (!empty($need_hospice_service_ids )) {
               $updateData['need_hospice_service'] = implode(',', $validatedData['need_hospice_service']);
           }
            $livingArrangements->update($updateData);
        } else {
            // Créer de nouvelles données
           
            $createData = [
                'patient_id' => $validatedData['patient_id'],
                'primary_caregiver' => $validatedData['primary_caregiver'],
                'primary_location_of_patient' => $validatedData['primary_location_of_patient'],
                'caregiver_availability' => $validatedData['caregiver_availability'],
                'patient_able' => $validatedData['patient_able'],
            ];
            // Vérifier et ajouter les champs non vides
            $need_hospice_service_ids = $validatedData['need_hospice_service'];
            if (!empty($need_hospice_service_ids )) {
               $updateData['need_hospice_service'] = implode(',', $validatedData['need_hospice_service']);
           }
            $livingArrangements = LivingArrangements::create($createData);
        }
        // Réponse JSON en cas de succès
        return response()->json([
            'message' => 'LivingArrangements créé ou mis à jour avec succès.',
            'data' => $livingArrangements,
        ], 201);
    }

    public function show($id)
    {
        try {
            // Recherchez les LivingArrangements correspondant à l'ID du patient
            $livingArrangements = LivingArrangements::where('patient_id', $id)->firstOrFail();
            return response()->json($livingArrangements);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No LivingArrangements found for this LivingArrangements'], 404);
        }
    }
}
