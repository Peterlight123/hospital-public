<?php

namespace App\Http\Controllers\patient;

use Illuminate\Http\Request;
use App\Models\PatientIdentifier;
use App\Http\Controllers\Controller;

class PatientIdentifiersController extends Controller
{
    /**
     * PatientIdentifiersController handles CRUD operations for patient identifiers
     */

    /**
     * Display a listing of all patient identifiers
     * 
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $patientIdentifiers = PatientIdentifier::all();
        return response()->json($patientIdentifiers);
    }

    /**
     * Store a newly created patient identifier
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        $patientIdentifier = PatientIdentifier::create($request->all());
        return response()->json($patientIdentifier);
    }

    /**
     * Display the specified patient identifier
     * 
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $patientIdentifier = PatientIdentifier::find($id);
        return response()->json($patientIdentifier);
    }

    /**
     * Update the specified patient identifier
     * 
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $id)
    {
        $patientIdentifier = PatientIdentifier::find($id);
        $patientIdentifier->update($request->all());
        return response()->json($patientIdentifier);
    }

    /**
     * Remove the specified patient identifier
     * 
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($id)
    {
        $patientIdentifier = PatientIdentifier::find($id);
        $patientIdentifier->delete();
        return response()->json(null, 204);
    }
    
    
    
    
}
