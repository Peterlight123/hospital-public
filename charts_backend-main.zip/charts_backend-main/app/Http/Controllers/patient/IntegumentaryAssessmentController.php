<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\Integumentary;
use App\Models\IntegumentaryAssessment;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class IntegumentaryAssessmentController extends Controller
{
    public function index()
    {
        $integumentary = IntegumentaryAssessment::all();
        return response()->json($integumentary);
    }
    public function integumentaryList()
    {
        $integumentary = Integumentary::all();
        return response()->json($integumentary);
    }
    public function store(Request $request)
    {
        // Valider les données entrantes
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'integumentary_ids' => 'required',
        ]);

        $integumentary = IntegumentaryAssessment::where('patient_id', $validatedData['patient_id'])->first();

        if ($integumentary) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['integumentary_ids'])) {
                $updateData['integumentary_ids'] = implode(',', $validatedData['integumentary_ids']);
            }
            $integumentary->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['integumentary_ids'])) {
                $createData['integumentary_ids'] = implode(',', $validatedData['integumentary_ids']);
            }
            $integumentary = IntegumentaryAssessment::create($createData);
        }
        // Réponse JSON en cas de succès
        return response()->json([
            'message' => 'integumentary créé ou mis à jour avec succès.',
            'data' => $integumentary,
        ], 201);
    }

    public function show($id)
    {
        try {
            // Recherchez les integumentary correspondant à l'ID du patient
            $integumentary = IntegumentaryAssessment::where('patient_id', $id)->firstOrFail();
            return response()->json($integumentary);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No integumentary found for this integumentary'], 404);
        }
    }
}
