<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\VisitInformation;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class VisitInformationController extends Controller
{
    public function store(Request $request)
    {
      // Valider les données entrantes
      $validatedData = $request->validate([
        'patient_id' => 'required|exists:patients,id', // Assurez-vous que l'ID du patient existe
        'visit_date' => 'nullable',
        'visit_time_in' => 'nullable',
        'travel_time_in' => 'nullable',
        'visit_time_out' => 'nullable',
        'travel_time_out' => 'nullable',
        'documenttation_time' => 'nullable',
        'associated_mileage' => 'nullable',
        'surcharge' => 'nullable',
        // Ajoutez plus de règles de validation au besoin
    ]);

    // Vérifier si l'ID du patient existe dans la table visitInformation
    $visitInformation = VisitInformation::where('patient_id', $validatedData['patient_id'])->first();

    if ($visitInformation) {
        // Mettre à jour les informations de visite existantes
        $visitInformation->update([
            'visit_date' => $validatedData['visit_date'],
            'visit_time_in' => $validatedData['visit_time_in'],
            'travel_time_in' => $validatedData['travel_time_in'],
            'travel_time_out' => $validatedData['travel_time_out'],
            'visit_time_out' => $validatedData['visit_time_out'],
            'documenttation_time' => $validatedData['documenttation_time'],
            'associated_mileage' => $validatedData['associated_mileage'],
            'surcharge' => $validatedData['surcharge']
        ]);
    } else {
        // Créer de nouvelles informations de visite
        $visitInformation = VisitInformation::create([
            'patient_id' => $validatedData['patient_id'],
            'visit_date' => $validatedData['visit_date'],
            'visit_time_in' => $validatedData['visit_time_in'],
            'travel_time_in' => $validatedData['travel_time_in'],
            'travel_time_out' => $validatedData['travel_time_out'],
            'visit_time_out' => $validatedData['visit_time_out'],
            'documenttation_time' => $validatedData['documenttation_time'],
            'associated_mileage' => $validatedData['associated_mileage'],
            'surcharge' => $validatedData['surcharge'],
        ]);
    }

       return response()->json(['message' => 'Données sauvegardées avec succès','data' => $visitInformation,], 200);
    }

    public function show($id)
    {
        try {
            // Recherchez les informations de visite correspondant à l'ID du patient
            $visitInformation = VisitInformation::where('patient_id', $id)->firstOrFail();
            return response()->json($visitInformation);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No visit information found for this patient'], 404);
        }
    }
}
