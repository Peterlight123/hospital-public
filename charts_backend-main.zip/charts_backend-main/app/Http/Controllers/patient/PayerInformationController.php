<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\PayerInformation;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class PayerInformationController extends Controller
{
    public function store(Request $request)
    {
      // Valider les données entrantes
      $validatedData = $request->validate([
        'patient_id' => 'required|exists:patients,id', // Assurez-vous que l'ID du patient existe
        'social_security' => 'nullable',
        'medicare_beneficiary' => 'nullable',
        'medicaid_number' => 'nullable',
        'medicaid_recipient' => 'nullable',
        'payer_info' => 'nullable',
    ]);

    // Vérifier si l'ID du patient existe dans la table address
    $payerInformation = PayerInformation::where('patient_id', $validatedData['patient_id'])->first();

    if ($payerInformation) {
        // Mettre à jour les informations de visite existantes
        $payerInformation->update([
            'social_security' => $validatedData['social_security'],
            'medicare_beneficiary' => $validatedData['medicare_beneficiary'],
            'medicaid_number' => $validatedData['medicaid_number'],
            'medicaid_recipient' => $validatedData['medicaid_recipient'],
            'payer_info' => $validatedData['payer_info'],
        ]);
    } else {
        // Créer de nouvelles informations de visite
        $payerInformation =  PayerInformation::create([
            'patient_id' => $validatedData['patient_id'],
            'social_security' => $validatedData['social_security'],
            'medicare_beneficiary' => $validatedData['medicare_beneficiary'],
            'medicaid_recipient' => $validatedData['medicaid_recipient'],
            'medicaid_number' => $validatedData['medicaid_number'],
            'payer_info' => $validatedData['payer_info'],
        ]);
    }
       return response()->json(['message' => 'Données sauvegardées avec succès','data' => $payerInformation,], 200);
    }

    public function show($id)
    {
        try {
            // Recherchez les payer information  correspondant à l'ID du patient
            $payerInformation = PayerInformation::where('patient_id', $id)->firstOrFail();
            return response()->json($payerInformation);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No payer information found for this patient'], 404);
        }
    }
}
