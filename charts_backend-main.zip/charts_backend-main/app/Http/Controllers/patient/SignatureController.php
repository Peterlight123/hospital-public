<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\Signature;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class SignatureController extends Controller
{
    public function store(Request $request)
    {
        // Valider les données entrantes
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'signature_name' => 'required',
        ]);
    
        // Rechercher la signature existante pour le patient
        $signature = Signature::where('patient_id', $validatedData['patient_id'])->first();
    
        if ($signature) {
            // Mettre à jour la signature existante
            $signature->update([
                'signature_name' => $validatedData['signature_name'],
            ]);
        } else {
            // Créer une nouvelle signature
            $signature = Signature::create([
                'patient_id' => $validatedData['patient_id'],
                'signature_name' => $validatedData['signature_name'],
            ]);
        }
    
        // Réponse JSON en cas de succès
        return response()->json([
            'message' => 'Signature créée ou mise à jour avec succès.',
            'data' => $signature,
        ], 201);
    }
    
    public function show($id)
    {
        try {
            $signature = Signature::where('patient_id', $id)->firstOrFail();
            return response()->json($signature);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No visit nutrition assessment found for this patient'], 404);
        }
    }

    public function delete($id)
    {
        try {
            $signature  = Signature::findOrFail($id);
            if (is_null($signature)) {
                return response()->json(['message' => 'La signature n\'existe pas', 'status' => 404]);
            }
    
            $signature->delete();
    
            return response()->json(['message' => 'Signature supprimée avec succès.', 'status' => 200]);
        } catch (ModelNotFoundException $e) {
            return response()->json(['message' => 'Erreur lors de la suppression de la signature.', 'status' => 500, 'error' => $e->getMessage()]);
        }
    }
    
}
