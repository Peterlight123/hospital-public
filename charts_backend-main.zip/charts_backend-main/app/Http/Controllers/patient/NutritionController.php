<?php

namespace App\Http\Controllers\patient;

use Illuminate\Http\Request;
use App\Models\NutritionAssessment;
use App\Http\Controllers\Controller;
use App\Models\NutritionProblemsType;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class NutritionController extends Controller
{
    public function nutritionProblemsTypes()
    {
        
        $nutritionProblemsTypes = NutritionProblemsType::all();
        return response()->json($nutritionProblemsTypes);
    }

    // public function nutritionAssessmentStore(Request $request)
    // {
        
    //     $nutritionProblemsTypes = NutritionProblemsType::all();
    //     return response()->json($nutritionProblemsTypes);
    // }

    public function nutritionAssessmentShow($id)
    {

        //echo("dfdfdfd");
        try {
            $nutrition_assessment = NutritionAssessment::where('patient_id', $id)->firstOrFail();
            return response()->json([
                'nutrition_assessment' => $nutrition_assessment,
            ]);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No visit nutrition assessment found for this patient'], 404);
        }
    }
    

    public function nutritionAssessmentAutoSave(Request $request, $id)
    {
        // Valider les données entrantes
        $validatedData = $request->validate([
            'patient_id' => 'required|exists:patients,id', // Assurez-vous que l'ID du patient existe
            'nutrition_problems_type_ids' => 'required', // Ajoutez la validation pour nutrition_problems_type_ids
            'nutrition_template_ids' => 'required', // Ajoutez la validation pour nutrition_problems_type_ids
            // Ajoutez d'autres règles de validation au besoin
        ]);
    
        // Vérifier si des informations de nutrition existent pour le patient
        $nutritionAssessment = NutritionAssessment::where('patient_id', $id)->first();
    
        if ($nutritionAssessment) {
            // Mettre à jour les informations de nutrition existantes
             // Vérifier et ajouter les champs non vides
             $nutrition_problems_type_ids = $validatedData['nutrition_problems_type_ids'];
             if (!empty($nutrition_problems_type_ids )) {
                $updateData['nutrition_problems_type_ids'] = implode(',', $validatedData['nutrition_problems_type_ids']);
            }
            $nutrition_template_ids = $validatedData['nutrition_template_ids'];
            if (!empty($nutrition_template_ids)) {
                $updateData['nutrition_template_ids'] = implode(',', $validatedData['nutrition_template_ids']);
            }
            $nutritionAssessment->update($updateData);
            

        } else {
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];
            $nutrition_problems_type_ids = $validatedData['nutrition_problems_type_ids'];
            if (!empty($nutrition_problems_type_ids )) {
               $createData['nutrition_problems_type_ids'] = implode(',', $validatedData['nutrition_problems_type_ids']);
           }
           $nutrition_template_ids = $validatedData['nutrition_template_ids'];
           if (!empty($nutrition_template_ids)) {
               $createData['nutrition_template_ids'] = implode(',', $validatedData['nutrition_template_ids']);
           }
           $nutritionAssessment = NutritionAssessment::create($createData);
        }
    
        return response()->json(['message' => 'Données sauvegardées avec succès', 'data' => $nutritionAssessment], 200);
    }
    

    
}
