<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\Address;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class addressController extends Controller
{
    public function store(Request $request)
    {
      // Valider les données entrantes
      $validatedData = $request->validate([
        'patient_id' => 'required|exists:patients,id', // Assurez-vous que l'ID du patient existe
        'address_line_1' => 'nullable',
        'address_line_2' => 'nullable',
        'state' => 'nullable',
        'marital_status' => 'nullable',
        'city' => 'nullable',
        'zip_code' => 'nullable',
        'phone_number' => 'nullable',
        'alternate_phone' => 'nullable',
    ]);

    // Vérifier si l'ID du patient existe dans la table address
    $address = Address::where('patient_id', $validatedData['patient_id'])->first();

    if ($address) {
        // Mettre à jour les informations de visite existantes
        $address->update([
            'address_line_1' => $validatedData['address_line_1'],
            'address_line_2' => $validatedData['address_line_2'],
            'state' => $validatedData['state'],
            'marital_status' => $validatedData['marital_status'],
            'city' => $validatedData['city'],
            'zip_code' => $validatedData['zip_code'],
            'phone_number' => $validatedData['phone_number'],
            'alternate_phone' => $validatedData['alternate_phone'],
        ]);
    } else {
        // Créer de nouvelles informations de visite
        $address =  Address::create([
            'patient_id' => $validatedData['patient_id'],
            'address_line_1' => $validatedData['address_line_1'],
            'address_line_2' => $validatedData['address_line_2'],
            'state' => $validatedData['state'],
            'marital_status' => $validatedData['marital_status'],
            'city' => $validatedData['city'],
            'zip_code' => $validatedData['zip_code'],
            'phone_number' => $validatedData['phone_number'],
            'alternate_phone' => $validatedData['alternate_phone'],
        ]);
    }

       return response()->json(['message' => 'Données sauvegardées avec succès','data' => $address,], 200);
    }

    public function show($id)
    {
        try {
            // Recherchez les informations de visite correspondant à l'ID du patient
            $address = Address::where('patient_id', $id)->firstOrFail();
            return response()->json($address);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No visit information found for this patient'], 404);
        }
    }
}
