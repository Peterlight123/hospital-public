<?php

namespace App\Http\Controllers\patient;

use App\Models\Patient;
use Illuminate\Http\Request;
use App\Models\BenefitPeriod;
use App\Http\Controllers\Controller;

class BenefitPeriodController extends Controller
{
    public function createNextPeriod($patientId)
    {
        $patient = Patient::findOrFail($patientId);

        $newBenefitPeriod = BenefitPeriod::createNextBenefitPeriod($patient->id);

        return response()->json([
            'message' => 'New benefit period created successfully',
            'benefit_period' => $newBenefitPeriod
        ]);
    }

    public function addNursingClinicalNote(Request $request, $benefitPeriodId)
    {
        $benefitPeriod = BenefitPeriod::findOrFail($benefitPeriodId);

        $nursingClinicalNote = $benefitPeriod->nursingClinicalNotes()->create([
            'note_date' => $request->input('note_date'),
            'note' => $request->input('note')
        ]);

        return response()->json([
            'message' => 'Nursing clinical note added successfully',
            'nursing_clinical_note' => $nursingClinicalNote
        ]);
    }

    public function getPatientChart($id)
    {
        $patient = Patient::with('benefitPeriods.nursingClinicalNotes')->findOrFail($id);
        return response()->json($patient);
    }
}
