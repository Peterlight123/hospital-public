<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\Hematological;
use App\Models\HematologicalAssessment;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class HematologicalAssessmentController extends Controller
{
    public function index()
    {
        $hematological = HematologicalAssessment::all();
        return response()->json($hematological);
    }
    public function hematologicalList()
    {
        $hematological = Hematological::all();
        return response()->json($hematological);
    }
    public function store(Request $request)
    {
        // Valider les données entrantes
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'hematological_ids' => 'required',
        ]);

        $hematological = HematologicalAssessment::where('patient_id', $validatedData['patient_id'])->first();

        if ($hematological) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['hematological_ids'])) {
                $updateData['hematological_ids'] = implode(',', $validatedData['hematological_ids']);
            }
            $hematological->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['hematological_ids'])) {
                $createData['hematological_ids'] = implode(',', $validatedData['hematological_ids']);
            }
            $hematological = HematologicalAssessment::create($createData);
        }
        // Réponse JSON en cas de succès
        return response()->json([
            'message' => 'hematological créé ou mis à jour avec succès.',
            'data' => $hematological,
        ], 201);
    }

    public function show($id)
    {
        try {
            // Recherchez les hematological correspondant à l'ID du patient
            $hematological = HematologicalAssessment::where('patient_id', $id)->firstOrFail();
            return response()->json($hematological);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No hematological found for this hematological'], 404);
        }
    }
}
