<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\Endocrine;
use App\Models\EndocrineAssessment;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class EndocrineAssessmentController extends Controller
{
    public function index()
    {
        $endocrine = EndocrineAssessment::all();
        return response()->json($endocrine);
    }
    public function endocrineList()
    {
        $endocrine = Endocrine::all();
        return response()->json($endocrine);
    }
    public function store(Request $request)
    {
        // Valider les données entrantes
        $validatedData = $request->validate([
            'patient_id' => 'required',
            'endocrine_ids' => 'required',
        ]);

        $endocrine = EndocrineAssessment::where('patient_id', $validatedData['patient_id'])->first();

        if ($endocrine) {
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['endocrine_ids'])) {
                $updateData['endocrine_ids'] = implode(',', $validatedData['endocrine_ids']);
            }
            $endocrine->update($updateData);
        } else {
            // Créer de nouvelles données
            $createData = [
                'patient_id' => $validatedData['patient_id'],
            ];
            // Vérifier et ajouter les champs non vides
            if (!empty($validatedData['endocrine_ids'])) {
                $createData['endocrine_ids'] = implode(',', $validatedData['endocrine_ids']);
            }
            $endocrine = EndocrineAssessment::create($createData);
        }
        // Réponse JSON en cas de succès
        return response()->json([
            'message' => 'endocrine créé ou mis à jour avec succès.',
            'data' => $endocrine,
        ], 201);
    }

    public function show($id)
    {
        try {
            // Recherchez les endocrine correspondant à l'ID du patient
            $endocrine = EndocrineAssessment::where('patient_id', $id)->firstOrFail();
            return response()->json($endocrine);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No endocrine found for this endocrine'], 404);
        }
    }
}
