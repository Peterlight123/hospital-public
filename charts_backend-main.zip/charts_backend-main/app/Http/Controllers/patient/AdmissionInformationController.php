<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\Admission_information;
use App\Models\AdmissionInformation;
use Illuminate\Http\Request;


class AdmissionInformationController extends Controller
{
    public function autoSave(Request $request)
    {
      // Valider les données entrantes
      $validatedData = $request->validate([
        'patient_id' => 'required|exists:patients,id', // Assurez-vous que l'ID du patient existe
        'admission_date' => 'nullable',
        'date_initial' => 'nullable',
        'site_of_service_id' => 'nullable',
        'admitted_form_id' => 'nullable',
    ]);

    // Vérifier si l'ID du patient existe dans la tableAdmission_information
    $admission_information =AdmissionInformation::where('patient_id', $validatedData['patient_id'])->first();

    if ($admission_information) {
        // Mettre à jour les informations de visite existantes
        $admission_information->update([
            'admission_date' => $validatedData['admission_date'],
            'date_initial' => $validatedData['date_initial'],
            'site_of_service_id' => $validatedData['site_of_service_id'],
            'admitted_form_id' => $validatedData['admitted_form_id'],
            
        ]);
    } else {
        // Créer de nouvelles informations de visite
        $admission_information = AdmissionInformation::create([
            'patient_id' => $validatedData['patient_id'],
            'admission_date' => $validatedData['admission_date'],
            'date_initial' => $validatedData['date_initial'],
            'site_of_service_id' => $validatedData['site_of_service_id'],
            'admitted_form_id' => $validatedData['admitted_form_id']
        ]);
    }

       return response()->json(['message' => 'Données sauvegardées avec succès','data' => $admission_information,], 200);
    }

    public function show($id)
    {
        try {
            // Recherchez les informations de visite correspondant à l'ID du patient
            $admission_information =AdmissionInformation::where('patient_id', $id)->firstOrFail();
            return response()->json($admission_information);
        } catch (AdmissionInformation $e) {
            return response()->json(['error' => 'No visit information found for this patient'], 404);
        }
    }

    
}
