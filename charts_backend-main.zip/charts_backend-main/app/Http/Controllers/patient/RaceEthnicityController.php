<?php

namespace App\Http\Controllers\patient;

use App\Http\Controllers\Controller;
use App\Models\RaceEthnicity;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class RaceEthnicityController extends Controller
{
    public function index()
    {
        $raceEthnicity = RaceEthnicity::all();
        return response()->json($raceEthnicity);
    }

    public function store(Request $request)
    {
         // Validation des données de la requête
         $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:race_ethnicity,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        $raceEthnicity = RaceEthnicity::create([
            'name' => $request->name,
        ]);

        // Réponse JSON en cas de succès
        return response()->json([
                    'message' => 'race ethnicity created successfully ',
                   'data' => $raceEthnicity,
                 ], 200);
    }
    public function show($id)
    {
        try {
            $raceEthnicity = RaceEthnicity::findOrFail($id);
            return response()->json($raceEthnicity);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No  race ethnicity found'], 404);
        }
    }
    public function update(Request $request, $id)
    {
          // Validation des données de la requête
          $validatedData = Validator::make($request->all(), [
            'name' => 'required|unique:race_ethnicity,name',
        ]);


        if ($validatedData->fails()) {
            return response()->json(['errors' => $validatedData->errors()], 422);
        }
        try {
            $raceEthnicity =   RaceEthnicity::findOrFail($id);
            $raceEthnicity->update([
                'name' => $request->name,
            ]);
            // Réponse JSON en cas de succès
            return response()->json([
                        'message' => 'race ethnicity update successfully ',
                       'data' => $raceEthnicity,
                     ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'No  race ethnicity found.'], 404);
        }
    }

    public function destroy($id)
    {
        try {
    $raceEthnicity = RaceEthnicity::findOrFail($id);
    $raceEthnicity->delete();
    return response()->json( ['message' => ' race ethnicity delete successfully ']);
    //code...
} catch (ModelNotFoundException $e) {
    return response()->json(['error' => 'No  race ethnicity found.'], 404);
}
    }
}

