<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Validator;

class RoleController extends Controller
{
    public function index()
    {
        //$roles = Role::all();
        $roles = Role::with('permissions')->get();
        return response()->json($roles);
    }

    // public function store(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'name' => 'required|unique:roles,name',
    //         'permissions' => 'required|array',
    //         'permissions.*.id' => 'exists:permissions,id',
    //     ]);

    //     $role = Role::create([
    //         'name' => $request->input('name'),
    //         'guard_name' => 'api',
    //     ]);

    //     $permissions = Permission::whereIn('id', $request->input('permissions'))->get();
    //     $role->syncPermissions($permissions);

    //     return response()->json([
    //         'message' => 'Role created successfully',
    //         'role' => $role,
    //     ], 201);
    // }
    public function store(Request $request)
    {
        // Validation des données de la requête
        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:roles,name',
            'permissions' => 'required|array',
            'permissions.*.id' => 'exists:permissions,id',
        ]);

        // Vérifier si la validation a échoué
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Créer un nouveau rôle avec le nom spécifié
        $role = Role::create([
            'name' => $request->name,
            'guard_name' => 'api',
        ]);

        // Associer les permissions au rôle
        $permissions = Permission::whereIn('id', $request->input('permissions'))->get();
            $role->syncPermissions($permissions);

        // Réponse JSON en cas de succès
        // return response()->json(['message' => 'Role created successfully with permissions']);
        return response()->json([
            'message' => 'Role created successfully with permissions',
                   'role' => $role,
                 ], 201);
    }

    public function show($id)
    {
        $rolesPermissions = Role::with('permissions')->findOrFail($id);
        return response()->json($rolesPermissions);
    }

    public function update(Request $request, $id)
    {
    $role = Role::findOrFail($id);
    $permissionIds = Permission::whereIn('id', $request->input('permissions'))->get();

    $request->validate([
        'name' => ['required', Rule::unique('roles')->ignore($role->id)],
        'permissions' => 'required|array',
        'permissions.*.id' => 'exists:permissions,id',
    ]);

    // Mettre à jour le nom du rôle
    $role->update(['name' => $request->name, 'guard_name' => 'api',]);

    // Synchroniser les permissions du rôle
    $role->syncPermissions($permissionIds);

        return response()->json(['message' => 'Role updated successfully with permissions']);
    }
    // public function update(Request $request, Role $role)
    // {
    //     // Validation des données de la requête
    //     $validator = Validator::make($request->all(), [
    //         'name' => [
    //             'required',
    //             Rule::unique('roles')->ignore($role->id),
    //         ],
    //         'permissions' => 'required|array',
    //         'permissions.*' => 'exists:permissions,id',
    //     ]);
    
    //     // Vérifier si la validation a échoué
    //     if ($validator->fails()) {
    //         return response()->json(['errors' => $validator->errors()], 422);
    //     }
    
    //     // Mettre à jour le rôle avec le nouveau nom
    //     $role->name = $request->name;
    //     $role->update();
    
    //     // Associer les permissions au rôle
    //     $permissions = Permission::whereIn('id', $request->input('permissions'))->get();
    //     $role->syncPermissions($permissions);
    
    //     // Réponse JSON en cas de succès avec le rôle mis à jour
    //     return response()->json([
    //         'message' => 'Role updated successfully with permissions',
    //         'role' => $role,
    //     ], 200);
    // }
    
    public function destroy($id)
    {
        $role = Role::findOrFail($id);
        $role->delete();
        return response()->json(['message' => 'Role deleted successfully']);
    }
}

