<?php

// namespace App\Http\Controllers;

// use Illuminate\Http\Request;
// use App\Http\Resources\Auth\UserResource;
// use Illuminate\Support\Facades\Cookie;
// use App\Http\Helpers\Helper;
// use App\Http\Requests\Auth\LoginRequest;
// use App\Models\User;
// use Illuminate\Support\Facades\Auth;
// use Illuminate\Support\Facades\Hash;

// class AuthController extends Controller
// {
//     //Register user

//     public function register(Request $request)
//     {
//         //validate fields 
//         $attrs = $request->validate([
//             'name'=>'required|string',
//             'email'=>'required|email|unique:users,email',
//             'password'=>'required|min:6|confirmed'
//         ]);
        
//         //create user
//         $user= User::create([
//             'name'=> $attrs['name'],
//             'email'=> $attrs['email'],
//             'password'=> Hash::make($attrs['password']),

//         ]);

//         //return user & token in response 
//         return response([
//             'user'=> $user,
//             'token'=> $user->createToken('secret')->plainTextToken,

//         ],200);
//     }

//     //login user 

//     public function login(LoginRequest $request)
//     {
//         if (!$token = auth()->attempt($request->validated())) {
//             Helper::sendError('Invalid email or password!');
//         }
//         $token = $this->token($request);
//         $user = User::find(auth()->user()->id);
//         $role = $this->roles($user);
//         $permissions = $user->permissions;

//         if (empty($role) || collect($permissions)->isEmpty())
//             return [
//                 'status' => 302,
//                 'redirectTo' => 'api/login',
//                 'message' => 'Please contact the administrator'
//             ];

//         // send response
//         $response = [
//             'status' => [
//                 'status' => 200,
//                 'message'  => "You are connected"
//             ],
//             'authorisation' => [
//                 'token' => $token,
//                 'type' => 'bearer',
//             ],
//             'expires_in' => auth()->factory()->getTTL(), // 120 minutes in jwt config
//             'user' => $user,
//             'roles' => $user->roles->pluck('name'),
//             'permissions' => $user->permissions->pluck('name'),
//         ];
    
//         // Devuelve la respuesta con el token como cookie
//         return response()->json($response)->cookie(
//             'token',
//             $token,
//             config('jwt.ttl')
//         );
//     }

//     public function logout()
//     {
//         auth()->user()->tokens()->delete();
//         return response ([
//             'message'=>'Logout success.'
//         ],200);
//     }

//     //get user details 
//     public function user()
//     {
        
//         return response ([
//             'user'=>auth()->user()
//         ],200);
//     }

//      // update user
//      public function update(Request $request)
//      {
//          $attrs = $request->validate([
//              'name' => 'required|string'
//          ]);
 
//          $image = $this->saveImage($request->image, 'profiles');
 
//          auth()->user()->update([
//              'name' => $attrs['name'],
//              'image' => $image
//          ]);
 
//          return response([
//              'message' => 'User updated.',
//              'user' => auth()->user()
//          ], 200);
//      }
//       /**
//      * Get the token array structure.
//      * @param object array $request
//      * @return \Illuminate\Http\JsonResponse
//      */
//     private function token($request)
//     {
//         return auth()->attempt($request->only('email', 'password'));
//     }
//     private function roles($user)
//     {
//         $roles = array();
//         foreach ($user->roles as $role) {
//             $roleArr = [
//                 'id' => $role->id,
//                 'name' => $role->name,
//             ];
//             $roles[] = $roleArr;
//         }

//         return  $roles;
//     }
// }

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Resources\Auth\UserResource;
use Illuminate\Support\Facades\Cookie;
use App\Http\Helpers\Helper;
use App\Http\Requests\Auth\LoginRequest;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;

class AuthController extends Controller
{
    // Register user
    public function register(Request $request)
    {
        // Validate fields
        $attrs = $request->validate([
            'name' => 'required|string',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6|confirmed'
        ]);

        // Create user
        $user = User::create([
            'name' => $attrs['name'],
            'email' => $attrs['email'],
            'password' => Hash::make($attrs['password']),
        ]);

        // Return user & token in response
        return response([
            'user' => $user,
            'token' => $user->createToken('secret')->plainTextToken,
        ], 200);
    }

    // Login user
    public function login(LoginRequest $request)
    {
        if (!$token = auth()->attempt($request->validated())) {
            Helper::sendError('Invalid email or password!');
        }
        $token = $this->token($request);
        $user = User::find(auth()->user()->id);
        $roles = $this->roles($user);
        $permissions = $this->getPermissionsByRoles($user->roles);

        if (empty($roles) || $permissions->isEmpty())
            return [
                'status' => 302,
                'redirectTo' => 'api/login',
                'message' => 'Please contact the administrator for access to the system '
            ];

        // Send response
        $response = [
            'status' => [
                'status' => 200,
                'message'  => "You are connected"
            ],
            'authorisation' => [
                'token' => $token,
                'type' => 'bearer',
            ],
            'expires_in' => auth()->factory()->getTTL(), // 120 minutes in jwt config
            'user' => $user,
            'roles' => $user->roles->pluck('name'),
            'permissions' => $permissions->pluck('name'),
        ];

        // Return the response with the token as a cookie
        return response()->json($response)->cookie(
            'token',
            $token,
            config('jwt.ttl')
        );
    }

    public function logout()
    {
        auth()->logout();
        Cookie::forget('token');
        return response()->json(['message' => 'Logged out successfully','status' => 200])->withCookie(Cookie::forget('token'));
    }

    // Get user details
    public function user()
    {
        return response([
            'user' => auth()->user()
        ], 200);
    }

    // Update user
    public function update(Request $request)
    {
        $attrs = $request->validate([
            'name' => 'required|string'
        ]);

        $image = $this->saveImage($request->image, 'profiles');

        auth()->user()->update([
            'name' => $attrs['name'],
            'image' => $image
        ]);

        return response([
            'message' => 'User updated.',
            'user' => auth()->user()
        ], 200);
    }

    /**
     * Get the token array structure.
     * @param object array $request
     * @return \Illuminate\Http\JsonResponse
     */
    private function token($request)
    {
        return auth()->attempt($request->only('email', 'password'));
    }

    private function roles($user)
    {
        $roles = array();
        foreach ($user->roles as $role) {
            $roleArr = [
                'id' => $role->id,
                'name' => $role->name,
            ];
            $roles[] = $roleArr;
        }

        return  $roles;
    }

    private function getPermissionsByRoles($roles)
    {
        $permissions = Permission::whereIn('id', function ($query) use ($roles) {
            $query->select('permission_id')
                ->from('role_has_permissions')
                ->whereIn('role_id', $roles->pluck('id'));
        })->get();

        return $permissions;
    }

    
}
