<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class PermissionController extends Controller
{
    public function index()
    {
        // Récupérer toutes les permissions
        $permissions = Permission::all();

        return response()->json($permissions);
    }
    public function permissionList()
    {
         // Récupérer tous les noms de permissions
    $permissionNames = Permission::pluck('name');

    return response()->json($permissionNames);
    }

    // public function store(Request $request)
    // {
    //     // Valider les données de la requête
    //     $request->validate([
    //         'name' => 'required|string|unique:permissions,name',
    //     ]);

    //     // Créer une nouvelle permission
    //     $permission = Permission::create(['name' => $request->name]);

    //     return response()->json(['permission' => $permission], 201);
    // }

    public function store(Request $request)
    {
        // Valider les données de la requête
        $request->validate([
            'name' => 'required|string|unique:permissions,name',
        ]);

        // Créer une nouvelle permission avec le guard_name spécifié comme 'api'
        $permission = Permission::create([
            'name' => $request->name,
            'guard_name' => 'api', // Spécifier le guard_name comme 'api'
        ]);

        return response()->json(['permission' => $permission], 201);
    }

    // public function store(Request $request)
    // {
    //     // Valider les données de la requête
    //     $request->validate([
    //         'name' => 'required|unique:roles,name',
    //         'permissions' => 'required|array',
    //     ]);

    //     // Création du rôle avec le guard_name spécifié comme 'api'
    //     $role = Role::create([
    //         'name' => $request->name,
    //         'guard_name' => 'api', // Spécification du guard_name
    //     ]);

    //     // Récupérer les IDs des permissions à partir de la requête
    //     $permissionIds = $request->permissions;

    //     // Associer les permissions sélectionnées au rôle nouvellement créé
    //     foreach ($permissionIds as $permissionId) {
    //         DB::table('role_has_permissions')->insert([
    //             'role_id' => $role->id,
    //             'permission_id' => $permissionId,
    //         ]);
    //     }

    //     // Récupérer la requête SQL insérée dans le réseau du navigateur
    //     $sqlQuery = DB::table('role_has_permissions')->toSql();

    //     // Retourner la réponse avec la requête SQL
    //     return response()->json(['message' => 'Role created successfully with permissions', 'sql_query' => $sqlQuery], 201);
    // }


    public function show($id)
    {
        // Récupérer la permission par ID
        $permission = Permission::findOrFail($id);

        return response()->json($permission);
    }

    public function update(Request $request, $id)
    {
        // Valider les données de la requête
        $request->validate([
            'name' => 'required|string|unique:permissions,name,' . $id,
        ]);

        // Mettre à jour la permission
        $permission = Permission::findOrFail($id);
        $permission->name = $request->name;
        $permission->save();

        return response()->json($permission);
    }

    public function destroy($id)
    {
        // Supprimer la permission par ID
        $permission = Permission::findOrFail($id);
        $permission->delete();

        return response()->json(['message' => 'Permission deleted successfully'], 200);
    }
}
