<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Illuminate\Support\Facades\Cookie;

class JwtMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        // Skip JWT check if route doesn't have jwt.auth middleware
        if (!$request->route()) {
            return $next($request);
        }
        
        $middlewares = $request->route()->gatherMiddleware();
        if (!in_array('jwt.auth', $middlewares)) {
            return $next($request);
        }

        try {
            // Essayer d'extraire l'utilisateur depuis le token
            $user = JWTAuth::parseToken()->authenticate();
        } catch (TokenExpiredException $e) {
            return response()->json(['message' => 'Your session has expired. Please login again.','status' => 401], 401);
        } catch (TokenInvalidException $e) {
            return response()->json(['message' => 'Invalid token. Please provide a valid token.','status' => 401], 401);
        } catch (JWTException $e) {
            return response()->json(['message' => 'Your session has expired. Please login again.','status' => 401], 401);
        }

        return $next($request);
    }
}
