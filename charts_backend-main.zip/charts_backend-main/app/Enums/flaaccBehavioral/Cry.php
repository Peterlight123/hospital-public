<?php
namespace App\Enums\flaaccBehavioral;
enum Cry: string
{
    case NO_CRY = 'No cry (awake or asleep) (0)';
    case MOANS = 'Moans or whimpers, occasional complaint (1)';
    case CRYING = 'Crying steadily, screams or sobs, frequent complaints (2)';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }
}