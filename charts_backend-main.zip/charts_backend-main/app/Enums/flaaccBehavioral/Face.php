<?php
namespace App\Enums\flaaccBehavioral;
enum Face: string
{
    case NO_EXPRESSION = 'No particular expression or smile (0)';
    case OCCASIONAL_GRIMACE = 'Occasional grimace or frown, withdrawn, disinterested (1)';
    case FREQUENT_FROWN = 'Frequent to constant frown, clenched jaw, quivering chin (2)';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }   
}