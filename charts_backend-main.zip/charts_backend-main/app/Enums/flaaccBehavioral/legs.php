<?php
namespace App\Enums\flaaccBehavioral;
enum Legs: string
{
    case NORMAL = 'Normal position or relaxed (0)';
    case UNEASY = 'Uneasy, restless, tense (1)';
    case KICKING = 'Kicking or legs drawn up (2)';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }
}