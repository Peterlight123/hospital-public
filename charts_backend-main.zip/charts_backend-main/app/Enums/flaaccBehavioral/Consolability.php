<?php

namespace App\Enums\flaaccBehavioral;

enum FlaaccBehavioralConsolability: string
{
    case RELAXED = 'Content, relaxed (0)';
    case REASSURED = 'Reassured by occasional touching, hugging, or being talked to, distractable (1)';
    case DIFFICULT = 'Difficult to console or comfort (2)';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }
}
