<?php
namespace App\Enums\flaaccBehavioral;
enum Activity: string
{
    case NORMAL = 'Lying quietly, normal position, moves easily (0)';
    case SQUIRMING = 'Squirming, shifting back and forth, tense (1)';
    case ARCHED = 'Arched, rigid, or jerking (2)';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }   
}