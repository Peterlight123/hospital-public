<?php
namespace App\Enums\PainScreening;
enum PainServerity: string
{
    case NO_PAIN = '0. None';
    case MILD_PAIN = '1. Mild';
    case MODERATE_PAIN = '2. Moderate';
    case SEVERE_PAIN = '3. Severe';
    case NOT_RATED = '9. Pain not rated';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }
}   