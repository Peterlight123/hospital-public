<?php
namespace App\Enums\PainScreening;
enum StandardizedPainTool: string
{
    case NUMERIC = '1. Numeric';
    case VERBAL_DESCRIPTOR = '2. Verbal descriptor';
    case PATIENT_VISUAL = '3. Patient visual';
    case STAFF_OBSERVATION = '4. Staff observation';
    case NO_STANDARDIZED_TOOL = '9. No standardized tool used';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }
}