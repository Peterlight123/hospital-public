<?php

namespace App\Enums\Pain;

enum PainRatedBy: string
{
    case PATIENT = 'patient';
    case CAREGIVER = 'caregiver';
    case HOSPICE_NURSE = 'hospice nurse';
    case FACILITY_STAFF = 'facility staff';
    case OTHER = 'other';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 1,
                'value' => $case->value
            ];
        }, self::cases());
    }
}