<?php

namespace App\Enums\Pain;

enum PainDuration: string
{
    case INTERMITTENT = 'intermittent';
    case FREQUENT = 'frequent';
    case CONSTANT = 'constant';
    case OTHER = 'other';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 1,
                'value' => $case->value
            ];
        }, self::cases());
    }
}