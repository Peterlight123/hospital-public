<?php

namespace App\Enums\Pain;

enum PainWorsened: string
{
    case CHANGE_IN_POSITION = 'change in position';
    case MOVEMENT = 'movement';
    case WALKING = 'walking';
    case COLD = 'cold';
    case SITTING = 'sitting';
    case STANDING = 'standing';
    case HEAT = 'heat';
    case OTHER = 'other';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 1,
                'value' => $case->value
            ];
        }, self::cases());
    }
}