<?php

namespace App\Enums\Pain;

enum PainFrequency: string
{
 
    case NO_PATTERN = 'no pattern';
    case CONSTANT = 'constant';
    case INTERMITTENT = 'intermittent';
    case IN_THE_MORNING = 'in the morning';
    case BREAKTHROUGH = 'breakthrough';
    case OTHER = 'other';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 1,
                'value' => $case->value
            ];
        }, self::cases());
    }
}