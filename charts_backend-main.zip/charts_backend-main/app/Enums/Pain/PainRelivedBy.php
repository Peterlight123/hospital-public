<?php

namespace App\Enums\Pain;

enum PainRelivedBy: string
{
    case HEAT = 'heat';
    case ICE = 'ice';
    case MASSAGE = 'massage';
    case MEDICATION = 'medication';
    case REPOSITIONING = 'repositioning';
    case REST_RELAXATION = 'rest/relaxation';
    case OTHER = 'other';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 1,
                'value' => $case->value
            ];
        }, self::cases());
    }
}