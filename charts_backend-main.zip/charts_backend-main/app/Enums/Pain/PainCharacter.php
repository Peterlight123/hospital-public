<?php

namespace App\Enums\Pain;

enum PainCharacter: string
{
    case CRAMPING = 'cramping';
    case GNAWING = 'gnawing';
    case NUMB = 'numb';
    case SHARP = 'sharp';
    case TENDER = 'tender';
    case DEEP = 'deep';
    case MISERABLE = 'miserable';
    case PENETRATING = 'penetrating';
    case SHOOTING = 'shooting';
    case TIRING = 'tiring';
    case EXHAUSTING = 'exhausting';
    case PRESSURE = 'pressure';
    case SQUEEZING = 'squeezing';
    case UNBEARABLE = 'unbearable';
    case PATIENT_UNABLE_TO_DESCRIBE = 'patient unable to describe';
    case OTHER = 'other';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 1,
                'value' => $case->value
            ];
        }, self::cases());
    }
}