<?php

namespace App\Enums\Pain;

enum PainObservation: string
{
    case CRYING = 'crying';
    case FACIAL_GRIMACING = 'facial grimacing';
    case GRABBING_HOLDING_BODY_PART = 'grabbing holding body part';
    case GUARDED_MOVEMENTS = 'guarded movements';
    case SPLINTING = 'splinting';
    case THRASHING = 'thrashing';
    case WINCING_UPON_MOVEMENT = 'wincing upon movement';
    case OTHER = 'other';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 1,
                'value' => $case->value
            ];
        }, self::cases());
    }
}