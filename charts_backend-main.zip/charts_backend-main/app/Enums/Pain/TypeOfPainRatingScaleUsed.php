<?php

namespace App\Enums\Pain;

enum TypeOfPainRatingScaleUsed: string
{
    case NUMERIC_ESAS = 'numeric/esas';
    case VERBAL_DESCRIPTOR = 'verbal descriptor';
    case POISE_VISUAL_FACES = 'poise visual/faces';
    case STAFF_OBSERVATION_PAINAD = 'staff observation/painad';
    case NO_SCALE_USED = 'no scale used';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 1,
                'value' => $case->value
            ];
        }, self::cases());
    }
}