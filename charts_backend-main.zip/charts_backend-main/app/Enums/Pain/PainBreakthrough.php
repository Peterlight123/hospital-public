<?php

namespace App\Enums\Pain;

enum PainBreakthrough: string
{
    case NEVER = 'never';
    case LESS_THAN_DAILY = 'less than daily';
    case DAILY = 'daily';
    case SEVERAL_TIMES_A_DAY = 'several times a day';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 1,
                'value' => $case->value
            ];
        }, self::cases());
    }

}