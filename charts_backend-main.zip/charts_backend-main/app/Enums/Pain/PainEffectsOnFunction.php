<?php

namespace App\Enums\Pain;

enum PainEffectsOnFunction: string
{
    case ACTIVITIES = 'activities';
    case APPETITE = 'appetite';
    case ENERGY = 'energy';
    case SLEEP = 'sleep';
    case SOCIALIZATION = 'socialization';
    case OTHER = 'other';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 1,
                'value' => $case->value
            ];
        }, self::cases());
    }
}