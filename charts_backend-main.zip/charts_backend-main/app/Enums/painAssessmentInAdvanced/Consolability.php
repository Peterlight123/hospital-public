<?php
namespace App\Enums\painAssessmentInAdvanced;
enum Consolability: string
{
    case NO_NEED_TO_CONSOLE = 'No need to console (0)';
    case DISTRACTED_OR_REASSURED = 'Distracted or reassured by voice or touch (1)';
    case UNABLE_TO_CONSOLE = 'Unable to console, distract, reassure (2)';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }
}       
