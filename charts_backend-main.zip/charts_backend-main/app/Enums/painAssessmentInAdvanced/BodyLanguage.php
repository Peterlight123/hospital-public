<?php
namespace App\Enums\painAssessmentInAdvanced;
enum BodyLanguage: string
{
    case RELAXED = 'Relaxed (0)';
    case TENSE_DISTRESSED = 'Tense, distressed pacing, fidgeting (1)';
    case RIGID_FISTS_CLENCHED = 'Rigid, fists clenched, knees pulled up, pulling or pushing away, striking out (2)';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }
}   