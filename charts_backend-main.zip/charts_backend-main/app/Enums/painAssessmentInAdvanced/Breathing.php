<?php
namespace App\Enums\painAssessmentInAdvanced;
enum Breathing: string
{
    case NORMAL = 'Normal (0)';
    case OCCASIONAL_LABORED = 'Occasional labored breathing, short periods of hyperventilation (1)';
    case NOISY_LABORED = 'Noisy labored breathing, long periods of hyperventilation, Cheyne-Stokes respirations (2)';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }
}