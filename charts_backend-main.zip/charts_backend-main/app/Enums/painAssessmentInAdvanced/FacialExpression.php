<?php
namespace App\Enums\painAssessmentInAdvanced;
enum FacialExpression: string
{
    case SMILING_OR_INEXPRESSIVE = 'Smiling or inexpressive (0)';
    case SAD_FRIGHTENED_FROWN = 'Sad, frightened, frown (1)';
    case FACIAL_GRIMACING = 'Facial grimacing (2)';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }
}