<?php
namespace App\Enums\painAssessmentInAdvanced;
enum NegativeVocalization: string
{
    case NONE = 'None (0)';
    case OCCASIONAL_MOAN = 'Occasional moan or groan, low level speech with negative or disapproving quality (1)';
    case REPEATED_TROUBLED = 'Repeated troubled calling out, loud moaning or groaning, crying (2)';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }
}