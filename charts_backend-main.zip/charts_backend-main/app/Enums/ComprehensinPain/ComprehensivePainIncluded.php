<?php
namespace App\Enums\ComprehensinPain;
enum ComprehensivePainIncluded: string
{
    case LOCATION = '1. Location';
    case SEVERITY = '2. Severity';
    case CHARACTER = '3. Character';
    case DURATION = '4. Duration';
    case FREQUENCY = '5. Frequency';
    case RELIEVES_WORSENS = '6. What relieves/worsens pain';
    case EFFECT_ON_FUNCTION = '7. Effect on function or quality of life';
    case NONE = '9. None of the above';

    public static function toArray(): array
    {
        return array_map(function($case) {
            return [
                'id' => array_search($case, self::cases()) + 0,
                'value' => $case->value
            ];
        }, self::cases());
    }
}   