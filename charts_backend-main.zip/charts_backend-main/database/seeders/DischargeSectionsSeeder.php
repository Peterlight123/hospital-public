<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DischargeSectionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $sections = [
            [
                'code' => 'A',
                'name' => 'Initial Evaluation'
            ],
            [
                'code' => 'B',
                'name' => 'Physical Examination'
            ],
            [
                'code' => 'C',
                'name' => 'History of Present Illness (HPI)'
            ],
            [
                'code' => 'D',
                'name' => 'Past Medical History (PMH)'
            ],
            [
                'code' => 'E',
                'name' => 'Medications'
            ],
            [
                'code' => 'F',
                'name' => 'Allergies'
            ],
            [
                'code' => 'G',
                'name' => 'Interventions/Procedures'
            ],
            [
                'code' => 'H',
                'name' => 'Laboratory Results'
            ],
            [
                'code' => 'I',
                'name' => 'Imaging Results'
            ],
            [
                'code' => 'J',
                'name' => 'Nursing Assessment'
            ],
            [
                'code' => 'K',
                'name' => 'Discharge Planning'
            ],
            [
                'code' => 'L',
                'name' => 'Education Provided'
            ],
        ];

        DB::table('discharge_sections')->insert($sections);
    }
}
