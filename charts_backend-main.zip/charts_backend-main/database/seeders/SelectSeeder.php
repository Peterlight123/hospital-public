<?php

namespace Database\Seeders;

use App\Models\AdmittedForm;
use App\Models\Cardiac;
use App\Models\DmeProvider;
use App\Models\Dnr;
use App\Models\EmergencyPreparednessLevel;
use App\Models\Endocrine;
use App\Models\Hematological;
use App\Models\Integumentary;
use App\Models\LiaisonPrimary;
use App\Models\LiaisonSecondary;
use App\Models\NutritionProblemsType;
use App\Models\NutritionTemplate;
use App\Models\Patient;
use App\Models\PatientPharmacy;
use App\Models\PrimaryDiagnosis;
use App\Models\prognosisCaregiver;
use App\Models\PrognosisImminence;
use App\Models\PrognosisPatient;
use App\Models\RaceEthnicity;
use App\Models\SiteOfService;
use App\Models\User;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class SelectSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create  SiteOfService.
        SiteOfService::create(['name' => '01. Hospice in patient\'s home/residence']);
        SiteOfService::create(['name' => '02. Hospice in Assisted Living facility']);
        SiteOfService::create(['name' => '03. Hospice provided in Nursing Long Term Care (LTC) or Non-Skilled Nursing Facility (NF)']);
        SiteOfService::create(['name' => '04. Hospice provided in a Skilled Nursing Facility (SNF)']);
        SiteOfService::create(['name' => '05. Hospice provided in Inpatient Hospital']);
        SiteOfService::create(['name' => '06. Hospice provided in Inpatient Hospice Facility']);
        SiteOfService::create(['name' => '07. Hospice provided in Long Term Care Hospital (LTCH)']);
        SiteOfService::create(['name' => '08. Hospice in Inpatient Psychiatric Facility']);
        SiteOfService::create(['name' => '09. Hospice provided in a place not otherwise specified (NOS) ']);
        SiteOfService::create(['name' => '10. Hospice home care provided in a hospice facility']);
        // Create  SiteOfService.
        AdmittedForm::create(['name' => '01. Community residential setting (e.g, private home/apt., board/care,assisted living, group home adult foster care)']);
        AdmittedForm::create(['name' => '02. Long-term care facility']);
        AdmittedForm::create(['name' => '03. Skilled Nursing Facility (SNF)']);
        AdmittedForm::create(['name' => '04. Hospital emergency department']);
        AdmittedForm::create(['name' => '05. Short-stay acute hospital ']);
        AdmittedForm::create(['name' => '06. Long-team care hospital (LTCH)']);
        AdmittedForm::create(['name' => '07. Inpatient rehabilitation facility or unit (IRF)']);
        AdmittedForm::create(['name' => '08. Psychiatric hospital or unit']);
        AdmittedForm::create(['name' => '09. ID/DD Facility']);
        AdmittedForm::create(['name' => '10. Hospice']);
        AdmittedForm::create(['name' => '99. None of the above']);
        // Create  Prognosis Patient.
        PrognosisPatient::create(['name' => 'Aware of Diagnosis']);
        PrognosisPatient::create(['name' => 'Unaware of Diagnosis']);
        PrognosisPatient::create(['name' => 'Unaware of Prognosis']);
        // Create  prognosis Caregiver.
        PrognosisCaregiver::create(['name' => 'Aware of Diagnosis']);
        PrognosisCaregiver::create(['name' => 'Unaware of Diagnosis']);
        PrognosisCaregiver::create(['name' => 'Unaware of Prognosis']);
        // Create  prognosis Caregiver.
        PrognosisImminence::create(['name' => 'Absent Bowel Function']);
        PrognosisImminence::create(['name' => 'Coolness to Skin']);
        PrognosisImminence::create(['name' => 'Cyanosis']);
        PrognosisImminence::create(['name' => 'Decreased Fluid/food Intake']);
        PrognosisImminence::create(['name' => 'Decreased Urine Output']);
        PrognosisImminence::create(['name' => 'Increased Fatigue']);
        PrognosisImminence::create(['name' => 'Increased  Respiratory Distress']);
        PrognosisImminence::create(['name' => 'Increased  Sleepiness']);
        PrognosisImminence::create(['name' => 'Other']);
        // Create  Cardiac Assessment.
        Cardiac::create(['name' => 'No Problems identified']);
        Cardiac::create(['name' => 'Abnormal Heart Rhythm:']);
        Cardiac::create(['name' => 'Abnormal Heart Sounds:']);
        Cardiac::create(['name' => 'Abnormal Lower Extremity:']);
        Cardiac::create(['name' => 'Abnormal Pulses:']);
        Cardiac::create(['name' => 'Abnormal Capillary Refills > 3 Sec :']);
        Cardiac::create(['name' => 'Cardiac Devices:']);
        Cardiac::create(['name' => 'Nebulizer']);
        Cardiac::create(['name' => 'Cherst Pain:']);
        Cardiac::create(['name' => 'Dizziness/Lightheadedness:']);
        Cardiac::create(['name' => 'Adema, Non-Pitting:']);
        Cardiac::create(['name' => 'Edema, Pitting:']);
        Cardiac::create(['name' => 'Edema, Weeping:']);
        Cardiac::create(['name' => 'Ascites:']);
        Cardiac::create(['name' => 'Ascites:']);
        Cardiac::create(['name' => 'Implanted Paracentiesis Drain:']);
        Cardiac::create(['name' => 'Other:']);
        // Create  Endocrine Assessment.
        Endocrine::create(['name' => 'No Problems identified']);
        Endocrine::create(['name' => 'Hypothyroidism:']);
        Endocrine::create(['name' => 'Hyperthyroidism:']);
        Endocrine::create(['name' => 'Diabetes:']);
        Endocrine::create(['name' => 'Other:']);
        // Create  Hematological Assessment.
        Hematological::create(['name' => 'No Problems identified']);
        Hematological::create(['name' => 'AIDS:']);
        Hematological::create(['name' => 'Anemia:']);
        Hematological::create(['name' => 'HIV:']);
        Hematological::create(['name' => 'Other:']);
        // Create  Integumentary Assessment.
        Integumentary::create(['name' => 'No Problems identified']);
        Integumentary::create(['name' => 'Abnormal Color:']);
        Integumentary::create(['name' => 'Bruising:']);
        Integumentary::create(['name' => 'Cool:']);
        Integumentary::create(['name' => 'Dry:']);
        Integumentary::create(['name' => 'Clammy:']);
        Integumentary::create(['name' => 'Poor Turgor:']);
        Integumentary::create(['name' => 'Pruritus:']);
        Integumentary::create(['name' => 'Rash:']);
        Integumentary::create(['name' => 'Wound(s):']);
        // Create  Nutrition Problems Type Assessment.
        NutritionProblemsType::create(['name' => 'No Problems identified']);
        NutritionProblemsType::create(['name' => 'Abnormal Appetite:']);
        NutritionProblemsType::create(['name' => 'Abnormal Hydration:']);
        NutritionProblemsType::create(['name' => 'Abnormal Oral Cavity:']);
        NutritionProblemsType::create(['name' => 'Difficulty Chewing']);
        NutritionProblemsType::create(['name' => 'Dyssphagia:']);
        NutritionProblemsType::create(['name' => 'Ill-Fitting Dentures:']);
        NutritionProblemsType::create(['name' => 'Sore Throat:']);
        NutritionProblemsType::create(['name' => 'Tube Freeding Present:']);
        NutritionProblemsType::create(['name' => 'Other:']);
        // Create  Nutrition Problems Type Assessment.
        NutritionTemplate::create(['name' => '15 - Without reason, has lost more than 10 Ibs, in the last 3 months']);
        NutritionTemplate::create(['name' => '10 - Has an illness or condition that made pt change the type and / or amount of food eaten']);
        NutritionTemplate::create(['name' => '10 - Eats fewer than 2 meals a day']);
        NutritionTemplate::create(['name' => '10 - Has open decubitus, ulcer, burn or wound']);
        NutritionTemplate::create(['name' => '10 - Has a tooth/mouth problem that makes it hard to eat']);
        NutritionTemplate::create(['name' => '10 - Has 3 or more drinks of beer, liquor or wine almost every day']);
        NutritionTemplate::create(['name' => '10 - Does not always have enough money to buy foods needed']);
        NutritionTemplate::create(['name' => '5 - Eats few fruits or vegetable, or milk products']);
        NutritionTemplate::create(['name' => '5 - Eats alone most of the time']);
        NutritionTemplate::create(['name' => '5 - Take 3 or more prescribed or OTC medications a day']);
        NutritionTemplate::create(['name' => '10 - Is not always physically able to cook and /or feed self and has no caregiver to assist']);
        NutritionTemplate::create(['name' => '10- Frequently has diarrhea or constipation']);
  
        DmeProvider::create(['name' => 'test Provider']);
        Dnr::create(['name' => 'test Dnr']);
        LiaisonPrimary::create(['name' => 'test primary']);
        LiaisonSecondary::create(['name' => 'test secondary']);
        RaceEthnicity::create(['name' => 'test race']);
        PatientPharmacy::create(['name' => 'test pharmacy']);
        PrimaryDiagnosis::create(['name' => 'test diagnosis']);
        EmergencyPreparednessLevel::create(['name' => 'test Emergency']);
      
        Patient::create([
            "first_name"=>  "Ahlin",
            "mi"=> "eeee",
            "last_name"=>  "Byll",
            "preferred_name"=> "pppp",
            "date_of_birth"=>  "2024-04-03",
            "suffix"=>  "dddd",
            "oxygen_dependent"=>  1,
            "ssn"=>  666,
            "patient_consents"=>  0,
            "genders"=>  "male",
            "dme_provider_id"=>  1,
            "primary_diagnosis_id"=>  1,
            "patient_pharmacy_id"=>  1,
            "dnr_id"=>  1,
            "race_ethnicity_id"=>  1,
            "emergency_preparedness_level_id"=>  1,
            "liaison_primary_id"=>  1,
            "liaison_secondary_id"=>  1,
            "hipaa_received"=>  0
        ]);

    }
}
