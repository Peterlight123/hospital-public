<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFlaccDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('flacc_data', function (Blueprint $table) {
            $table->id();
            $table->foreignId('note_id')->constrained('nursing_clinical_notes')->onDelete('cascade');
            $table->string('flacc_face')->nullable();
            $table->string('flacc_legs')->nullable();
            $table->string('flacc_activity')->nullable();
            $table->string('flacc_cry')->nullable();
            $table->string('flacc_consolability')->nullable();
            $table->integer('total_score')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('flacc_data');
    }
}
