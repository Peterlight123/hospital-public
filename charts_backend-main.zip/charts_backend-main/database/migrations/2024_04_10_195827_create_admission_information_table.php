<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdmissionInformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('admission_information', function (Blueprint $table) {
            $table->id(); 
            $table->date('admission_date')->nullable();
            $table->date('date_initial')->nullable();
            $table->unsignedBigInteger('admitted_form_id');
            $table->foreign('admitted_form_id')->references('id')->on('admitted_form')->onDelete('no action');
            $table->unsignedBigInteger('site_of_service_id');
            $table->foreign('site_of_service_id')->references('id')->on('site_of_service')->onDelete('no action');
            $table->unsignedBigInteger('patient_id');
            $table->foreign('patient_id')->references('id')->on('patients')->onDelete('no action');
           $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admission_information');
    }
}
