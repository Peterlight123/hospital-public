<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePainadDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('painad_data', function (Blueprint $table) {
            $table->id();
            $table->foreignId('note_id')->constrained('nursing_clinical_notes')->onDelete('cascade');
            $table->string('pain_assessment_behavior')->nullable();
            $table->string('pain_assessment_negative_vocalizations')->nullable();
            $table->string('pain_assessment_facial_expression')->nullable();
            $table->string('pain_assessment_body_language')->nullable();
            $table->string('pain_consolability')->nullable();
            $table->integer('painad_total_score')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('painad_data');
    }
}
