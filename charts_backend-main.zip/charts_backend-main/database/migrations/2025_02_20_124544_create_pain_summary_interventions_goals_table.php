<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePainSummaryInterventionsGoalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pain_summary_interventions_goals', function (Blueprint $table) {
            $table->id();
            $table->string('summary_of_problem')->nullable();
            $table->text('pain_interventions_administer_medication')->nullable();
            $table->date('pain_interventions_administer_medication_start_date')->nullable();
            $table->date('pain_interventions_assess_effectiveness')->nullable();
            $table->text('pain_interventions_assess_effectiveness_start_date')->nullable();
            $table->text('pain_interventions_assess_pain_status')->nullable();
            $table->text('pain_interventions_assess_pain_status_start_date')->nullable();
            $table->text('pain_interventions_non_pharmacological')->nullable();
            $table->text('pain_interventions_non_pharmacological_start_date')->nullable();
            $table->text('pain_goals_caregiver')->nullable();
            $table->text('pain_goals_rating')->nullable();
            $table->date('pain_goals_start_date')->nullable();
            $table->date('pain_goals_end_date')->nullable();
            $table->text('pain_caregiver_discussion_methods')->nullable();
            $table->text('pain_achive_by_date')->nullable();
            $table->text('pain_achive_by_date_start_date')->nullable();
            $table->foreignId('patient_id')->constrained()->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pain_summary_interventions_goals');
    }
}
