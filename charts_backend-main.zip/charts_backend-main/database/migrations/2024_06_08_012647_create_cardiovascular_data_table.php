<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCardiovascularDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cardiovascular_data', function (Blueprint $table) {
            $table->id();
            $table->foreignId('note_id')->constrained('nursing_clinical_notes')->onDelete('cascade');
            $table->boolean('chest_pain')->default(false);
            $table->boolean('dizziness')->default(false);
            $table->json('edema')->nullable();
            $table->boolean('pedal')->default(false);
            $table->boolean('right')->default(false);
            $table->boolean('left')->default(false);
            $table->boolean('sacral')->default(false);
            $table->boolean('dependent')->default(false);
            $table->boolean('irregular_heart_sounds')->default(false);
            $table->boolean('neck_vein_distention')->default(false);
            $table->json('devices')->nullable();
            $table->boolean('additional_details')->default(false);
            $table->json('present')->nullable();
            $table->json('bounding')->nullable();
            $table->json('weak_thready')->nullable();
            $table->json('absent')->nullable();
            $table->boolean('cardiovascular_note')->default(false);
            $table->string('right_foot')->nullable();
            $table->string('left_foot')->nullable();
            $table->string('right_ankle')->nullable();
            $table->string('left_ankle')->nullable();
            $table->string('right_calf')->nullable();
            $table->string('left_calf')->nullable();
            $table->string('right_upper_leg')->nullable();
            $table->string('left_upper_leg')->nullable();
            $table->string('right_hand')->nullable();
            $table->string('left_hand')->nullable();
            $table->string('right_arm')->nullable();
            $table->string('left_arm')->nullable();
            $table->string('right_scrotum')->nullable();
            $table->string('left_scrotum')->nullable();
            $table->string('right_face')->nullable();
            $table->string('left_face')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cardiovascular_data');
    }
}
