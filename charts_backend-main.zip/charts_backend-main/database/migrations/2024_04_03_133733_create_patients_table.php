<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePatientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patients', function (Blueprint $table) {
            $table->id();
            $table->string('first_name');
            $table->string('mi');
            $table->string('last_name');
            $table->string('preferred_name');
            $table->date('date_of_birth');
            $table->string('suffix');
            $table->boolean('oxygen_dependent');
            $table->bigInteger('ssn');
            $table->boolean('patient_consents');
            $table->string('genders');
            $table->unsignedBigInteger('dme_provider_id');
            $table->foreign('dme_provider_id')->references('id')->on('dme_providers')->onDelete('no action');
            $table->unsignedBigInteger('primary_diagnosis_id');
            $table->foreign('primary_diagnosis_id')->references('id')->on('primary_diagnoses')->onDelete('no action');
            $table->unsignedBigInteger('patient_pharmacy_id');
            $table->foreign('patient_pharmacy_id')->references('id')->on('patient_pharmacies')->onDelete('no action');
            $table->unsignedBigInteger('dnr_id');
            $table->foreign('dnr_id')->references('id')->on('dnr')->onDelete('no action');
            $table->unsignedBigInteger('race_ethnicity_id');
            $table->foreign('race_ethnicity_id')->references('id')->on('race_ethnicity')->onDelete('no action');
            $table->unsignedBigInteger('emergency_preparedness_level_id');
            $table->foreign('emergency_preparedness_level_id')->references('id')->on('emergency_preparedness_level')->onDelete('no action');
            $table->unsignedBigInteger('liaison_primary_id');
            $table->foreign('liaison_primary_id')->references('id')->on('liaison_primary')->onDelete('no action');
            $table->unsignedBigInteger('liaison_secondary_id');
            $table->foreign('liaison_secondary_id')->references('id')->on('liaison_secondary')->onDelete('no action');
            $table->boolean('hipaa_received');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patients');
    }
}
