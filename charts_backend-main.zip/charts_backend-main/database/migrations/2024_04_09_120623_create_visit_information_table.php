<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVisitInformationTable extends Migration
{
    /**
     * Run the migrations.
     * 
     * @return void
     */
    public function up()
    {
        Schema::create('visit_information', function (Blueprint $table) {
            $table->id(); 
             $table->date('visit_date')->nullable();
             $table->time('visit_time_in')->nullable();
             $table->time('visit_time_out')->nullable();
             $table->time('travel_time_in')->nullable();
             $table->time('travel_time_out')->nullable();
             $table->string('documenttation_time')->nullable();
             $table->string('associated_mileage')->nullable();
             $table->string('surcharge')->nullable();
             $table->unsignedBigInteger('patient_id');
             $table->foreign('patient_id')->references('id')->on('patients')->onDelete('no action');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('visit_information');
    }
}
