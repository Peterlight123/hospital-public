<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePainAssessmentInDementiaScaleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pain_assessment_in_dementia_scale', function (Blueprint $table) {
            $table->id();
            $table->unsignedTinyInteger('breathing')->nullable();
            $table->unsignedTinyInteger('vocalization')->nullable();
            $table->unsignedTinyInteger('facial_expression')->nullable();
            $table->unsignedTinyInteger('body_language')->nullable();
            $table->unsignedTinyInteger('consolability')->nullable();
            $table->unsignedTinyInteger('total_score')->nullable();
            $table->foreignId('patient_id')->constrained()->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pain_assessment_in_dementia_scale');
    }
}
