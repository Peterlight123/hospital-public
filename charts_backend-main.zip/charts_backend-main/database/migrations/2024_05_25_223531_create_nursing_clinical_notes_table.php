<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNursingClinicalNotesTable extends Migration
{
    public function up()
    {
        Schema::create('nursing_clinical_notes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('benefit_period_id')->constrained()->onDelete('cascade');
            $table->date('note_date');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('nursing_clinical_notes');
    }
}
