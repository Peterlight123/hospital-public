<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateNursingClinicalNotesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('nursing_clinical_notes', function (Blueprint $table) {
            $table->string('patient_name')->nullable();
            $table->string('patient_number')->nullable();
            $table->string('location_name')->nullable();
            $table->date('dob')->nullable();
            $table->string('location_number')->nullable();
        });
    }

    public function down()
    {
        Schema::table('nursing_clinical_notes', function (Blueprint $table) {
            $table->dropColumn('time_in');
            $table->dropColumn('time_out');
            $table->dropColumn('patient_name');
            $table->dropColumn('patient_number');
            $table->dropColumn('location_name');
            $table->dropColumn('benefit_period');
            $table->dropColumn('dob');
            $table->dropColumn('location_number');
            $table->dropColumn('patient_identifiers');
        });
    }
}
