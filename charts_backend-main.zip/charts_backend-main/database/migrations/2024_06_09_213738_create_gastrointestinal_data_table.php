<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGastrointestinalDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('gastrointestinal_data', function (Blueprint $table) {
            $table->id();
            $table->foreignId('note_id')->constrained('nursing_clinical_notes')->onDelete('cascade');
            $table->boolean('last_bm')->default(false);
            $table->boolean('unknown')->default(false);
            $table->boolean('bowel_sounds')->default(false);
            $table->json('present')->nullable();
            $table->json('hyper_active')->nullable();
            $table->json('hypo_active')->nullable();
            $table->json('absent')->nullable();
            $table->boolean('rectal_bleeding')->default(false);
            $table->boolean('hemorrhoids')->default(false);
            $table->boolean('bowel_incontinence')->default(false);
            $table->boolean('change_bowel_incontinence')->default(false);
            $table->boolean('constipation')->default(false);
            $table->boolean('diarrhea')->default(false);
            $table->boolean('ascites')->default(false);
            $table->boolean('ostomy_details')->default(false);
            $table->boolean('drain_details')->default(false);
            $table->boolean('anorexia')->default(false);
            $table->boolean('cachexia')->default(false);
            $table->boolean('nausea')->default(false);
            $table->boolean('vomiting')->default(false);
            $table->boolean('no_intake_last_24hrs')->default(false);
            $table->boolean('swallowing_deficits')->default(false);
            $table->boolean('inability_swallow')->default(false);
            $table->string('diet')->nullable();
            $table->string('percentage_eaten')->nullable();
            $table->boolean('npo')->default(false);
            $table->boolean('tube_feeding')->default(false);
            $table->boolean('placement_checked')->default(false);
            $table->boolean('most_recent_rbs')->default(false);
            $table->boolean('hyperglycemia')->default(false);
            $table->boolean('hypoglycemia')->default(false);
            $table->boolean('other')->default(false);
            $table->boolean('no_deficit')->default(false);
            $table->text('describe_deficits')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('gastrointestinal_data');
    }
}
