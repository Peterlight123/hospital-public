<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFlaccBehavioralPainTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('flacc_behavioral_pain', function (Blueprint $table) {
            $table->id();
            $table->unsignedTinyInteger('face')->nullable();
            $table->unsignedTinyInteger('legs')->nullable();
            $table->unsignedTinyInteger('activity')->nullable();
            $table->unsignedTinyInteger('cry')->nullable();
            $table->unsignedTinyInteger('consolability')->nullable();
            $table->foreignId('patient_id')->constrained()->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('flacc_behavioral_pain');
    }
}
