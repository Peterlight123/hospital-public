<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePainScalesToolsLabDataReviewsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pain_scales_tools_lab_data_reviews', function (Blueprint $table) {
            $table->id();
             // Relation avec le patient
             $table->foreignId('patient_id')
             ->constrained('patients')
             ->onDelete('cascade');
       
            // Scales & Tools
            $table->string('mid_arm_circumference')->nullable()->comment('Mid Arm Circumference (MAC)');
            $table->string('mid_thigh_circumference')->nullable()->comment('Mid-Thigh Circumference (MTC)');
            $table->integer('sleep_hours')->nullable()->comment('Sleep time in last 24 hours');
            $table->string('fast')->nullable()->comment('FAST score');
            $table->string('nyha')->nullable()->comment('NYHA classification');
            $table->string('pps')->nullable()->comment('PPS score');

            // Lab Values
            $table->string('blood_sugar')->nullable();
            $table->string('pt_inr')->nullable()->comment('PT/INR value');
            $table->string('other_reading_2')->nullable();
            $table->string('other_reading_3')->nullable();
            $table->string('other_reading_4')->nullable();

            $table->timestamps();
             // Index pour optimiser les recherches
             $table->index('patient_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pain_scales_tools_lab_data_reviews');
    }
}
