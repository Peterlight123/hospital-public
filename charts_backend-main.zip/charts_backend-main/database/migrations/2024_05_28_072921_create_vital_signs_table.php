<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVitalSignsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vital_signs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('note_id')->constrained('nursing_clinical_notes')->onDelete('cascade');
            $table->integer('degrees_fahrenheit')->nullable();
            $table->string('temperature_method')->nullable();
            $table->integer('heart_rate')->nullable();
            $table->string('heart_rhythm')->nullable();
            $table->string('heart_rate_location')->nullable();
            $table->string('other_heart_rate_location')->nullable();
            $table->integer('bp_systolic')->nullable();
            $table->integer('bp_diastolic')->nullable();
            $table->string('bp_position')->nullable();
            $table->string('bp_location')->nullable();
            $table->string('other_bp_location')->nullable();
            $table->string('bp_additional_readings')->nullable();
            $table->integer('respiratory_rate')->nullable();
            $table->string('respiratory_rhythm')->nullable();
            $table->integer('pulse_oximetry_percentage')->nullable();
            $table->string('pulse_ox_location')->nullable();
            $table->string('pulse_ox_other_location')->nullable();
            $table->float('body_height_inches')->nullable();
            $table->float('body_weight_ibs')->nullable();
            $table->float('body_weight_kg')->nullable();
            $table->string('body_weight_period')->nullable();
            $table->float('bmi_kg_m2')->nullable();
            $table->float('bmi_percentage')->nullable();
            $table->integer('bp_mmhg')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vital_signs');
    }
}
