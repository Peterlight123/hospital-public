<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateComprehensivePainAssessmentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('comprehensive_pain_assessment', function (Blueprint $table) {
            $table->id();
            $table->unsignedTinyInteger('comprehensive_pain')->nullable();
            $table->date('date_of_assessment')->nullable();
            $table->string('comprehensive_pain_included')->nullable();
            $table->string('comments')->nullable();
            $table->foreignId('patient_id')->constrained()->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('comprehensive_pain_assessment');
    }
}
