<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePainDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pain_data', function (Blueprint $table) {
            $table->id();
            $table->foreignId('note_id')->constrained('nursing_clinical_notes')->onDelete('cascade');
            $table->string('pain_level_now')->nullable();
            $table->string('pain_right')->nullable();
            $table->string('pain_left')->nullable();
            $table->string('pain_acceptable_level')->nullable();
            $table->json('pain_rated_by')->nullable();
            $table->string('respiratory_rhythm')->nullable();
            $table->json('pain_observations')->nullable();
            $table->json('pain_duration')->nullable();
            $table->json('pain_frequency')->nullable();
            $table->json('pain_character')->nullable();
            $table->json('worsened_by')->nullable();
            $table->json('relieved_by')->nullable();
            $table->json('effects_on_function')->nullable();
            $table->string('current_pain_management')->nullable();
            $table->json('breakthrough_pain')->nullable();
            $table->string('additional_pain_information')->nullable();
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pain_data');
    }
}
