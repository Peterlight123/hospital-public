<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateScaleToolLabDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('scale_tool_lab_data', function (Blueprint $table) {
            $table->id();
            $table->foreignId('note_id')->constrained('nursing_clinical_notes')->onDelete('cascade');
            $table->string('mac')->nullable();
            $table->string('mtc')->nullable();
            $table->string('sleep_time')->nullable();
            $table->string('fast')->nullable();
            $table->string('nyha')->nullable();
            $table->string('other_reading_1')->nullable();
            $table->string('blood_sugar')->nullable();
            $table->string('pt_inr')->nullable();
            $table->string('other_reading_2')->nullable();
            $table->string('other_reading_3')->nullable();
            $table->string('other_reading_4')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('scale_tool_lab_data');
    }
}
