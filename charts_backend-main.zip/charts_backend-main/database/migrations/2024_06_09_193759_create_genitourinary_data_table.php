<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGenitourinaryDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('genitourinary_data', function (Blueprint $table) {
            $table->id();
            $table->foreignId('note_id')->constrained('nursing_clinical_notes')->onDelete('cascade');
            $table->boolean('absence_urinary_output')->default(false);
            $table->boolean('decrease_urinary_output')->default(false);
            $table->boolean('change_bladder_incontinence')->default(false);
            $table->boolean('distension')->default(false);
            $table->boolean('incontinence')->default(false);
            $table->boolean('retention')->default(false);
            $table->json('current_ss_infection')->nullable(); // Store as JSON
            $table->boolean('indwelling_catheter_flush')->default(false);
            $table->boolean('other_catheter')->default(false);
            $table->boolean('no_deficit')->default(false);
            $table->boolean('urinary_diversion_ostomy_ileal_conduit')->default(false);
            $table->boolean('urinary_diversion_ostomy_nephrostomy')->default(false);
            $table->boolean('urinary_diversion_ostomy_ureterostomy')->default(false);
            $table->boolean('urinary_diversion_ostomy_other')->default(false);
            $table->boolean('urinary_diversion_ostomy_suprapubic_catheter')->default(false);
            $table->boolean('urinary_diversion_ostomy_condom_catheter')->default(false);
            $table->string('flush')->nullable();
            $table->string('size_balloon')->nullable();
            $table->string('describe_deficits')->nullable();
            $table->timestamps();
    
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('genitourinary_data');
    }
}
