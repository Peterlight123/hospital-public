<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePainScreeningTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pain_screening', function (Blueprint $table) {
            $table->id();
            $table->unsignedTinyInteger('patient_screened')->nullable();
            $table->date('date_of_first_pain')->nullable();
            $table->unsignedTinyInteger('pain_severity')->nullable();
            $table->unsignedTinyInteger('standardized_tool_pain_used')->nullable();
            $table->foreignId('patient_id')->constrained()->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pain_screening');
    }
}
