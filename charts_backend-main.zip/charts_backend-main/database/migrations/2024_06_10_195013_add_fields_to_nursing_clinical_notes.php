<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldsToNursingClinicalNotes extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('nursing_clinical_notes', function (Blueprint $table) {
            $table->time('time_in')->nullable();
            $table->time('time_out')->nullable();
            $table->boolean('prn_visit')->default(false);
            $table->json('patient_identifiers')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('nursing_clinical_notes', function (Blueprint $table) {
            $table->dropColumn('time_in');
            $table->dropColumn('time_out');
            $table->dropColumn('prn_visit');
            $table->dropColumn('patient_identifiers');
        });
    }
}
