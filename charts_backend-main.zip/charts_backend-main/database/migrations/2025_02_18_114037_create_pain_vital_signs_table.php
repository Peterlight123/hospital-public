<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePainVitalSignsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pain_vital_signs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('patients');
            $table->decimal('temperature_fahrenheit', 4, 1)->nullable();
            $table->string('temperature_method')->nullable();
            $table->integer('heart_rate')->nullable();
            $table->string('heart_rhythm')->nullable();
            $table->string('heart_rate_location')->nullable();
            $table->integer('respiratory_rate')->nullable();
            $table->string('respiratory_rhythm')->nullable();
            $table->integer('blood_pressure_systolic')->nullable();
            $table->integer('blood_pressure_diastolic')->nullable();
            $table->string('bp_location')->nullable();
            $table->string('bp_position')->nullable();
            $table->text('bp_additional_details')->nullable();
            $table->decimal('pulse_oximetry', 4, 1)->nullable();
            $table->string('pulse_ox_location')->nullable();
            $table->text('pulse_ox_other_location')->nullable();
            $table->decimal('bmi', 4, 1)->nullable();
            $table->decimal('bmi_percentile', 4, 1)->nullable();
            $table->decimal('body_height_inches', 4, 1)->nullable();
            $table->decimal('body_weight_lbs', 4, 1)->nullable();
            $table->decimal('body_weight_kg', 4, 1)->nullable();
            $table->string('weight_source')->nullable();
            $table->decimal('abdominal_girth_cm', 4, 1)->nullable();
            $table->text('abdominal_girth_location')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pain_vital_signs');
    }
}
