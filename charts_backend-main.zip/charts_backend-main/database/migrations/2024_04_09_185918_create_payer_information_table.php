<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePayerInformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payer_information', function (Blueprint $table) {
            $table->id();
            $table->string('social_security')->nullable();
            $table->string('medicare_beneficiary')->nullable();
            $table->string('medicaid_number')->nullable();
            $table->string('payer_info')->nullable();
            $table->boolean('medicaid_recipient')->nullable();
            $table->unsignedBigInteger('patient_id');
            $table->foreign('patient_id')->references('id')->on('patients')->onDelete('no action');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payer_information');
    }
}
