<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRespiratoryDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('respiratory_data', function (Blueprint $table) {
            $table->id();
            $table->foreignId('note_id')->constrained('nursing_clinical_notes')->onDelete('cascade');
            $table->json('clear')->nullable();
            $table->json('diminished')->nullable();
            $table->json('crackles')->nullable();
            $table->json('rhonchi')->nullable();
            $table->json('wheezing')->nullable();
            $table->json('rales')->nullable();
            $table->json('absent')->nullable();
            $table->text('note')->nullable();
            $table->json('breathing')->nullable();
            $table->json('oxygen_use')->nullable();
            $table->json('shortness_of_breath')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('respiratory_data');
    }
}
